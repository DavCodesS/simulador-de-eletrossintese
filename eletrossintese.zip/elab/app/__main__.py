"""Ponto de entrada: ``python -m app``.

Sobe o servidor local e abre o navegador. Para não abrir o navegador
(execução em servidor ou em contêiner), use ``ELAB_OPEN_BROWSER=0``.
"""

from __future__ import annotations

import threading
import webbrowser

import uvicorn

from .config import settings


def _open_browser(url: str, delay: float = 1.2) -> None:
    threading.Timer(delay, lambda: webbrowser.open(url)).start()


def main() -> None:
    url = f"http://{settings.host}:{settings.port}"
    print(f"\n  {settings.app_name} v{settings.version}")
    print(f"  Interface : {url}")
    print(f"  Documentação da API : {url}/docs")
    print(f"  Banco de dados : {settings.database_url}\n")

    if settings.open_browser:
        _open_browser(url)

    uvicorn.run("app.main:app", host=settings.host, port=settings.port,
                reload=False, log_level="info")


if __name__ == "__main__":
    main()
