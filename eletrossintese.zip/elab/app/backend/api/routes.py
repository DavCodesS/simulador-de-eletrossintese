"""Rotas HTTP.

Esta camada só traduz: HTTP -> serviço/motor -> HTTP. Não há nenhuma
fórmula, nenhuma conversão de unidade e nenhuma decisão científica aqui.
"""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session

from ...config import settings
from ..calculations import engine, formulas, simulation, stoichiometry
from ..calculations.errors import CalculationError
from ..validators import experiment_validator
from ..calculations.spec import ExperimentSpec
from ..calculations.units import UNIT_REGISTRY
from ..database.session import get_session
from ..services import io_service, report_service
from ..services.experiment_service import ExperimentService
from .schemas import (
    ExperimentIn, ImportIn, LimitingIn, ScenariosIn, SweepIn,
)

router = APIRouter(prefix="/api")


def service(session: Session = Depends(get_session)) -> ExperimentService:
    return ExperimentService(session)


def _guard(callable_: Any, *args: Any,
           spec: Any = None, **kwargs: Any) -> Any:
    """Converte erros do motor em respostas HTTP previsíveis.

    Quando a descrição do experimento está disponível, a resposta traz
    também a lista completa de problemas — o motor para no primeiro, mas
    quem preenche o formulário merece ver todos de uma vez.
    """
    try:
        return callable_(*args, **kwargs)
    except CalculationError as exc:
        detail: dict[str, Any] = {
            "error": str(exc),
            "field": getattr(exc, "field", None),
            "kind": type(exc).__name__,
        }
        if spec is not None:
            detail["problems"] = [
                problem.as_dict()
                for problem in experiment_validator.inspect(spec)
            ]
        raise HTTPException(status_code=422, detail=detail) from exc


# ---------------------------------------------------------------------------
# Metadados
# ---------------------------------------------------------------------------

@router.get("/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "version": settings.version,
            "database": "sqlite" if settings.is_sqlite else "external"}


@router.get("/formulas")
def list_formulas() -> dict[str, Any]:
    return {"formulas": formulas.catalog(),
            "faraday_constant": formulas.FARADAY_CONSTANT,
            "faraday_reference": formulas.FARADAY_REFERENCE}


@router.get("/units")
def list_units() -> dict[str, Any]:
    return {"dimensions": {dim: list(units)
                           for dim, units in UNIT_REGISTRY.items()},
            "sweepable": simulation.SWEEPABLE}


# ---------------------------------------------------------------------------
# Cálculo sem persistência
# ---------------------------------------------------------------------------

@router.post("/calculate")
def calculate(payload: ExperimentIn) -> dict[str, Any]:
    data = payload.to_spec_dict()
    return _guard(ExperimentService.calculate, data, spec=data)


@router.post("/validate")
def validate_spec(payload: ExperimentIn) -> dict[str, Any]:
    """Confere a descrição inteira e devolve todos os problemas de uma vez.

    Diferente de ``/calculate``, este endpoint nunca devolve 422: ele existe
    justamente para relatar o que está errado.
    """
    problems = experiment_validator.inspect(payload.to_spec_dict())
    errors = experiment_validator.errors_only(problems)
    return {
        "valid": not errors,
        "problems": [problem.as_dict() for problem in problems],
        "error_count": len(errors),
        "notice_count": len(problems) - len(errors),
    }


@router.post("/limiting")
def limiting(payload: LimitingIn) -> dict[str, Any]:
    spec = ExperimentSpec.from_dict(
        {"reagents": [r.model_dump() for r in payload.reagents],
         "limiting_selection": payload.limiting_selection})
    _guard(spec.validate)
    analysis = _guard(stoichiometry.analyse_limiting, spec.reagents,
                      payload.limiting_selection)
    theoretical = _guard(
        stoichiometry.theoretical_amount_from_stoichiometry,
        analysis, payload.product_coefficient, payload.product_name)
    return {"limiting": analysis.as_dict(),
            "theoretical_amount": theoretical.as_dict()}


# ---------------------------------------------------------------------------
# CRUD de experimentos
# ---------------------------------------------------------------------------

@router.get("/experiments")
def list_experiments(
    search: str = "",
    sort: str = "created_at",
    direction: Literal["asc", "desc"] = "desc",
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    min_yield: float | None = None,
    max_yield: float | None = None,
    svc: ExperimentService = Depends(service),
) -> dict[str, Any]:
    rows = svc.list(search=search, sort=sort, direction=direction,
                    limit=limit, offset=offset,
                    min_yield=min_yield, max_yield=max_yield)
    return {"total": svc.repository.count(),
            "items": [e.as_dict(include_results=False) for e in rows]}


@router.post("/experiments", status_code=201)
def create_experiment(payload: ExperimentIn,
                      svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    data = payload.to_spec_dict()
    return _guard(svc.create, data, spec=data).as_dict()


@router.get("/experiments/{experiment_id}")
def get_experiment(experiment_id: int,
                   svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    experiment = svc.get(experiment_id)
    if experiment is None:
        raise HTTPException(404, "Experimento não encontrado.")
    return experiment.as_dict()


@router.put("/experiments/{experiment_id}")
def update_experiment(experiment_id: int, payload: ExperimentIn,
                      svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    data = payload.to_spec_dict()
    experiment = _guard(svc.update, experiment_id, data, spec=data)
    if experiment is None:
        raise HTTPException(404, "Experimento não encontrado.")
    return experiment.as_dict()


@router.post("/experiments/{experiment_id}/duplicate", status_code=201)
def duplicate_experiment(experiment_id: int, name: str = Body("", embed=True),
                         svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    experiment = _guard(svc.duplicate, experiment_id, name)
    if experiment is None:
        raise HTTPException(404, "Experimento não encontrado.")
    return experiment.as_dict()


@router.post("/experiments/{experiment_id}/recalculate")
def recalculate_experiment(experiment_id: int,
                           svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    experiment = _guard(svc.recalculate, experiment_id)
    if experiment is None:
        raise HTTPException(404, "Experimento não encontrado.")
    return experiment.as_dict()


@router.delete("/experiments/{experiment_id}", status_code=204)
def delete_experiment(experiment_id: int,
                      svc: ExperimentService = Depends(service)) -> Response:
    if not svc.delete(experiment_id):
        raise HTTPException(404, "Experimento não encontrado.")
    return Response(status_code=204)


# ---------------------------------------------------------------------------
# Painel, comparação e séries
# ---------------------------------------------------------------------------

@router.get("/dashboard")
def dashboard(svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    return svc.dashboard()


@router.get("/compare")
def compare(ids: str = Query(..., description="IDs separados por vírgula"),
            svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    parsed = [int(part) for part in ids.split(",") if part.strip().isdigit()]
    return _guard(svc.compare, parsed)


@router.get("/series")
def series(ids: str = "",
           svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    parsed = [int(part) for part in ids.split(",") if part.strip().isdigit()]
    return {"points": svc.series(parsed or None)}


# ---------------------------------------------------------------------------
# Simulação
# ---------------------------------------------------------------------------

@router.post("/simulate/sweep")
def sweep(payload: SweepIn) -> dict[str, Any]:
    spec = ExperimentSpec.from_dict(payload.spec.to_spec_dict())
    result = _guard(simulation.sweep, spec, payload.parameter,
                    payload.start, payload.stop, payload.points)
    return result.as_dict()


@router.post("/simulate/scenarios")
def scenarios(payload: ScenariosIn) -> dict[str, Any]:
    spec = ExperimentSpec.from_dict(payload.spec.to_spec_dict())
    evaluated = _guard(
        simulation.scenarios, spec,
        [s.model_dump() for s in payload.scenarios])
    return {"scenarios": [s.as_dict() for s in evaluated],
            "disclaimer": simulation.PROJECTION_DISCLAIMER}


# ---------------------------------------------------------------------------
# Relatórios, importação e exportação
# ---------------------------------------------------------------------------

@router.get("/experiments/{experiment_id}/report")
def report(experiment_id: int,
           svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    experiment = svc.get(experiment_id)
    if experiment is None:
        raise HTTPException(404, "Experimento não encontrado.")
    return report_service.build(experiment)


@router.get("/experiments/{experiment_id}/report.pdf")
def report_pdf(experiment_id: int,
               svc: ExperimentService = Depends(service)) -> Response:
    experiment = svc.get(experiment_id)
    if experiment is None:
        raise HTTPException(404, "Experimento não encontrado.")
    try:
        content = report_service.to_pdf(experiment)
    except ImportError as exc:
        raise HTTPException(
            501, "Exportação em PDF indisponível: instale 'reportlab'.") from exc
    filename = f"relatorio_{experiment.id}.pdf"
    return Response(content, media_type="application/pdf",
                    headers={"Content-Disposition":
                             f'attachment; filename="{filename}"'})


@router.get("/export/template.csv")
def csv_template() -> Response:
    return Response(io_service.template_csv(), media_type="text/csv",
                    headers={"Content-Disposition":
                             'attachment; filename="modelo_importacao.csv"'})


@router.get("/export/{fmt}")
def export(fmt: Literal["csv", "json", "xlsx"], ids: str = "",
           svc: ExperimentService = Depends(service)) -> Response:
    parsed = [int(part) for part in ids.split(",") if part.strip().isdigit()]
    rows = (svc.repository.get_many(parsed) if parsed
            else svc.list(limit=1000, sort="created_at", direction="asc"))

    if fmt == "csv":
        return Response(io_service.export_csv(rows), media_type="text/csv",
                        headers={"Content-Disposition":
                                 'attachment; filename="experimentos.csv"'})
    if fmt == "json":
        return Response(io_service.export_json(rows),
                        media_type="application/json",
                        headers={"Content-Disposition":
                                 'attachment; filename="experimentos.json"'})
    try:
        content = io_service.export_xlsx(rows)
    except ImportError as exc:
        raise HTTPException(
            501, "Exportação em Excel indisponível: instale 'openpyxl'.") from exc
    return Response(
        content,
        media_type=("application/vnd.openxmlformats-officedocument"
                    ".spreadsheetml.sheet"),
        headers={"Content-Disposition":
                 'attachment; filename="experimentos.xlsx"'})


@router.post("/import/csv")
def import_csv(payload: ImportIn,
               svc: ExperimentService = Depends(service)) -> dict[str, Any]:
    specs, errors = _guard(io_service.parse_csv, payload.content)
    created = []
    if payload.persist:
        for spec_data in specs:
            try:
                created.append(svc.create(spec_data).as_dict(
                    include_results=False))
            except CalculationError as exc:
                errors.append(f"'{spec_data.get('name')}': {exc}")
    return {"parsed": len(specs), "created": len(created),
            "errors": errors, "items": created,
            "previews": specs if not payload.persist else []}
