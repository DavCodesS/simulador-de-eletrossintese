"""Esquemas de entrada e saída da API.

O Pydantic cuida apenas de tipos e formato. As regras físicas (massa não
negativa, tempo positivo, eficiência entre 0 e 100 %) ficam no motor de
cálculo, para que valham também fora da API.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class ReagentIn(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    formula: str = ""
    molar_mass: float | None = None
    mass: float | None = None
    mass_unit: str = "mg"
    amount: float | None = None
    amount_unit: str = "mmol"
    concentration: float | None = None
    concentration_unit: str = "mol/L"
    volume: float | None = None
    volume_unit: str = "mL"
    stoich_coefficient: float | None = None
    role: str = "reagent"
    notes: str = ""


class ProductIn(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str = "Produto"
    formula: str = ""
    molar_mass: float | None = None
    stoich_coefficient: float | None = None
    electrons_per_mol: float | None = None
    experimental_mass: float | None = None
    experimental_mass_unit: str = "mg"
    experimental_amount: float | None = None
    experimental_amount_unit: str = "mmol"
    notes: str = ""


class ElectroIn(BaseModel):
    model_config = ConfigDict(extra="ignore")

    current: float | None = None
    current_unit: str = "mA"
    time: float | None = None
    time_unit: str = "min"
    voltage: float | None = None
    voltage_unit: str = "V"
    measured_charge: float | None = None
    measured_charge_unit: str = "C"
    faraday_constant: float | None = None
    assumed_current_efficiency: float | None = None
    assumed_current_efficiency_unit: str = "%"
    notes: str = ""


class ExperimentIn(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str = "Experimento sem nome"
    identifier: str = ""
    date: str = ""
    reference: str = ""
    notes: str = ""
    reagents: list[ReagentIn] = Field(default_factory=list)
    product: ProductIn = Field(default_factory=ProductIn)
    electro: ElectroIn = Field(default_factory=ElectroIn)
    substrate_name: str = ""
    limiting_selection: str = "auto"
    yield_definition: Literal["mass", "amount"] = "mass"
    theoretical_basis: Literal["stoichiometric", "faradaic"] = "stoichiometric"

    def to_spec_dict(self) -> dict[str, Any]:
        """Remove chaves nulas que devem cair no padrão da dataclass."""
        data = self.model_dump()
        electro = data.get("electro") or {}
        if electro.get("faraday_constant") is None:
            electro.pop("faraday_constant", None)
        return data


class LimitingIn(BaseModel):
    reagents: list[ReagentIn]
    product_coefficient: float | None = None
    product_name: str = "Produto"
    limiting_selection: str = "auto"


class SweepIn(BaseModel):
    spec: ExperimentIn
    parameter: str
    start: float
    stop: float
    points: int = 25


class ScenarioIn(BaseModel):
    name: str = ""
    overrides: dict[str, Any] = Field(default_factory=dict)


class ScenariosIn(BaseModel):
    spec: ExperimentIn
    scenarios: list[ScenarioIn]


class ImportIn(BaseModel):
    content: str
    persist: bool = True


class ErrorOut(BaseModel):
    error: str
    field: str | None = None
    kind: str = "validation"
