"""Cálculos eletroquímicos.

Cada função devolve um ``Outcome``. Quando faltam dados, o ``Outcome`` sai
com ``status='not_calculable'`` e a lista do que falta — nunca com um valor
estimado. Isso é o que permite à interface mostrar "não calculável" em vez
de um número silenciosamente inventado.
"""

from __future__ import annotations

from . import formulas as F
from .spec import ElectroSpec
from .trace import Outcome, Step, StepKind
from .units import Quantity


def total_charge(electro: ElectroSpec) -> Outcome:
    """Carga total: medida por coulometria, ou calculada por Q = I · t."""
    key, label = "charge", "Carga elétrica total"

    measured = electro.measured_charge_q
    if measured is not None:
        from .trace import Trace
        trace = Trace(title="Carga elétrica total (medida)")
        trace.assumption(
            "Origem do valor",
            "Carga medida diretamente (coulômetro). Tem precedência sobre "
            "Q = I · t, que pressupõe corrente constante.")
        trace.input("Q medida", measured.value, measured.unit)
        if measured.is_converted():
            trace.conversion("Conversão", f"{measured.value} {measured.unit} "
                             f"= {measured.base_value} C",
                             measured.base_value, "C")
        trace.result(measured.base_value, "C", "Q")
        return Outcome.ok(key, label, measured.base_value, "C", trace,
                          kind="experimental")

    current, time = electro.current_q, electro.time_q
    missing = []
    if current is None:
        missing.append("corrente")
    if time is None:
        missing.append("tempo")
    if missing:
        return Outcome.missing_data(
            key, label, missing,
            "Informe corrente e tempo, ou a carga medida diretamente.")

    value, trace = F.CHARGE_FROM_CURRENT_TIME.evaluate(
        {"I": current, "t": time}, trace_title="Carga elétrica total")
    trace.steps.insert(0, Step(
        StepKind.ASSUMPTION, "Regime admitido",
        note="Corrente constante durante todo o ensaio (galvanostático). "
             "Se a corrente variou, use a carga medida."))
    return Outcome.ok(key, label, value, "C", trace)


def moles_of_electrons(charge: Outcome, electro: ElectroSpec) -> Outcome:
    """n(e⁻) = Q / F."""
    key, label = "moles_electrons", "Quantidade de matéria de elétrons"
    if not charge.is_ok:
        return Outcome.missing_data(key, label, ["carga elétrica"],
                                    charge.reason)
    value, trace = F.MOLES_OF_ELECTRONS.evaluate(
        {"Q": Quantity.create(charge.value, "C"), "F": electro.faraday_q},
        trace_title="Quantidade de matéria de elétrons")
    if charge.trace:
        trace.steps.insert(0, Step(StepKind.INTERMEDIATE, "Carga utilizada",
                                   value=charge.value, unit="C",
                                   note="Ver rastro da carga total."))
    return Outcome.ok(key, label, value, "mol", trace)


def electrical_energy(charge: Outcome, electro: ElectroSpec) -> Outcome:
    """E = U · Q, válida para tensão aproximadamente constante."""
    key, label = "energy", "Energia elétrica consumida"
    voltage = electro.voltage_q
    missing = []
    if voltage is None:
        missing.append("tensão da célula")
    if not charge.is_ok:
        missing.append("carga elétrica")
    if missing:
        return Outcome.missing_data(key, label, missing)
    value, trace = F.SPECIFIC_ENERGY.evaluate(
        {"U": voltage, "Q": Quantity.create(charge.value, "C")},
        trace_title="Energia elétrica consumida")
    trace.steps.insert(0, Step(
        StepKind.ASSUMPTION, "Regime admitido",
        note="Tensão média constante. Em ensaios com tensão variável este "
             "valor é apenas uma estimativa de ordem de grandeza."))
    return Outcome.ok(key, label, value, "J", trace)


def charge_per_mole_substrate(charge: Outcome,
                              substrate_amount_mol: float | None,
                              substrate_name: str) -> Outcome:
    """q = Q / n(substrato), em C/mol."""
    key, label = "charge_per_mole", "Carga por mol de substrato"
    missing = []
    if not charge.is_ok:
        missing.append("carga elétrica")
    if substrate_amount_mol is None:
        missing.append("quantidade de matéria do substrato")
    if missing:
        return Outcome.missing_data(key, label, missing)
    value, trace = F.CHARGE_PER_MOLE.evaluate(
        {"Q": Quantity.create(charge.value, "C"),
         "n_s": Quantity.create(substrate_amount_mol, "mol")},
        trace_title=f"Carga por mol de {substrate_name}")
    return Outcome.ok(key, label, value, "C/mol", trace)


def observed_electrons_per_substrate(electrons: Outcome,
                                     substrate_amount_mol: float | None,
                                     substrate_name: str) -> Outcome:
    """z_obs = n(e⁻) / n(substrato): grandeza medida, não mecanismo."""
    key = "electrons_per_substrate"
    label = "Elétrons por mol de substrato (observado)"
    missing = []
    if not electrons.is_ok:
        missing.append("quantidade de elétrons")
    if substrate_amount_mol is None:
        missing.append("quantidade de matéria do substrato")
    if missing:
        return Outcome.missing_data(key, label, missing)
    value, trace = F.ELECTRONS_PER_MOLE_SUBSTRATE.evaluate(
        {"n_e": Quantity.create(electrons.value, "mol"),
         "n_s": Quantity.create(substrate_amount_mol, "mol")},
        trace_title=f"Elétrons fornecidos por mol de {substrate_name}")
    trace.assumption(
        "Interpretação",
        "Razão entre elétrons fornecidos e substrato carregado. NÃO indica "
        "o número de elétrons do mecanismo: parte da carga pode ter sido "
        "consumida em processos paralelos.")
    return Outcome.ok(key, label, value, "", trace)


def theoretical_amount_faradaic(charge: Outcome, electro: ElectroSpec,
                                electrons_per_mol: float | None,
                                product_name: str) -> Outcome:
    """n_p = (Q · η) / (z · F), rota faradaica.

    Quando o usuário não informa uma eficiência admitida, o cálculo usa
    η = 100 % e o rastro registra isso como uma escolha explícita — que é o
    limite superior teórico, não uma previsão.
    """
    key, label = "theoretical_amount_faradaic", "Quantidade teórica (rota faradaica)"
    missing = []
    if not charge.is_ok:
        missing.append("carga elétrica")
    if electrons_per_mol is None:
        missing.append("elétrons por mol de produto (z)")
    if missing:
        return Outcome.missing_data(
            key, label, missing,
            "O valor de z depende do mecanismo da reação e precisa ser "
            "informado a partir do protocolo ou da literatura.")

    efficiency = electro.assumed_efficiency_q
    assumed = efficiency is None
    if assumed:
        efficiency = F.ratio(1.0)

    value, trace = F.AMOUNT_FROM_CHARGE.evaluate(
        {"Q": Quantity.create(charge.value, "C"),
         "eta": efficiency,
         "z": F.ratio(electrons_per_mol),
         "F": electro.faraday_q},
        trace_title=f"Quantidade teórica de {product_name} pela carga")
    trace.steps.insert(0, Step(
        StepKind.ASSUMPTION, "Eficiência de corrente",
        note=("Nenhuma eficiência foi informada; adotado η = 100 %, que é o "
              "limite superior teórico e não uma previsão de resultado."
              if assumed else
              f"Eficiência admitida pelo usuário: "
              f"{electro.assumed_current_efficiency} "
              f"{electro.assumed_current_efficiency_unit}.")))
    return Outcome.ok(key, label, value, "mol", trace)


def theoretical_charge(theoretical_amount: Outcome, electro: ElectroSpec,
                       electrons_per_mol: float | None) -> Outcome:
    """Q_th = n_p · z · F, carga exigida a 100 % de eficiência."""
    key, label = "theoretical_charge", "Carga teórica necessária"
    missing = []
    if not theoretical_amount.is_ok:
        missing.append("quantidade teórica de produto")
    if electrons_per_mol is None:
        missing.append("elétrons por mol de produto (z)")
    if missing:
        return Outcome.missing_data(key, label, missing)
    value, trace = F.THEORETICAL_CHARGE.evaluate(
        {"n_p": Quantity.create(theoretical_amount.value, "mol"),
         "z": F.ratio(electrons_per_mol),
         "F": electro.faraday_q},
        trace_title="Carga teórica necessária")
    return Outcome.ok(key, label, value, "C", trace)


def faradaic_efficiency(experimental_amount_mol: float | None,
                        charge: Outcome, electro: ElectroSpec,
                        electrons_per_mol: float | None) -> Outcome:
    """η = 100 · (n_exp · z · F) / Q, a partir do produto realmente isolado."""
    key, label = "faradaic_efficiency", "Eficiência faradaica (calculada)"
    missing = []
    if experimental_amount_mol is None:
        missing.append("quantidade experimental de produto")
    if not charge.is_ok:
        missing.append("carga elétrica")
    if electrons_per_mol is None:
        missing.append("elétrons por mol de produto (z)")
    if missing:
        return Outcome.missing_data(key, label, missing)
    value, trace = F.FARADAIC_EFFICIENCY.evaluate(
        {"n_exp": Quantity.create(experimental_amount_mol, "mol"),
         "z": F.ratio(electrons_per_mol),
         "F": electro.faraday_q,
         "Q": Quantity.create(charge.value, "C")},
        trace_title="Eficiência faradaica a partir do produto isolado")
    trace.assumption(
        "Distinção importante",
        "Esta é a eficiência CALCULADA a partir do produto experimental. Não "
        "se confunde com a eficiência ADMITIDA usada em simulações.")
    return Outcome.ok(key, label, value, "%", trace)
