"""Motor de cálculo — orquestrador.

Recebe um ``ExperimentSpec`` e devolve um ``ExperimentResults`` com todos os
parâmetros que puderam ser calculados e, explicitamente, os que não puderam.

Este módulo não importa FastAPI, SQLAlchemy, Jinja nem nada de I/O. É a
fronteira: tudo abaixo dele é ciência pura e testável isoladamente.

Duas rotas independentes de quantidade teórica são sempre calculadas quando
possível e NUNCA são fundidas:

* rota estequiométrica — limitada pela matéria disponível;
* rota faradaica       — limitada pela carga fornecida.

O usuário escolhe qual delas é a referência do rendimento
(``theoretical_basis``), e o resultado deixa claro qual foi usada.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from . import electrochemistry as ec
from . import formulas as F
from . import stoichiometry as st
from .errors import CalculationError
from .formatting import significant
from .spec import ExperimentSpec
from .trace import Outcome, Step, StepKind, Trace
from .units import Quantity


@dataclass(slots=True)
class ExperimentResults:
    """Conjunto completo de resultados de um experimento."""

    spec: ExperimentSpec
    outcomes: dict[str, Outcome] = field(default_factory=dict)
    limiting: st.LimitingAnalysis | None = None
    warnings: list[str] = field(default_factory=list)

    def add(self, outcome: Outcome) -> Outcome:
        self.outcomes[outcome.key] = outcome
        return outcome

    def value(self, key: str) -> float | None:
        outcome = self.outcomes.get(key)
        return outcome.value if outcome and outcome.is_ok else None

    def as_dict(self) -> dict[str, Any]:
        return {
            "spec": self.spec.as_dict(),
            "limiting": self.limiting.as_dict() if self.limiting else None,
            "outcomes": {k: v.as_dict() for k, v in self.outcomes.items()},
            "warnings": self.warnings,
            "summary": self.summary(),
        }

    def summary(self) -> dict[str, Any]:
        """Achatado para tabelas, gráficos e comparações."""
        return {
            key: (o.value if o.is_ok else None)
            for key, o in self.outcomes.items()
        }


def _experimental_amount(results: ExperimentResults) -> Outcome:
    """Quantidade de matéria de produto obtida: informada ou via n = m / M."""
    product = results.spec.product
    key, label = "experimental_amount", "Quantidade experimental de produto"

    direct = product.experimental_amount_q
    if direct is not None:
        trace = Trace(title=label)
        trace.input("n experimental informado", direct.value, direct.unit)
        if direct.is_converted():
            trace.conversion(
                "Conversão",
                f"{significant(direct.value)} {direct.unit} = "
                f"{significant(direct.base_value)} mol",
                direct.base_value, "mol")
        trace.result(direct.base_value, "mol", "n_exp")
        return Outcome.ok(key, label, direct.base_value, "mol", trace,
                          kind="experimental")

    mass, molar_mass = product.experimental_mass_q, product.molar_mass_q
    missing = []
    if mass is None:
        missing.append("massa experimental de produto")
    if molar_mass is None:
        missing.append("massa molar do produto")
    if missing:
        return Outcome.missing_data(key, label, missing)

    value, trace = F.AMOUNT_FROM_MASS.evaluate(
        {"m": mass, "M": molar_mass}, trace_title=label)
    outcome = Outcome.ok(key, label, value, "mol", trace, kind="experimental")
    return outcome


def _theoretical_mass(results: ExperimentResults,
                      theoretical_amount: Outcome) -> Outcome:
    """m_th = n_th · M."""
    key, label = "theoretical_mass", "Massa teórica de produto"
    molar_mass = results.spec.product.molar_mass_q
    missing = []
    if not theoretical_amount.is_ok:
        missing.append("quantidade teórica de produto")
    if molar_mass is None:
        missing.append("massa molar do produto")
    if missing:
        return Outcome.missing_data(key, label, missing,
                                    theoretical_amount.reason)
    value, trace = F.MASS_FROM_AMOUNT.evaluate(
        {"n": Quantity.create(theoretical_amount.value, "mol"),
         "M": molar_mass}, trace_title=label)
    trace.steps.insert(0, Step(
        StepKind.ASSUMPTION, "Base teórica",
        note=f"Usada a {theoretical_amount.label.lower()}."))
    return Outcome.ok(key, label, value, "g", trace)


def _yields(results: ExperimentResults, theoretical_amount: Outcome,
            theoretical_mass: Outcome, experimental_amount: Outcome) -> None:
    """Calcula as DUAS definições de rendimento, sem misturá-las."""
    spec = results.spec
    experimental_mass = spec.product.experimental_mass_q

    # -- definição por massa ----------------------------------------------
    missing = []
    if experimental_mass is None:
        missing.append("massa experimental de produto")
    if not theoretical_mass.is_ok:
        missing.append("massa teórica de produto")
    if missing:
        results.add(Outcome.missing_data(
            "yield_mass", "Rendimento (base massa)", missing,
            theoretical_mass.reason))
    else:
        value, trace = F.YIELD_BY_MASS.evaluate(
            {"m_exp": experimental_mass,
             "m_th": Quantity.create(theoretical_mass.value, "g")},
            trace_title="Rendimento — definição por massa")
        trace.assumption(
            "Definição empregada",
            "Rendimento = massa experimental / massa teórica × 100. Esta "
            "definição não é intercambiável com a definição por quantidade "
            "de matéria.")
        results.add(Outcome.ok("yield_mass", "Rendimento (base massa)",
                               value, "%", trace))

    # -- definição por quantidade de matéria -------------------------------
    missing = []
    if not experimental_amount.is_ok:
        missing.append("quantidade experimental de produto")
    if not theoretical_amount.is_ok:
        missing.append("quantidade teórica de produto")
    if missing:
        results.add(Outcome.missing_data(
            "yield_amount", "Rendimento (base quantidade de matéria)",
            missing, theoretical_amount.reason))
    else:
        value, trace = F.YIELD_BY_AMOUNT.evaluate(
            {"n_exp": Quantity.create(experimental_amount.value, "mol"),
             "n_th": Quantity.create(theoretical_amount.value, "mol")},
            trace_title="Rendimento — definição por quantidade de matéria")
        trace.assumption(
            "Definição empregada",
            "Rendimento = quantidade experimental / quantidade teórica × 100.")
        results.add(Outcome.ok("yield_amount",
                               "Rendimento (base quantidade de matéria)",
                               value, "%", trace))

    # -- rendimento principal, conforme a escolha do usuário ---------------
    source_key = "yield_mass" if spec.yield_definition == "mass" else "yield_amount"
    source = results.outcomes[source_key]
    primary = Outcome(
        key="yield_primary",
        label=f"Rendimento principal ({'massa' if spec.yield_definition == 'mass' else 'quantidade de matéria'})",
        status=source.status, value=source.value, unit=source.unit,
        trace=source.trace, reason=source.reason, missing=source.missing)
    results.add(primary)


def run(spec: ExperimentSpec) -> ExperimentResults:
    """Executa todos os cálculos possíveis para um experimento."""
    spec.validate()
    results = ExperimentResults(spec=spec)

    # ---- 1. Estequiometria e reagente limitante -------------------------
    limiting = st.analyse_limiting(spec.reagents, spec.limiting_selection)
    results.limiting = limiting

    # ---- 2. Substrato de referência -------------------------------------
    substrate_name = spec.substrate_name or (limiting.limiting_name or "")
    substrate_amount = None
    for entry in limiting.amounts:
        if entry.name.strip().lower() == substrate_name.strip().lower():
            substrate_amount = entry.amount_mol
            if entry.trace is not None:
                results.add(Outcome.ok(
                    "substrate_amount",
                    f"Quantidade de matéria de {entry.name}",
                    entry.amount_mol, "mol", entry.trace))
            break
    if "substrate_amount" not in results.outcomes:
        results.add(Outcome.missing_data(
            "substrate_amount", "Quantidade de matéria do substrato",
            ["substrato com quantidade calculável"],
            "Defina qual reagente é o substrato e informe massa + massa "
            "molar, quantidade de matéria, ou concentração + volume."))

    # ---- 3. Bloco eletroquímico ------------------------------------------
    charge = results.add(ec.total_charge(spec.electro))
    electrons = results.add(ec.moles_of_electrons(charge, spec.electro))
    results.add(ec.electrical_energy(charge, spec.electro))
    results.add(ec.charge_per_mole_substrate(
        charge, substrate_amount, substrate_name or "substrato"))
    results.add(ec.observed_electrons_per_substrate(
        electrons, substrate_amount, substrate_name or "substrato"))

    # ---- 4. Rotas teóricas independentes ---------------------------------
    stoich_route = results.add(st.theoretical_amount_from_stoichiometry(
        limiting, spec.product.stoich_coefficient, spec.product.name))
    faradaic_route = results.add(ec.theoretical_amount_faradaic(
        charge, spec.electro, spec.product.electrons_per_mol,
        spec.product.name))

    selected = (stoich_route if spec.theoretical_basis == "stoichiometric"
                else faradaic_route)
    results.add(Outcome(
        key="theoretical_amount",
        label=f"Quantidade teórica adotada ({'estequiométrica' if spec.theoretical_basis == 'stoichiometric' else 'faradaica'})",
        status=selected.status, value=selected.value, unit=selected.unit,
        trace=selected.trace, reason=selected.reason, missing=selected.missing))

    theoretical_amount = results.outcomes["theoretical_amount"]
    theoretical_mass = results.add(_theoretical_mass(results, theoretical_amount))

    # ---- 5. Produto experimental e rendimentos ---------------------------
    experimental_amount = results.add(_experimental_amount(results))
    _yields(results, theoretical_amount, theoretical_mass, experimental_amount)

    # ---- 6. Métricas de carga --------------------------------------------
    results.add(ec.theoretical_charge(
        stoich_route, spec.electro, spec.product.electrons_per_mol))
    results.add(ec.faradaic_efficiency(
        experimental_amount.value if experimental_amount.is_ok else None,
        charge, spec.electro, spec.product.electrons_per_mol))

    # ---- 7. Avisos derivados dos próprios números ------------------------
    _add_warnings(results, stoich_route, faradaic_route)
    return results


def _add_warnings(results: ExperimentResults, stoich: Outcome,
                  faradaic: Outcome) -> None:
    """Avisos que decorrem apenas de comparações numéricas já calculadas.

    Nenhum destes avisos prevê comportamento químico; todos apenas apontam
    inconsistências aritméticas ou limites que os próprios dados revelam.
    """
    warnings = results.warnings

    if stoich.is_ok and faradaic.is_ok:
        if faradaic.value < stoich.value:
            warnings.append(
                f"A carga aplicada comporta no máximo "
                f"{significant(faradaic.value)} mol de produto, abaixo dos "
                f"{significant(stoich.value)} mol permitidos pela "
                "estequiometria: o fator limitante nas condições informadas "
                "é a carga, não a matéria.")
        elif faradaic.value > stoich.value:
            warnings.append(
                f"A carga aplicada comporta {significant(faradaic.value)} mol "
                f"de produto, acima dos {significant(stoich.value)} mol "
                "permitidos pela estequiometria: há excesso de carga em "
                "relação ao reagente limitante.")

    for key in ("yield_mass", "yield_amount"):
        outcome = results.outcomes.get(key)
        if outcome and outcome.is_ok and outcome.value > 100:
            warnings.append(
                f"{outcome.label} resultou em {significant(outcome.value)} %, "
                "acima de 100 %. Verifique massa molar, coeficientes, pureza "
                "do produto isolado e a base teórica escolhida.")

    efficiency = results.outcomes.get("faradaic_efficiency")
    if efficiency and efficiency.is_ok and efficiency.value > 100:
        warnings.append(
            f"A eficiência faradaica calculada ({significant(efficiency.value)} %) "
            "excede 100 %, o que é fisicamente impossível. Reveja o valor de "
            "z, a carga total e a quantidade de produto.")

    mass_yield = results.outcomes.get("yield_mass")
    amount_yield = results.outcomes.get("yield_amount")
    if (mass_yield and amount_yield and mass_yield.is_ok and amount_yield.is_ok
            and abs(mass_yield.value - amount_yield.value) > 1e-6):
        warnings.append(
            "As duas definições de rendimento divergem. Isso ocorre quando a "
            "massa experimental e a quantidade experimental foram informadas "
            "de forma independente. Compare-as antes de reportar.")


def safe_run(spec: ExperimentSpec) -> tuple[ExperimentResults | None, str]:
    """Executa ``run`` capturando erros de validação de forma previsível."""
    try:
        return run(spec), ""
    except CalculationError as exc:
        return None, str(exc)
