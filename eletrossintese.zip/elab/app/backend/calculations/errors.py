"""Exceções do motor de cálculo.

Todas herdam de ``CalculationError`` para que a camada de API possa
traduzi-las em respostas HTTP sem conhecer os detalhes internos.
"""

from __future__ import annotations


class CalculationError(Exception):
    """Erro base do motor de cálculo."""

    http_status: int = 400


class UnknownUnitError(CalculationError):
    """Unidade ou dimensão não registrada."""


class IncompatibleUnitError(CalculationError):
    """Tentativa de operar com unidades de dimensões diferentes."""


class ValidationError(CalculationError):
    """Valor de entrada fora do domínio físico admissível."""

    def __init__(self, message: str, field: str | None = None) -> None:
        super().__init__(message)
        self.field = field


class MissingDataError(CalculationError):
    """Dados insuficientes para executar um cálculo.

    Nunca é usada para preencher valores desconhecidos: o motor a converte
    em um resultado explícito de status ``not_calculable``.
    """

    def __init__(self, message: str, missing: list[str] | None = None) -> None:
        super().__init__(message)
        self.missing = missing or []


class DivisionByZeroError(CalculationError):
    """Denominador nulo em uma fórmula."""


class FormulaError(CalculationError):
    """Fórmula inexistente ou usada com símbolos incorretos."""
