"""Formatação numérica — usada APENAS para apresentação.

O motor de cálculo nunca chama estas funções antes de terminar uma cadeia de
operações. Todos os valores intermediários permanecem em precisão total de
ponto flutuante de 64 bits; o arredondamento acontece somente quando o número
vira texto (rastro, relatório, interface).
"""

from __future__ import annotations

import math

DEFAULT_SIGNIFICANT_DIGITS = 6


def significant(value: float, digits: int = DEFAULT_SIGNIFICANT_DIGITS) -> str:
    """Formata um número com N algarismos significativos.

    Usa notação científica quando a magnitude torna a notação decimal
    ilegível, o que é comum em quantidade de matéria (1e-6 mol) e em carga.
    """
    if value is None:
        return "—"
    if isinstance(value, bool):
        return str(value)
    if not math.isfinite(value):
        return "indefinido"
    if value == 0:
        return "0"

    magnitude = math.floor(math.log10(abs(value)))
    if magnitude < -4 or magnitude >= digits + 3:
        text = f"{value:.{max(digits - 1, 0)}e}"
        mantissa, exponent = text.split("e")
        mantissa = mantissa.rstrip("0").rstrip(".")
        return f"{mantissa}e{int(exponent)}"

    decimals = max(digits - 1 - magnitude, 0)
    text = f"{value:.{decimals}f}"
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def with_unit(value: float | None, unit: str,
              digits: int = DEFAULT_SIGNIFICANT_DIGITS) -> str:
    """Representação ``valor unidade`` para o rastro."""
    if value is None:
        return "não calculável"
    text = significant(value, digits)
    return f"{text} {unit}".strip()
