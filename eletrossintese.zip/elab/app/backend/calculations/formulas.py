"""Registro de fórmulas matemáticas universais.

Cada fórmula é declarada uma única vez, de forma simbólica (SymPy), junto com
a dimensão física de cada símbolo. Isso dá três garantias:

1. A fórmula exibida no rastro é literalmente a mesma que foi avaliada —
   não há duas versões (uma para calcular, outra para mostrar).
2. As unidades de cada símbolo são verificadas antes da substituição.
3. Novas fórmulas são adicionadas ao sistema declarando um objeto aqui,
   sem tocar em API, banco ou interface.

IMPORTANTE: este módulo contém somente relações matemáticas gerais
(definições de carga, quantidade de matéria, rendimento, lei de Faraday).
Ele NÃO contém estequiometria de nenhuma reação específica. Coeficientes
estequiométricos e número de elétrons entram como símbolos cujo valor é
sempre fornecido pelo usuário.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Final

import sympy as sp

from .errors import DivisionByZeroError, FormulaError, ValidationError
from .formatting import significant
from .trace import Trace
from .units import Quantity, base_unit

# ---------------------------------------------------------------------------
# Constantes físicas
# ---------------------------------------------------------------------------

#: Constante de Faraday (CODATA 2018), em C/mol.
#: Valor exato derivado de e = 1.602176634e-19 C e N_A = 6.02214076e23 /mol.
FARADAY_CONSTANT: Final[float] = 96485.33212331001
FARADAY_REFERENCE: Final[str] = (
    "CODATA 2018 — F = e · N_A = 96485,33212... C/mol (valor exato por definição do SI)"
)


@dataclass(frozen=True, slots=True)
class SymbolSpec:
    """Descrição de um símbolo de uma fórmula."""

    symbol: str
    dimension: str
    description: str

    @property
    def base_unit(self) -> str:
        return base_unit(self.dimension)


@dataclass(frozen=True, slots=True)
class Formula:
    """Uma relação matemática avaliável e auditável."""

    id: str
    name: str
    lhs: str
    rhs: str
    result_dimension: str
    symbols: tuple[SymbolSpec, ...]
    description: str = ""
    reference: str = ""
    #: Símbolos que não podem valer zero por aparecerem em denominador.
    nonzero: tuple[str, ...] = field(default=())
    #: Unidade em que o membro direito já entrega o resultado, quando ela não
    #: é a unidade base da dimensão (caso de rendimentos, que a própria
    #: fórmula multiplica por 100 e portanto saem diretamente em "%").
    result_unit_override: str = ""

    # -- representação -----------------------------------------------------
    @property
    def _locals(self) -> dict[str, sp.Symbol]:
        """Símbolos declarados, forçados a serem símbolos livres.

        Sem isto, o SymPy interpretaria ``I`` como unidade imaginária e ``E``
        como número de Euler — exatamente os símbolos de corrente e energia.
        """
        names = {s.symbol for s in self.symbols} | {self.lhs}
        return {name: sp.Symbol(name) for name in names}

    @property
    def expression(self) -> sp.Expr:
        return sp.sympify(self.rhs, locals=self._locals)

    @property
    def text(self) -> str:
        return f"{self.lhs} = {self.rhs.replace('**', '^')}"

    @property
    def latex(self) -> str:
        lhs = sp.latex(sp.Symbol(self.lhs))
        return f"{lhs} = {sp.latex(self.expression)}"

    @property
    def result_unit(self) -> str:
        return self.result_unit_override or base_unit(self.result_dimension)

    def spec(self, symbol: str) -> SymbolSpec:
        for s in self.symbols:
            if s.symbol == symbol:
                return s
        raise FormulaError(f"A fórmula '{self.id}' não possui o símbolo '{symbol}'.")

    # -- avaliação ---------------------------------------------------------
    def evaluate(self, inputs: dict[str, Quantity],
                 trace_title: str | None = None) -> tuple[float, Trace]:
        """Avalia a fórmula e devolve (valor na unidade base, rastro).

        ``inputs`` mapeia cada símbolo para uma ``Quantity``. Toda quantidade
        é convertida para a unidade base da sua dimensão antes da substituição,
        de modo que o resultado sai sempre na unidade base coerente.
        """
        expected = {s.symbol for s in self.symbols}
        received = set(inputs)
        if missing := expected - received:
            raise FormulaError(
                f"Fórmula '{self.id}': faltam os símbolos {sorted(missing)}."
            )
        if extra := received - expected:
            raise FormulaError(
                f"Fórmula '{self.id}': símbolos não previstos {sorted(extra)}."
            )

        trace = Trace(
            title=trace_title or self.name,
            formula_id=self.id,
            formula_latex=self.latex,
            references=[self.reference] if self.reference else [],
        )

        # 1) Dados de entrada e conversões, na ordem declarada da fórmula.
        base_values: dict[str, float] = {}
        for spec in self.symbols:
            quantity = inputs[spec.symbol]
            if quantity.dimension != spec.dimension:
                raise FormulaError(
                    f"Fórmula '{self.id}': o símbolo '{spec.symbol}' exige "
                    f"dimensão '{spec.dimension}', mas recebeu "
                    f"'{quantity.dimension}'."
                )
            trace.input(
                f"{spec.symbol} — {spec.description}",
                quantity.value,
                quantity.unit,
            )
            if quantity.is_converted():
                trace.conversion(
                    f"Conversão de {spec.symbol}",
                    f"{significant(quantity.value)} {quantity.unit} = "
                    f"{significant(quantity.base_value)} {quantity.base_unit}",
                    quantity.base_value,
                    quantity.base_unit,
                )
            base_values[spec.symbol] = quantity.base_value

        # 2) Proteção contra divisão por zero, antes de avaliar.
        for symbol in self.nonzero:
            if base_values[symbol] == 0:
                raise DivisionByZeroError(
                    f"Fórmula '{self.text}': o símbolo '{symbol}' "
                    f"({self.spec(symbol).description}) está no denominador e "
                    "não pode ser zero."
                )

        # 3) Fórmula, substituição e resultado.
        trace.formula(self.text, self.description)

        substituted = self.rhs
        for symbol in sorted(base_values, key=len, reverse=True):
            substituted = substituted.replace(
                symbol, f"({significant(base_values[symbol])})"
            )
        trace.substitution(
            f"{self.lhs} = {substituted.replace('**', '^')}"
        )

        expr = self.expression
        value = float(expr.subs({sp.Symbol(k): v for k, v in base_values.items()}))
        trace.result(value, self.result_unit, f"{self.lhs}")
        return value, trace


# ---------------------------------------------------------------------------
# Catálogo
# ---------------------------------------------------------------------------

_S = SymbolSpec

FORMULAS: Final[dict[str, Formula]] = {}


def register(formula: Formula) -> Formula:
    if formula.id in FORMULAS:
        raise FormulaError(f"Fórmula duplicada: '{formula.id}'.")
    FORMULAS[formula.id] = formula
    return formula


def get(formula_id: str) -> Formula:
    try:
        return FORMULAS[formula_id]
    except KeyError as exc:
        raise FormulaError(f"Fórmula desconhecida: '{formula_id}'.") from exc


CHARGE_FROM_CURRENT_TIME = register(Formula(
    id="charge_from_current_time",
    name="Carga elétrica a partir de corrente e tempo",
    lhs="Q", rhs="I*t",
    result_dimension="charge",
    symbols=(
        _S("I", "current", "corrente aplicada"),
        _S("t", "time", "duração da eletrólise"),
    ),
    description="Definição de carga para corrente constante (modo galvanostático).",
    reference="Definição do coulomb: 1 C = 1 A · 1 s.",
))

MOLES_OF_ELECTRONS = register(Formula(
    id="moles_of_electrons",
    name="Quantidade de matéria de elétrons",
    lhs="n_e", rhs="Q/F",
    result_dimension="amount",
    symbols=(
        _S("Q", "charge", "carga elétrica que atravessou a célula"),
        _S("F", "faraday", "constante de Faraday"),
    ),
    description="Primeira lei de Faraday da eletrólise.",
    reference=FARADAY_REFERENCE,
    nonzero=("F",),
))

CHARGE_FROM_MOLES_OF_ELECTRONS = register(Formula(
    id="charge_from_moles_of_electrons",
    name="Carga a partir da quantidade de elétrons",
    lhs="Q", rhs="n_e*F",
    result_dimension="charge",
    symbols=(
        _S("n_e", "amount", "quantidade de matéria de elétrons"),
        _S("F", "faraday", "constante de Faraday"),
    ),
    description="Forma inversa da primeira lei de Faraday.",
    reference=FARADAY_REFERENCE,
))

AMOUNT_FROM_MASS = register(Formula(
    id="amount_from_mass",
    name="Quantidade de matéria a partir da massa",
    lhs="n", rhs="m/M",
    result_dimension="amount",
    symbols=(
        _S("m", "mass", "massa da substância"),
        _S("M", "molar_mass", "massa molar da substância"),
    ),
    description="Definição de quantidade de matéria.",
    nonzero=("M",),
))

MASS_FROM_AMOUNT = register(Formula(
    id="mass_from_amount",
    name="Massa a partir da quantidade de matéria",
    lhs="m", rhs="n*M",
    result_dimension="mass",
    symbols=(
        _S("n", "amount", "quantidade de matéria"),
        _S("M", "molar_mass", "massa molar"),
    ),
    description="Forma inversa da definição de quantidade de matéria.",
))

AMOUNT_FROM_CONCENTRATION = register(Formula(
    id="amount_from_concentration",
    name="Quantidade de matéria a partir de concentração e volume",
    lhs="n", rhs="c*V",
    result_dimension="amount",
    symbols=(
        _S("c", "concentration", "concentração em quantidade de matéria"),
        _S("V", "volume", "volume da solução"),
    ),
    description="Definição de concentração em quantidade de matéria.",
))

AMOUNT_FROM_STOICHIOMETRY = register(Formula(
    id="amount_from_stoichiometry",
    name="Quantidade de produto pela estequiometria",
    lhs="n_p", rhs="n_L*(nu_p/nu_L)",
    result_dimension="amount",
    symbols=(
        _S("n_L", "amount", "quantidade de matéria do reagente limitante"),
        _S("nu_p", "ratio", "coeficiente estequiométrico do produto"),
        _S("nu_L", "ratio", "coeficiente estequiométrico do reagente limitante"),
    ),
    description=(
        "Proporção estequiométrica. Os coeficientes são fornecidos pelo "
        "usuário a partir da equação balanceada do seu protocolo; o sistema "
        "não infere nenhuma estequiometria."
    ),
    nonzero=("nu_L",),
))

AMOUNT_FROM_CHARGE = register(Formula(
    id="amount_from_charge",
    name="Quantidade de produto pela carga (rota faradaica)",
    lhs="n_p", rhs="(Q*eta)/(z*F)",
    result_dimension="amount",
    symbols=(
        _S("Q", "charge", "carga total aplicada"),
        _S("eta", "ratio", "eficiência de corrente admitida"),
        _S("z", "ratio", "elétrons por mol de produto (fornecido pelo usuário)"),
        _S("F", "faraday", "constante de Faraday"),
    ),
    description=(
        "Primeira lei de Faraday aplicada ao produto. O valor de z depende do "
        "mecanismo da reação e deve vir do protocolo experimental ou da "
        "literatura; o sistema nunca o arbitra."
    ),
    reference=FARADAY_REFERENCE,
    nonzero=("z", "F"),
))

THEORETICAL_CHARGE = register(Formula(
    id="theoretical_charge",
    name="Carga teórica necessária",
    lhs="Q_th", rhs="n_p*z*F",
    result_dimension="charge",
    symbols=(
        _S("n_p", "amount", "quantidade de matéria de produto visada"),
        _S("z", "ratio", "elétrons por mol de produto"),
        _S("F", "faraday", "constante de Faraday"),
    ),
    description="Carga exigida para converter n_p mols com eficiência de 100 %.",
    reference=FARADAY_REFERENCE,
))

FARADAIC_EFFICIENCY = register(Formula(
    id="faradaic_efficiency",
    name="Eficiência faradaica / de corrente",
    lhs="eta", rhs="100*(n_exp*z*F)/Q",
    result_dimension="ratio",
    symbols=(
        _S("n_exp", "amount", "quantidade de matéria de produto obtida"),
        _S("z", "ratio", "elétrons por mol de produto"),
        _S("F", "faraday", "constante de Faraday"),
        _S("Q", "charge", "carga total que atravessou a célula"),
    ),
    description=(
        "Fração da carga total efetivamente convertida no produto de "
        "interesse, expressa em porcentagem."
    ),
    reference=FARADAY_REFERENCE,
    nonzero=("Q",),
    result_unit_override="%",
))

YIELD_BY_MASS = register(Formula(
    id="yield_by_mass",
    name="Rendimento em massa",
    lhs="Y_m", rhs="100*m_exp/m_th",
    result_dimension="ratio",
    symbols=(
        _S("m_exp", "mass", "massa de produto isolada (experimental)"),
        _S("m_th", "mass", "massa teórica de produto"),
    ),
    description=(
        "Definição por massa. Não deve ser misturada com a definição por "
        "quantidade de matéria na mesma comparação."
    ),
    nonzero=("m_th",),
    result_unit_override="%",
))

YIELD_BY_AMOUNT = register(Formula(
    id="yield_by_amount",
    name="Rendimento em quantidade de matéria",
    lhs="Y_n", rhs="100*n_exp/n_th",
    result_dimension="ratio",
    symbols=(
        _S("n_exp", "amount", "quantidade de matéria de produto obtida"),
        _S("n_th", "amount", "quantidade de matéria teórica de produto"),
    ),
    description=(
        "Definição por quantidade de matéria. Coincide numericamente com a "
        "definição por massa apenas quando ambas usam a mesma massa molar."
    ),
    nonzero=("n_th",),
    result_unit_override="%",
))

CHARGE_PER_MOLE = register(Formula(
    id="charge_per_mole",
    name="Carga por mol de substrato",
    lhs="q_m", rhs="Q/n_s",
    result_dimension="faraday",
    symbols=(
        _S("Q", "charge", "carga total aplicada"),
        _S("n_s", "amount", "quantidade de matéria de substrato"),
    ),
    description="Carga específica efetivamente aplicada por mol de substrato.",
    nonzero=("n_s",),
))

ELECTRONS_PER_MOLE_SUBSTRATE = register(Formula(
    id="electrons_per_mole_substrate",
    name="Elétrons por mol de substrato (observado)",
    lhs="z_obs", rhs="n_e/n_s",
    result_dimension="ratio",
    symbols=(
        _S("n_e", "amount", "quantidade de matéria de elétrons"),
        _S("n_s", "amount", "quantidade de matéria de substrato"),
    ),
    description=(
        "Razão observada entre elétrons fornecidos e substrato carregado. É "
        "uma grandeza medida, não uma dedução de mecanismo."
    ),
    nonzero=("n_s",),
))

SPECIFIC_ENERGY = register(Formula(
    id="electrical_energy",
    name="Energia elétrica consumida",
    lhs="E", rhs="U*Q",
    result_dimension="energy",
    symbols=(
        _S("U", "voltage", "tensão média da célula"),
        _S("Q", "charge", "carga total"),
    ),
    description="Válida para tensão aproximadamente constante durante o ensaio.",
))

CONVERSION_FRACTION = register(Formula(
    id="substrate_conversion",
    name="Conversão do substrato",
    lhs="X", rhs="100*(n_0-n_f)/n_0",
    result_dimension="ratio",
    symbols=(
        _S("n_0", "amount", "quantidade inicial de substrato"),
        _S("n_f", "amount", "quantidade final de substrato recuperada"),
    ),
    description="Fração do substrato consumida, em porcentagem.",
    nonzero=("n_0",),
    result_unit_override="%",
))


def catalog() -> list[dict[str, object]]:
    """Catálogo serializável, consumido pela API e pela documentação."""
    return [
        {
            "id": f.id,
            "name": f.name,
            "text": f.text,
            "latex": f.latex,
            "result_dimension": f.result_dimension,
            "result_unit": f.result_unit,
            "description": f.description,
            "reference": f.reference,
            "symbols": [
                {
                    "symbol": s.symbol,
                    "dimension": s.dimension,
                    "base_unit": s.base_unit,
                    "description": s.description,
                }
                for s in f.symbols
            ],
        }
        for f in FORMULAS.values()
    ]


def ratio(value: float, unit: str = "fraction") -> Quantity:
    """Atalho para grandezas adimensionais (coeficientes, z, eficiência)."""
    if value < 0:
        raise ValidationError("Valores adimensionais não podem ser negativos.")
    return Quantity.create(value, unit, "ratio")


def faraday(value: float = FARADAY_CONSTANT) -> Quantity:
    return Quantity.create(value, "C/mol", "faraday")
