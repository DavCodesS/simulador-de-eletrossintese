"""Regras de validação reutilizáveis.

Guardas numéricas que aparecem repetidamente na descrição de um experimento.
Ficam aqui para que a mensagem de erro de uma mesma regra seja idêntica em
todo o sistema, e para que uma mudança de política (por exemplo, passar a
aceitar corrente negativa em ensaios catódicos) aconteça em um lugar só.

Todas ignoram ``None``: ausência de dado não é erro de validação — é o que
faz o resultado sair como "não calculável".
"""

from __future__ import annotations

from .errors import ValidationError


def non_negative(value: float | None, label: str, field: str) -> None:
    """Aceita zero, rejeita negativos. Para massas e cargas."""
    if value is not None and value < 0:
        raise ValidationError(f"{label} não pode ser negativa.", field)


def positive(value: float | None, label: str, field: str) -> None:
    """Rejeita zero e negativos. Para tempo, massa molar e coeficientes."""
    if value is not None and value <= 0:
        raise ValidationError(f"{label} deve ser maior que zero.", field)


def in_range(value: float | None, low: float, high: float,
             label: str, field: str, unit: str = "") -> None:
    """Faixa fechada. Para eficiências e frações."""
    if value is not None and not low <= value <= high:
        suffix = f" {unit}" if unit else ""
        raise ValidationError(
            f"{label} deve estar entre {low}{suffix} e {high}{suffix}.", field)


def required(value: object, label: str, field: str) -> None:
    """Exige presença. Usado só onde a ausência impede até o registro."""
    if value is None or (isinstance(value, str) and not value.strip()):
        raise ValidationError(f"{label} é obrigatório.", field)


def unique_names(names: list[str], label: str, field: str) -> None:
    """Nomes distintos, sem diferenciar maiúsculas."""
    normalized = [name.strip().lower() for name in names]
    duplicates = {name for name in normalized if normalized.count(name) > 1}
    if duplicates:
        raise ValidationError(
            f"{label}: nomes repetidos ({', '.join(sorted(duplicates))}). "
            "Os nomes precisam ser únicos para identificar cada substância.",
            field)


def one_of(value: str, options: tuple[str, ...], label: str,
           field: str) -> None:
    """Valor restrito a um conjunto conhecido."""
    if value not in options:
        raise ValidationError(
            f"{label} deve ser um destes: {', '.join(options)}.", field)


def member_of(value: str, names: list[str], label: str, field: str) -> None:
    """Referência cruzada a um nome declarado em outro lugar."""
    if value and value.strip().lower() not in [n.strip().lower() for n in names]:
        raise ValidationError(
            f"{label} '{value}' não está na lista de reagentes.", field)
