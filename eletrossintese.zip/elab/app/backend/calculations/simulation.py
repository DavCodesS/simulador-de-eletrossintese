"""Simulação e análise de cenários.

Duas operações, ambas construídas sobre ``engine.run`` — nenhuma fórmula é
reimplementada aqui, de modo que simulação e cálculo pontual não podem
divergir.

* ``sweep``     — varre um parâmetro em N pontos e devolve as séries.
* ``scenarios`` — avalia uma lista de conjuntos de alterações.

Os valores produzidos são projeções aritméticas das fórmulas com os
parâmetros informados. Não são previsões de comportamento experimental, e a
resposta carrega essa ressalva explicitamente.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from .engine import ExperimentResults, run
from .errors import ValidationError
from .spec import ExperimentSpec

PROJECTION_DISCLAIMER = (
    "Valores projetados aritmeticamente a partir das fórmulas e dos "
    "parâmetros informados. Não constituem previsão de resultado "
    "experimental."
)

#: Parâmetros que podem ser varridos, com rótulo e unidade de referência.
SWEEPABLE: dict[str, dict[str, str]] = {
    "electro.current": {"label": "Corrente", "unit_field": "electro.current_unit"},
    "electro.time": {"label": "Tempo", "unit_field": "electro.time_unit"},
    "electro.voltage": {"label": "Tensão", "unit_field": "electro.voltage_unit"},
    "electro.assumed_current_efficiency": {
        "label": "Eficiência admitida",
        "unit_field": "electro.assumed_current_efficiency_unit"},
    "product.electrons_per_mol": {"label": "Elétrons por mol (z)", "unit_field": ""},
    "product.stoich_coefficient": {
        "label": "Coeficiente do produto", "unit_field": ""},
    "product.molar_mass": {"label": "Massa molar do produto", "unit_field": ""},
}


def _resolve(spec: ExperimentSpec, path: str) -> tuple[Any, str]:
    """Resolve um caminho pontilhado, inclusive ``reagents[nome].campo``."""
    parts = path.split(".")
    target: Any = spec
    for part in parts[:-1]:
        if part.startswith("reagents[") and part.endswith("]"):
            name = part[len("reagents["):-1].strip().strip("'\"")
            match = next((r for r in spec.reagents
                          if r.name.strip().lower() == name.lower()), None)
            if match is None:
                raise ValidationError(f"Reagente '{name}' não encontrado.", path)
            target = match
        else:
            if not hasattr(target, part):
                raise ValidationError(f"Caminho inválido: '{path}'.", path)
            target = getattr(target, part)
    if not hasattr(target, parts[-1]):
        raise ValidationError(f"Caminho inválido: '{path}'.", path)
    return target, parts[-1]


def apply_overrides(spec: ExperimentSpec,
                    overrides: dict[str, Any]) -> ExperimentSpec:
    """Devolve uma cópia do spec com os campos indicados substituídos."""
    clone = copy.deepcopy(spec)
    for path, value in (overrides or {}).items():
        target, attribute = _resolve(clone, path)
        setattr(target, attribute, value)
    return clone


def _unit_for(spec: ExperimentSpec, parameter: str) -> str:
    meta = SWEEPABLE.get(parameter)
    if not meta or not meta["unit_field"]:
        return ""
    target, attribute = _resolve(spec, meta["unit_field"])
    return str(getattr(target, attribute) or "")


@dataclass(slots=True)
class SweepResult:
    parameter: str
    label: str
    unit: str
    values: list[float]
    series: dict[str, list[float | None]]
    errors: list[str | None] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "parameter": self.parameter,
            "label": self.label,
            "unit": self.unit,
            "values": self.values,
            "series": self.series,
            "errors": self.errors,
            "disclaimer": PROJECTION_DISCLAIMER,
        }


#: Métricas devolvidas por ponto de varredura.
TRACKED_METRICS = (
    "charge", "moles_electrons", "theoretical_amount",
    "theoretical_amount_stoich", "theoretical_amount_faradaic",
    "theoretical_mass", "yield_mass", "yield_amount", "yield_primary",
    "faradaic_efficiency", "theoretical_charge", "charge_per_mole",
    "electrons_per_substrate", "energy",
)


def sweep(spec: ExperimentSpec, parameter: str, start: float, stop: float,
          points: int = 25) -> SweepResult:
    """Varre um parâmetro entre ``start`` e ``stop`` em ``points`` pontos."""
    if parameter not in SWEEPABLE:
        raise ValidationError(
            f"Parâmetro '{parameter}' não é varrível. Opções: "
            f"{sorted(SWEEPABLE)}", "parameter")
    if points < 2:
        raise ValidationError("A varredura exige pelo menos 2 pontos.", "points")
    if points > 500:
        raise ValidationError("Máximo de 500 pontos por varredura.", "points")
    if start < 0 or stop < 0:
        raise ValidationError(
            "Os limites da varredura não podem ser negativos.", "start/stop")

    grid = np.linspace(float(start), float(stop), int(points))
    series: dict[str, list[float | None]] = {m: [] for m in TRACKED_METRICS}
    errors: list[str | None] = []

    for raw in grid:
        candidate = apply_overrides(spec, {parameter: float(raw)})
        try:
            results = run(candidate)
        except Exception as exc:  # ponto inválido não interrompe a varredura
            errors.append(str(exc))
            for metric in TRACKED_METRICS:
                series[metric].append(None)
            continue
        errors.append(None)
        summary = results.summary()
        for metric in TRACKED_METRICS:
            series[metric].append(summary.get(metric))

    return SweepResult(
        parameter=parameter,
        label=SWEEPABLE[parameter]["label"],
        unit=_unit_for(spec, parameter),
        values=[float(v) for v in grid],
        series=series,
        errors=errors,
    )


@dataclass(slots=True)
class Scenario:
    name: str
    overrides: dict[str, Any]
    results: ExperimentResults | None = None
    error: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "overrides": self.overrides,
            "error": self.error,
            "summary": self.results.summary() if self.results else None,
            "warnings": self.results.warnings if self.results else [],
        }


def scenarios(spec: ExperimentSpec,
              definitions: list[dict[str, Any]]) -> list[Scenario]:
    """Avalia uma lista de cenários derivados de um mesmo experimento base."""
    evaluated: list[Scenario] = []
    for index, definition in enumerate(definitions or [], start=1):
        name = str(definition.get("name") or f"Cenário {index}")
        overrides = definition.get("overrides") or {}
        scenario = Scenario(name=name, overrides=overrides)
        try:
            scenario.results = run(apply_overrides(spec, overrides))
        except Exception as exc:
            scenario.error = str(exc)
        evaluated.append(scenario)
    return evaluated


def compare(results: list[tuple[str, ExperimentResults]]) -> dict[str, Any]:
    """Tabela comparativa entre experimentos já calculados.

    A diferença percentual só é calculada quando a referência é não nula e a
    grandeza é razão-invariante; caso contrário sai ``None``.
    """
    if len(results) < 2:
        raise ValidationError(
            "A comparação exige pelo menos dois experimentos.", "ids")

    labels: dict[str, str] = {}
    for _, res in results:
        for key, outcome in res.outcomes.items():
            labels.setdefault(key, outcome.label)

    rows = []
    reference_name, reference = results[0]
    for key, label in labels.items():
        values = []
        for _, res in results:
            outcome = res.outcomes.get(key)
            values.append({
                "value": outcome.value if outcome and outcome.is_ok else None,
                "unit": outcome.unit if outcome else "",
                "status": outcome.status if outcome else "not_calculable",
            })
        base = values[0]["value"]
        for entry in values[1:]:
            if base is None or entry["value"] is None:
                entry["delta"] = None
                entry["delta_percent"] = None
            else:
                entry["delta"] = entry["value"] - base
                entry["delta_percent"] = (
                    None if base == 0 else 100.0 * (entry["value"] - base) / base
                )
        rows.append({"key": key, "label": label, "values": values})

    return {
        "experiments": [name for name, _ in results],
        "reference": reference_name,
        "rows": rows,
    }
