"""Estruturas de entrada do motor de cálculo.

São dataclasses puras: não dependem de FastAPI, de SQLAlchemy nem de HTTP.
O motor de cálculo pode ser importado e usado em um script ou num notebook
sem subir a aplicação web.

Nenhum campo químico possui valor padrão "razoável". Coeficientes
estequiométricos, número de elétrons por mol e eficiência de corrente são
sempre ``None`` até que o usuário os forneça — o que faz o resultado
correspondente sair como ``not_calculable`` em vez de sair errado.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from . import rules
from .errors import ValidationError
from .formulas import FARADAY_CONSTANT
from .units import Quantity

YieldDefinition = Literal["mass", "amount"]
TheoreticalBasis = Literal["stoichiometric", "faradaic"]


def _quantity(value: float | None, unit: str | None,
              dimension: str) -> Quantity | None:
    """Constrói uma ``Quantity`` ou devolve ``None`` se o dado não existe."""
    if value is None or unit in (None, ""):
        return None
    return Quantity.create(float(value), str(unit), dimension)


@dataclass(slots=True)
class ReagentSpec:
    """Um reagente declarado pelo usuário.

    A quantidade pode ser informada de três maneiras mutuamente
    complementares: massa + massa molar, quantidade de matéria direta, ou
    concentração + volume. O motor usa a primeira via disponível e registra
    no rastro qual delas foi usada.
    """

    name: str
    molar_mass: float | None = None            # g/mol
    mass: float | None = None
    mass_unit: str = "mg"
    amount: float | None = None
    amount_unit: str = "mmol"
    concentration: float | None = None
    concentration_unit: str = "mol/L"
    volume: float | None = None
    volume_unit: str = "mL"
    stoich_coefficient: float | None = None
    formula: str = ""
    role: str = "reagent"
    notes: str = ""

    # -- acesso tipado -----------------------------------------------------
    @property
    def molar_mass_q(self) -> Quantity | None:
        return _quantity(self.molar_mass, "g/mol", "molar_mass")

    @property
    def mass_q(self) -> Quantity | None:
        return _quantity(self.mass, self.mass_unit, "mass")

    @property
    def amount_q(self) -> Quantity | None:
        return _quantity(self.amount, self.amount_unit, "amount")

    @property
    def concentration_q(self) -> Quantity | None:
        return _quantity(self.concentration, self.concentration_unit,
                         "concentration")

    @property
    def volume_q(self) -> Quantity | None:
        return _quantity(self.volume, self.volume_unit, "volume")

    def validate(self) -> None:
        rules.required(self.name, "O nome do reagente", "name")
        who = f"'{self.name}'"
        rules.non_negative(self.mass, f"{who}: a massa", "mass")
        rules.non_negative(self.amount, f"{who}: a quantidade de matéria",
                           "amount")
        rules.non_negative(self.concentration, f"{who}: a concentração",
                           "concentration")
        rules.non_negative(self.volume, f"{who}: o volume", "volume")
        rules.positive(self.molar_mass, f"{who}: a massa molar", "molar_mass")
        rules.positive(self.stoich_coefficient,
                       f"{who}: o coeficiente estequiométrico",
                       "stoich_coefficient")


@dataclass(slots=True)
class ProductSpec:
    """O produto de interesse."""

    name: str = "Produto"
    formula: str = ""
    molar_mass: float | None = None            # g/mol
    stoich_coefficient: float | None = None
    #: Elétrons consumidos por mol de produto. Depende do mecanismo da
    #: reação; deve vir do protocolo do usuário. Nunca é inferido.
    electrons_per_mol: float | None = None
    experimental_mass: float | None = None
    experimental_mass_unit: str = "mg"
    experimental_amount: float | None = None
    experimental_amount_unit: str = "mmol"
    notes: str = ""

    @property
    def molar_mass_q(self) -> Quantity | None:
        return _quantity(self.molar_mass, "g/mol", "molar_mass")

    @property
    def experimental_mass_q(self) -> Quantity | None:
        return _quantity(self.experimental_mass, self.experimental_mass_unit,
                         "mass")

    @property
    def experimental_amount_q(self) -> Quantity | None:
        return _quantity(self.experimental_amount,
                         self.experimental_amount_unit, "amount")

    def validate(self) -> None:
        rules.positive(self.molar_mass, "A massa molar do produto",
                       "product.molar_mass")
        rules.positive(self.electrons_per_mol,
                       "O número de elétrons por mol de produto",
                       "product.electrons_per_mol")
        rules.positive(self.stoich_coefficient,
                       "O coeficiente estequiométrico do produto",
                       "product.stoich_coefficient")
        rules.non_negative(self.experimental_mass,
                           "A massa experimental do produto",
                           "product.experimental_mass")
        rules.non_negative(self.experimental_amount,
                           "A quantidade experimental do produto",
                           "product.experimental_amount")


@dataclass(slots=True)
class ElectroSpec:
    """Parâmetros elétricos do ensaio."""

    current: float | None = None
    current_unit: str = "mA"
    time: float | None = None
    time_unit: str = "min"
    voltage: float | None = None
    voltage_unit: str = "V"
    #: Carga medida por um coulômetro. Quando presente, é usada em vez de
    #: I × t, e o motor registra isso explicitamente no rastro.
    measured_charge: float | None = None
    measured_charge_unit: str = "C"
    faraday_constant: float = FARADAY_CONSTANT
    #: Eficiência de corrente ADMITIDA, usada apenas na rota faradaica e na
    #: simulação. Não se confunde com a eficiência faradaica CALCULADA a
    #: partir do produto isolado.
    assumed_current_efficiency: float | None = None
    assumed_current_efficiency_unit: str = "%"
    notes: str = ""

    @property
    def current_q(self) -> Quantity | None:
        return _quantity(self.current, self.current_unit, "current")

    @property
    def time_q(self) -> Quantity | None:
        return _quantity(self.time, self.time_unit, "time")

    @property
    def voltage_q(self) -> Quantity | None:
        return _quantity(self.voltage, self.voltage_unit, "voltage")

    @property
    def measured_charge_q(self) -> Quantity | None:
        return _quantity(self.measured_charge, self.measured_charge_unit,
                         "charge")

    @property
    def faraday_q(self) -> Quantity:
        return Quantity.create(self.faraday_constant, "C/mol", "faraday")

    @property
    def assumed_efficiency_q(self) -> Quantity | None:
        return _quantity(self.assumed_current_efficiency,
                         self.assumed_current_efficiency_unit, "ratio")

    def validate(self) -> None:
        rules.non_negative(self.current, "A corrente", "electro.current")
        rules.non_negative(self.measured_charge, "A carga medida",
                           "electro.measured_charge")
        rules.non_negative(self.voltage, "A tensão", "electro.voltage")
        rules.positive(self.time, "O tempo", "electro.time")
        rules.positive(self.faraday_constant, "A constante de Faraday",
                       "electro.faraday_constant")
        efficiency = self.assumed_efficiency_q
        if efficiency is not None:
            rules.in_range(efficiency.base_value, 0.0, 1.0,
                           "A eficiência de corrente admitida",
                           "electro.assumed_current_efficiency")


@dataclass(slots=True)
class ExperimentSpec:
    """Descrição completa de um experimento, pronta para cálculo."""

    name: str = "Experimento sem nome"
    identifier: str = ""
    date: str = ""
    reference: str = ""
    notes: str = ""
    reagents: list[ReagentSpec] = field(default_factory=list)
    product: ProductSpec = field(default_factory=ProductSpec)
    electro: ElectroSpec = field(default_factory=ElectroSpec)
    #: Nome do reagente tratado como substrato nas métricas por mol de
    #: substrato. Se vazio, o motor usa o reagente limitante determinado.
    substrate_name: str = ""
    #: "auto" ou o nome de um reagente, quando o usuário quer forçar qual é
    #: o limitante (por exemplo, por conhecimento do sistema real).
    limiting_selection: str = "auto"
    #: Qual definição de rendimento reportar como principal.
    yield_definition: YieldDefinition = "mass"
    #: Qual rota usar como quantidade teórica de referência do rendimento.
    theoretical_basis: TheoreticalBasis = "stoichiometric"

    def validate(self) -> None:
        for reagent in self.reagents:
            reagent.validate()
        self.product.validate()
        self.electro.validate()

        names = [reagent.name for reagent in self.reagents]
        rules.unique_names(names, "Lista de reagentes", "reagents")
        if self.limiting_selection not in ("auto", ""):
            rules.member_of(self.limiting_selection, names,
                            "O reagente escolhido como limitante",
                            "limiting_selection")
        rules.member_of(self.substrate_name, names, "O substrato",
                        "substrate_name")
        rules.one_of(self.yield_definition, ("mass", "amount"),
                     "A definição de rendimento", "yield_definition")
        rules.one_of(self.theoretical_basis,
                     ("stoichiometric", "faradaic"),
                     "A base da quantidade teórica", "theoretical_basis")

    # -- serialização ------------------------------------------------------
    def as_dict(self) -> dict[str, Any]:
        from dataclasses import asdict
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExperimentSpec":
        data = dict(data or {})
        reagents = [ReagentSpec(**r) for r in data.pop("reagents", []) or []]
        product = ProductSpec(**(data.pop("product", None) or {}))
        electro = ElectroSpec(**(data.pop("electro", None) or {}))
        known = {f for f in cls.__slots__}
        clean = {k: v for k, v in data.items() if k in known}
        return cls(reagents=reagents, product=product, electro=electro, **clean)
