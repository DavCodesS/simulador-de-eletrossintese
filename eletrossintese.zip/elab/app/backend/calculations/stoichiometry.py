"""Estequiometria e reagente limitante.

Este módulo aplica proporções estequiométricas, mas NÃO conhece nenhuma
reação. Os coeficientes vêm inteiramente da equação balanceada informada
pelo usuário. Se um coeficiente faltar, o reagente é excluído da análise e
isso é reportado — nunca substituído por 1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from . import formulas as F
from .errors import ValidationError
from .formatting import significant
from .spec import ReagentSpec
from .trace import Outcome, Step, StepKind, Trace
from .units import Quantity


@dataclass(slots=True)
class ReagentAmount:
    """Quantidade de matéria de um reagente, com a origem do cálculo."""

    name: str
    amount_mol: float | None
    source: str                      # "massa", "quantidade informada", "c x V"
    stoich_coefficient: float | None
    trace: Trace | None = None
    excluded_reason: str = ""

    @property
    def usable(self) -> bool:
        return (self.amount_mol is not None
                and self.stoich_coefficient is not None
                and self.stoich_coefficient > 0)

    @property
    def extent(self) -> float | None:
        """Avanço máximo de reação permitido por este reagente (ξ = n / ν)."""
        if not self.usable:
            return None
        return self.amount_mol / self.stoich_coefficient  # type: ignore[operator]

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "amount_mol": self.amount_mol,
            "source": self.source,
            "stoich_coefficient": self.stoich_coefficient,
            "extent": self.extent,
            "usable": self.usable,
            "excluded_reason": self.excluded_reason,
            "trace": self.trace.as_dict() if self.trace else None,
        }


def amount_of(reagent: ReagentSpec) -> ReagentAmount:
    """Determina a quantidade de matéria de um reagente.

    Ordem de preferência, sempre registrada no rastro:
      1. quantidade de matéria informada diretamente;
      2. massa e massa molar (n = m / M);
      3. concentração e volume (n = c · V).
    """
    trace = Trace(title=f"Quantidade de matéria de {reagent.name}")

    amount = reagent.amount_q
    if amount is not None:
        trace.input(f"n({reagent.name}) informado diretamente",
                    amount.value, amount.unit)
        if amount.is_converted():
            trace.conversion(
                "Conversão",
                f"{significant(amount.value)} {amount.unit} = "
                f"{significant(amount.base_value)} mol",
                amount.base_value, "mol")
        trace.result(amount.base_value, "mol", f"n({reagent.name})")
        return ReagentAmount(reagent.name, amount.base_value,
                             "quantidade de matéria informada",
                             reagent.stoich_coefficient, trace)

    mass, molar_mass = reagent.mass_q, reagent.molar_mass_q
    if mass is not None and molar_mass is not None:
        value, sub_trace = F.AMOUNT_FROM_MASS.evaluate(
            {"m": mass, "M": molar_mass},
            trace_title=f"Quantidade de matéria de {reagent.name}")
        return ReagentAmount(reagent.name, value, "massa e massa molar",
                             reagent.stoich_coefficient, sub_trace)

    concentration, volume = reagent.concentration_q, reagent.volume_q
    if concentration is not None and volume is not None:
        value, sub_trace = F.AMOUNT_FROM_CONCENTRATION.evaluate(
            {"c": concentration, "V": volume},
            trace_title=f"Quantidade de matéria de {reagent.name}")
        return ReagentAmount(reagent.name, value, "concentração e volume",
                             reagent.stoich_coefficient, sub_trace)

    return ReagentAmount(
        reagent.name, None, "indisponível", reagent.stoich_coefficient,
        None,
        "Informe a quantidade de matéria, ou massa + massa molar, ou "
        "concentração + volume.",
    )


@dataclass(slots=True)
class LimitingAnalysis:
    """Resultado completo da análise de reagente limitante."""

    status: str                                  # calculated | not_calculable
    limiting_name: str | None = None
    extent_mol: float | None = None              # ξ, avanço máximo
    amounts: list[ReagentAmount] = field(default_factory=list)
    trace: Trace | None = None
    reason: str = ""
    forced: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "limiting_name": self.limiting_name,
            "extent_mol": self.extent_mol,
            "forced": self.forced,
            "reason": self.reason,
            "reagents": [a.as_dict() for a in self.amounts],
            "trace": self.trace.as_dict() if self.trace else None,
        }


def analyse_limiting(reagents: list[ReagentSpec],
                     forced_name: str = "auto") -> LimitingAnalysis:
    """Determina o reagente limitante entre os reagentes DECLARADOS.

    O sistema não decide quais substâncias participam da reação: analisa
    exatamente a lista fornecida. Se o usuário declarar um único reagente, o
    resultado é trivialmente esse reagente, e o rastro deixa isso explícito.
    """
    amounts = [amount_of(r) for r in reagents]
    trace = Trace(title="Determinação do reagente limitante")

    if not reagents:
        return LimitingAnalysis(
            "not_calculable",
            reason="Nenhum reagente foi declarado.",
            amounts=amounts)

    trace.assumption(
        "Escopo da análise",
        "Considerados apenas os reagentes declarados pelo usuário: "
        + ", ".join(r.name for r in reagents) + ".")

    # 1) Conversão de tudo para mol.
    for entry in amounts:
        if entry.trace is not None:
            trace.extend(entry.trace, f"Etapa 1 — n({entry.name})")
        else:
            trace.add(Step(
                StepKind.ASSUMPTION, f"n({entry.name})",
                note=f"Excluído da análise. {entry.excluded_reason}"))

    usable = [a for a in amounts if a.usable]
    if not usable:
        missing = [a.name for a in amounts if not a.usable]
        return LimitingAnalysis(
            "not_calculable",
            reason=(
                "Nenhum reagente possui simultaneamente quantidade de matéria "
                "e coeficiente estequiométrico. Pendentes: "
                + ", ".join(missing) + "."),
            amounts=amounts, trace=trace)

    # 2) Aplicação dos coeficientes: ξ_i = n_i / ν_i
    trace.formula("xi_i = n_i / nu_i",
                  "Avanço de reação permitido por cada reagente. O menor "
                  "valor identifica o limitante.")
    for entry in usable:
        trace.substitution(
            f"xi({entry.name}) = {significant(entry.amount_mol)} / "
            f"{significant(entry.stoich_coefficient)} = "
            f"{significant(entry.extent)} mol")

    # 3) Escolha do limitante.
    forced = bool(forced_name) and forced_name != "auto"
    if forced:
        chosen = next(
            (a for a in usable
             if a.name.strip().lower() == forced_name.strip().lower()), None)
        if chosen is None:
            raise ValidationError(
                f"O reagente '{forced_name}' foi forçado como limitante, mas "
                "não possui dados suficientes para o cálculo.",
                "limiting_selection")
        trace.assumption(
            "Limitante definido pelo usuário",
            f"O usuário fixou '{chosen.name}' como limitante; o critério "
            "do menor avanço não foi aplicado.")
    else:
        chosen = min(usable, key=lambda a: a.extent)  # type: ignore[arg-type]
        trace.add(Step(
            StepKind.INTERMEDIATE, "Critério",
            expression="limitante = argmin(xi_i)",
            note=f"Menor avanço: {chosen.name}."))

    if len(usable) == 1 and not forced:
        trace.assumption(
            "Atenção",
            "Apenas um reagente reúne os dados necessários; ele é o "
            "limitante por construção, não por comparação.")

    trace.result(chosen.extent, "mol", f"xi máximo ({chosen.name})")
    return LimitingAnalysis("calculated", chosen.name, chosen.extent,
                            amounts, trace, forced=forced)


def theoretical_amount_from_stoichiometry(
        analysis: LimitingAnalysis,
        product_coefficient: float | None,
        product_name: str = "produto") -> Outcome:
    """Quantidade teórica máxima de produto: n_p = ξ · ν_p."""
    key, label = "theoretical_amount_stoich", "Quantidade teórica (estequiometria)"
    missing: list[str] = []
    if analysis.status != "calculated":
        missing.append("reagente limitante")
    if product_coefficient is None:
        missing.append("coeficiente estequiométrico do produto")
    if missing:
        reason = (analysis.reason if analysis.status != "calculated" else "")
        return Outcome.missing_data(key, label, missing, reason)

    limiting = next(a for a in analysis.amounts if a.name == analysis.limiting_name)
    value, trace = F.AMOUNT_FROM_STOICHIOMETRY.evaluate(
        {
            "n_L": Quantity.create(limiting.amount_mol, "mol"),
            "nu_p": F.ratio(product_coefficient),
            "nu_L": F.ratio(limiting.stoich_coefficient),
        },
        trace_title=f"Quantidade teórica de {product_name} pela estequiometria",
    )
    trace.steps.insert(0, Step(
        StepKind.ASSUMPTION, "Reagente limitante",
        note=f"'{analysis.limiting_name}', determinado na etapa anterior."))
    return Outcome.ok(key, label, value, "mol", trace)
