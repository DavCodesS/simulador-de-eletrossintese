"""Rastreamento de cálculos ("Como foi calculado?").

Princípio central do projeto: o rastro NÃO é reconstruído pela interface a
partir do resultado. Ele é produzido pela mesma função que produz o número.
Assim é impossível o rastro divergir do valor apresentado.

Cada cálculo devolve um ``Outcome``, que é uma de duas coisas:

* ``status = "calculated"``  -> possui ``value``, ``unit`` e ``trace``;
* ``status = "not_calculable"`` -> possui ``reason`` e ``missing``,
  e ``value`` é ``None``.

Não existe terceiro estado. Um parâmetro que não pôde ser calculado nunca
recebe zero, média, estimativa ou valor padrão.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal


class StepKind(str, Enum):
    """Tipo de cada linha exibida no rastro."""

    INPUT = "input"                # dado fornecido pelo usuário
    CONVERSION = "conversion"      # conversão de unidade
    CONSTANT = "constant"          # constante física utilizada
    ASSUMPTION = "assumption"      # escolha de configuração feita pelo usuário
    FORMULA = "formula"            # fórmula simbólica
    SUBSTITUTION = "substitution"  # fórmula com os números substituídos
    INTERMEDIATE = "intermediate"  # resultado parcial reaproveitado
    RESULT = "result"              # valor final


@dataclass(frozen=True, slots=True)
class Step:
    """Uma linha do rastro de cálculo."""

    kind: StepKind
    label: str
    expression: str = ""
    value: float | None = None
    unit: str = ""
    note: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "label": self.label,
            "expression": self.expression,
            "value": self.value,
            "unit": self.unit,
            "note": self.note,
        }


@dataclass(slots=True)
class Trace:
    """Sequência auditável de passos que leva a um resultado."""

    title: str
    formula_id: str | None = None
    formula_latex: str | None = None
    steps: list[Step] = field(default_factory=list)
    references: list[str] = field(default_factory=list)

    def add(self, step: Step) -> "Trace":
        self.steps.append(step)
        return self

    def input(self, label: str, value: float, unit: str, note: str = "") -> "Trace":
        return self.add(Step(StepKind.INPUT, label, value=value, unit=unit, note=note))

    def conversion(self, label: str, expression: str, value: float,
                   unit: str) -> "Trace":
        return self.add(
            Step(StepKind.CONVERSION, label, expression=expression,
                 value=value, unit=unit)
        )

    def constant(self, label: str, value: float, unit: str, note: str = "") -> "Trace":
        return self.add(
            Step(StepKind.CONSTANT, label, value=value, unit=unit, note=note)
        )

    def assumption(self, label: str, note: str) -> "Trace":
        return self.add(Step(StepKind.ASSUMPTION, label, note=note))

    def formula(self, expression: str, note: str = "") -> "Trace":
        return self.add(Step(StepKind.FORMULA, "Fórmula",
                             expression=expression, note=note))

    def substitution(self, expression: str) -> "Trace":
        return self.add(Step(StepKind.SUBSTITUTION, "Substituição",
                             expression=expression))

    def result(self, value: float, unit: str, label: str = "Resultado") -> "Trace":
        return self.add(Step(StepKind.RESULT, label, value=value, unit=unit))

    def extend(self, other: "Trace", label: str | None = None) -> "Trace":
        """Incorpora os passos de outro rastro como etapa intermediária.

        Usado quando um resultado depende de outro já calculado, de modo que
        a auditoria seja completa desde os dados brutos.
        """
        self.add(
            Step(StepKind.INTERMEDIATE, label or other.title,
                 note="Detalhamento abaixo")
        )
        self.steps.extend(other.steps)
        return self

    def as_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "formula_id": self.formula_id,
            "formula_latex": self.formula_latex,
            "steps": [s.as_dict() for s in self.steps],
            "references": self.references,
        }


Status = Literal["calculated", "not_calculable"]


@dataclass(slots=True)
class Outcome:
    """Resultado de um cálculo, calculável ou não."""

    key: str
    label: str
    status: Status
    value: float | None = None
    unit: str = ""
    trace: Trace | None = None
    reason: str = ""
    missing: list[str] = field(default_factory=list)
    kind: Literal["calculated", "experimental", "input"] = "calculated"

    @classmethod
    def ok(cls, key: str, label: str, value: float, unit: str, trace: Trace,
           kind: str = "calculated") -> "Outcome":
        return cls(key=key, label=label, status="calculated", value=value,
                   unit=unit, trace=trace, kind=kind)  # type: ignore[arg-type]

    @classmethod
    def missing_data(cls, key: str, label: str, missing: list[str],
                     reason: str = "") -> "Outcome":
        pretty = ", ".join(missing)
        return cls(
            key=key,
            label=label,
            status="not_calculable",
            reason=reason or f"Não calculável: faltam os dados: {pretty}.",
            missing=list(missing),
        )

    @property
    def is_ok(self) -> bool:
        return self.status == "calculated"

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "label": self.label,
            "status": self.status,
            "value": self.value,
            "unit": self.unit,
            "kind": self.kind,
            "reason": self.reason,
            "missing": self.missing,
            "trace": self.trace.as_dict() if self.trace else None,
        }
