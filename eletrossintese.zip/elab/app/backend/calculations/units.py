"""Camada de unidades.

Responsabilidade única: converter valores entre unidades da MESMA dimensão
física e expor a unidade base (SI) de cada dimensão.

Esta camada não conhece química, estequiometria nem eletroquímica.
Ela apenas garante que qualquer número que entre no motor de cálculo
esteja em uma unidade base conhecida antes de qualquer operação.

Regra de precisão: as conversões são multiplicações por fatores exatos e
NUNCA arredondam. Arredondamento é responsabilidade exclusiva da camada de
apresentação (``formatting.py``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from .errors import IncompatibleUnitError, UnknownUnitError

# ---------------------------------------------------------------------------
# Registro de unidades
# ---------------------------------------------------------------------------
# Estrutura: dimensão -> {unidade: fator para a unidade base}
# A primeira unidade declarada de cada dimensão é a unidade base (fator 1).

UNIT_REGISTRY: Final[dict[str, dict[str, float]]] = {
    "current": {"A": 1.0, "mA": 1e-3, "uA": 1e-6, "µA": 1e-6, "kA": 1e3},
    "time": {"s": 1.0, "ms": 1e-3, "min": 60.0, "h": 3600.0, "d": 86400.0},
    "mass": {"g": 1.0, "mg": 1e-3, "ug": 1e-6, "µg": 1e-6, "kg": 1e3, "ng": 1e-9},
    "amount": {"mol": 1.0, "mmol": 1e-3, "umol": 1e-6, "µmol": 1e-6, "nmol": 1e-9},
    "charge": {"C": 1.0, "mC": 1e-3, "kC": 1e3, "mAh": 3.6, "Ah": 3600.0},
    "molar_mass": {"g/mol": 1.0, "kg/mol": 1e3, "mg/mol": 1e-3},
    "voltage": {"V": 1.0, "mV": 1e-3, "kV": 1e3},
    "volume": {"L": 1.0, "mL": 1e-3, "uL": 1e-6, "µL": 1e-6, "m3": 1e3},
    "concentration": {"mol/L": 1.0, "M": 1.0, "mmol/L": 1e-3, "mM": 1e-3, "uM": 1e-6},
    "energy": {"J": 1.0, "kJ": 1e3, "Wh": 3600.0, "kWh": 3.6e6},
    "faraday": {"C/mol": 1.0},
    "ratio": {"fraction": 1.0, "": 1.0, "%": 0.01},
}

BASE_UNITS: Final[dict[str, str]] = {
    dim: next(iter(units)) for dim, units in UNIT_REGISTRY.items()
}

# Índice reverso unidade -> lista de dimensões possíveis.
_UNIT_INDEX: Final[dict[str, list[str]]] = {}
for _dim, _units in UNIT_REGISTRY.items():
    for _unit in _units:
        _UNIT_INDEX.setdefault(_unit, []).append(_dim)


def known_units(dimension: str) -> list[str]:
    """Lista as unidades aceitas para uma dimensão."""
    if dimension not in UNIT_REGISTRY:
        raise UnknownUnitError(f"Dimensão desconhecida: '{dimension}'.")
    return list(UNIT_REGISTRY[dimension])


def dimension_of(unit: str, expected: str | None = None) -> str:
    """Descobre a dimensão de uma unidade.

    ``expected`` desfaz ambiguidades quando a mesma string pertence a mais de
    uma dimensão (caso de ``''`` e ``'M'``).
    """
    candidates = _UNIT_INDEX.get(unit)
    if not candidates:
        raise UnknownUnitError(
            f"Unidade desconhecida: '{unit}'. "
            f"Unidades aceitas: {sorted(_UNIT_INDEX)}"
        )
    if expected is not None:
        if expected not in candidates:
            raise IncompatibleUnitError(
                f"A unidade '{unit}' pertence à dimensão "
                f"'{candidates[0]}', mas era esperada a dimensão '{expected}'."
            )
        return expected
    if len(candidates) > 1:
        raise IncompatibleUnitError(
            f"A unidade '{unit}' é ambígua entre {candidates}; "
            "informe a dimensão esperada."
        )
    return candidates[0]


def factor(unit: str, expected: str | None = None) -> float:
    """Fator multiplicativo que converte ``unit`` para a unidade base."""
    dim = dimension_of(unit, expected)
    return UNIT_REGISTRY[dim][unit]


def to_base(value: float, unit: str, expected: str | None = None) -> float:
    """Converte um valor para a unidade base da sua dimensão."""
    return value * factor(unit, expected)


def from_base(value: float, unit: str, expected: str | None = None) -> float:
    """Converte um valor que está na unidade base para ``unit``."""
    return value / factor(unit, expected)


def convert(value: float, from_unit: str, to_unit: str,
            expected: str | None = None) -> float:
    """Converte entre duas unidades da mesma dimensão."""
    dim_from = dimension_of(from_unit, expected)
    dim_to = dimension_of(to_unit, expected)
    if dim_from != dim_to:
        raise IncompatibleUnitError(
            f"Não é possível converter '{from_unit}' ({dim_from}) para "
            f"'{to_unit}' ({dim_to}): dimensões incompatíveis."
        )
    return value * UNIT_REGISTRY[dim_from][from_unit] / UNIT_REGISTRY[dim_to][to_unit]


def base_unit(dimension: str) -> str:
    """Unidade base de uma dimensão."""
    if dimension not in BASE_UNITS:
        raise UnknownUnitError(f"Dimensão desconhecida: '{dimension}'.")
    return BASE_UNITS[dimension]


@dataclass(frozen=True, slots=True)
class Quantity:
    """Valor numérico associado a uma unidade e a uma dimensão.

    A instância é imutável: qualquer conversão devolve uma nova ``Quantity``.
    ``value`` é sempre mantido em precisão total (float de 64 bits).
    """

    value: float
    unit: str
    dimension: str

    def __post_init__(self) -> None:
        # Valida a coerência unidade/dimensão já na construção.
        dimension_of(self.unit, self.dimension)

    @classmethod
    def create(cls, value: float, unit: str,
               dimension: str | None = None) -> "Quantity":
        dim = dimension_of(unit, dimension)
        return cls(float(value), unit, dim)

    @property
    def base_value(self) -> float:
        """Valor na unidade base da dimensão, sem arredondamento."""
        return self.value * UNIT_REGISTRY[self.dimension][self.unit]

    @property
    def base_unit(self) -> str:
        return BASE_UNITS[self.dimension]

    def to(self, unit: str) -> "Quantity":
        return Quantity(
            convert(self.value, self.unit, unit, self.dimension),
            unit,
            self.dimension,
        )

    def to_base(self) -> "Quantity":
        return self.to(self.base_unit)

    def is_converted(self) -> bool:
        """True se a unidade informada difere da unidade base."""
        return self.unit != self.base_unit

    def as_dict(self) -> dict[str, object]:
        return {
            "value": self.value,
            "unit": self.unit,
            "dimension": self.dimension,
            "base_value": self.base_value,
            "base_unit": self.base_unit,
        }
