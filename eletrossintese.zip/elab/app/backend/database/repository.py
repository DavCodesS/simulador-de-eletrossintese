"""Camada de acesso a dados.

Isola o SQLAlchemy do resto da aplicação: os serviços conversam com este
repositório, nunca com a sessão diretamente. Trocar de banco ou de ORM
não sai daqui.
"""

from __future__ import annotations

from typing import Any, Literal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..models.experiment import Experiment

SORTABLE = {
    "created_at": Experiment.created_at,
    "updated_at": Experiment.updated_at,
    "name": Experiment.name,
    "identifier": Experiment.identifier,
    "date": Experiment.experiment_date,
    "yield_primary": Experiment.yield_primary,
    "faradaic_efficiency": Experiment.faradaic_efficiency,
    "charge_c": Experiment.charge_c,
    "current_a": Experiment.current_a,
    "time_s": Experiment.time_s,
}


class ExperimentRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    # -- escrita -----------------------------------------------------------
    def create(self, **fields: Any) -> Experiment:
        experiment = Experiment(**fields)
        self.session.add(experiment)
        self.session.commit()
        self.session.refresh(experiment)
        return experiment

    def update(self, experiment: Experiment, **fields: Any) -> Experiment:
        for key, value in fields.items():
            setattr(experiment, key, value)
        self.session.commit()
        self.session.refresh(experiment)
        return experiment

    def delete(self, experiment: Experiment) -> None:
        self.session.delete(experiment)
        self.session.commit()

    # -- leitura -----------------------------------------------------------
    def get(self, experiment_id: int) -> Experiment | None:
        return self.session.get(Experiment, experiment_id)

    def get_many(self, ids: list[int]) -> list[Experiment]:
        if not ids:
            return []
        rows = self.session.scalars(
            select(Experiment).where(Experiment.id.in_(ids))).all()
        order = {value: index for index, value in enumerate(ids)}
        return sorted(rows, key=lambda e: order.get(e.id, 0))

    def list(self, search: str = "", sort: str = "created_at",
             direction: Literal["asc", "desc"] = "desc",
             limit: int = 200, offset: int = 0,
             min_yield: float | None = None,
             max_yield: float | None = None) -> list[Experiment]:
        statement = select(Experiment)

        if search:
            pattern = f"%{search.lower()}%"
            statement = statement.where(or_(
                func.lower(Experiment.name).like(pattern),
                func.lower(Experiment.identifier).like(pattern),
                func.lower(Experiment.notes).like(pattern),
                func.lower(Experiment.reference).like(pattern),
            ))
        if min_yield is not None:
            statement = statement.where(Experiment.yield_primary >= min_yield)
        if max_yield is not None:
            statement = statement.where(Experiment.yield_primary <= max_yield)

        column = SORTABLE.get(sort, Experiment.created_at)
        statement = statement.order_by(
            column.desc() if direction == "desc" else column.asc())
        statement = statement.limit(min(limit, 1000)).offset(max(offset, 0))
        return list(self.session.scalars(statement).all())

    def count(self) -> int:
        return int(self.session.scalar(
            select(func.count()).select_from(Experiment)) or 0)

    def aggregates(self) -> dict[str, Any]:
        """Estatísticas do painel, calculadas pelo banco."""
        row = self.session.execute(select(
            func.count(Experiment.id),
            func.avg(Experiment.yield_primary),
            func.max(Experiment.yield_primary),
            func.max(Experiment.faradaic_efficiency),
            func.avg(Experiment.faradaic_efficiency),
        )).one()
        total, avg_yield, best_yield, best_efficiency, avg_efficiency = row
        return {
            "total": int(total or 0),
            "average_yield": float(avg_yield) if avg_yield is not None else None,
            "best_yield": float(best_yield) if best_yield is not None else None,
            "best_efficiency": (float(best_efficiency)
                                if best_efficiency is not None else None),
            "average_efficiency": (float(avg_efficiency)
                                   if avg_efficiency is not None else None),
        }
