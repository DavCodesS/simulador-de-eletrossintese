"""Motor e sessões do banco de dados."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from ...config import settings
from ..models.experiment import Base

_connect_args = {"check_same_thread": False} if settings.is_sqlite else {}

engine: Engine = create_engine(
    settings.database_url,
    echo=settings.echo_sql,
    future=True,
    connect_args=_connect_args,
)

if settings.is_sqlite:
    @event.listens_for(engine, "connect")
    def _enable_sqlite_foreign_keys(dbapi_connection, _record) -> None:
        """SQLite desliga chaves estrangeiras por padrão; PostgreSQL não."""
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False,
                            class_=Session)


def init_db() -> None:
    """Cria as tabelas ausentes.

    Suficiente para uso local. Para evolução de esquema em produção, o passo
    seguinte é Alembic — os modelos já estão escritos de forma compatível.
    """
    Base.metadata.create_all(bind=engine)


@contextmanager
def session_scope() -> Iterator[Session]:
    """Sessão transacional para uso fora do ciclo de requisição."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_session() -> Iterator[Session]:
    """Dependência do FastAPI."""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
