"""Modelo de persistência de experimentos.

Escolhas deliberadas para portabilidade SQLite -> PostgreSQL:

* nenhum tipo específico de banco: ``JSON``, ``String``, ``Float`` e
  ``DateTime`` existem nos dois;
* datas sempre em UTC e com ``timezone=True``;
* nenhuma dependência de ``rowid`` ou de ``AUTOINCREMENT`` do SQLite;
* o ``spec`` completo é guardado como JSON (é o documento de entrada), e as
  grandezas mais usadas em busca, ordenação e gráficos são espelhadas em
  colunas escalares indexáveis.

Os campos espelhados NUNCA são a fonte da verdade: são reescritos a partir
do motor de cálculo a cada gravação.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import DateTime, Float, Index, Integer, JSON, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Experiment(Base):
    """Um experimento persistido, com entrada e resultados calculados."""

    __tablename__ = "experiments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False, index=True)
    identifier: Mapped[str] = mapped_column(String(80), default="", index=True)
    experiment_date: Mapped[str] = mapped_column(String(20), default="")
    reference: Mapped[str] = mapped_column(String(500), default="")
    notes: Mapped[str] = mapped_column(Text, default="")

    #: Documento de entrada completo (ExperimentSpec serializado).
    spec: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    #: Último resultado calculado, incluindo rastros.
    results: Mapped[dict[str, Any] | None] = mapped_column(JSON, default=None)

    # -- espelhos para busca/ordenação/gráficos ---------------------------
    yield_primary: Mapped[float | None] = mapped_column(Float, default=None)
    yield_mass: Mapped[float | None] = mapped_column(Float, default=None)
    yield_amount: Mapped[float | None] = mapped_column(Float, default=None)
    faradaic_efficiency: Mapped[float | None] = mapped_column(Float, default=None)
    charge_c: Mapped[float | None] = mapped_column(Float, default=None)
    current_a: Mapped[float | None] = mapped_column(Float, default=None)
    time_s: Mapped[float | None] = mapped_column(Float, default=None)
    theoretical_mass_g: Mapped[float | None] = mapped_column(Float, default=None)
    experimental_mass_g: Mapped[float | None] = mapped_column(Float, default=None)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow,
        nullable=False)

    __table_args__ = (
        Index("ix_experiments_yield", "yield_primary"),
        Index("ix_experiments_created", "created_at"),
    )

    def as_dict(self, include_results: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.id,
            "name": self.name,
            "identifier": self.identifier,
            "date": self.experiment_date,
            "reference": self.reference,
            "notes": self.notes,
            "spec": self.spec,
            "metrics": {
                "yield_primary": self.yield_primary,
                "yield_mass": self.yield_mass,
                "yield_amount": self.yield_amount,
                "faradaic_efficiency": self.faradaic_efficiency,
                "charge_c": self.charge_c,
                "current_a": self.current_a,
                "time_s": self.time_s,
                "theoretical_mass_g": self.theoretical_mass_g,
                "experimental_mass_g": self.experimental_mass_g,
            },
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_results:
            payload["results"] = self.results
        return payload
