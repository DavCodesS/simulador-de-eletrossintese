"""Serviço de experimentos.

Única camada que conhece ao mesmo tempo o motor de cálculo e o repositório.
Toda gravação recalcula os resultados a partir do ``spec``, de modo que
resultados persistidos nunca ficam dessincronizados da entrada.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from ..calculations import engine
from ..calculations.spec import ExperimentSpec
from ..calculations.units import Quantity
from ..database.repository import ExperimentRepository
from ..models.experiment import Experiment


def _mirror_metrics(spec: ExperimentSpec,
                    results: engine.ExperimentResults) -> dict[str, Any]:
    """Extrai as colunas espelhadas, sempre em unidades base."""
    current = spec.electro.current_q
    time = spec.electro.time_q
    experimental_mass = spec.product.experimental_mass_q
    return {
        "yield_primary": results.value("yield_primary"),
        "yield_mass": results.value("yield_mass"),
        "yield_amount": results.value("yield_amount"),
        "faradaic_efficiency": results.value("faradaic_efficiency"),
        "charge_c": results.value("charge"),
        "current_a": current.base_value if current else None,
        "time_s": time.base_value if time else None,
        "theoretical_mass_g": results.value("theoretical_mass"),
        "experimental_mass_g": (experimental_mass.base_value
                                if experimental_mass else None),
    }


class ExperimentService:
    def __init__(self, session: Session) -> None:
        self.repository = ExperimentRepository(session)

    # -- cálculo sem persistência -----------------------------------------
    @staticmethod
    def calculate(spec_data: dict[str, Any]) -> dict[str, Any]:
        spec = ExperimentSpec.from_dict(spec_data)
        return engine.run(spec).as_dict()

    # -- CRUD ---------------------------------------------------------------
    def create(self, spec_data: dict[str, Any]) -> Experiment:
        spec = ExperimentSpec.from_dict(spec_data)
        results = engine.run(spec)
        return self.repository.create(
            name=spec.name,
            identifier=spec.identifier,
            experiment_date=spec.date,
            reference=spec.reference,
            notes=spec.notes,
            spec=spec.as_dict(),
            results=results.as_dict(),
            **_mirror_metrics(spec, results),
        )

    def update(self, experiment_id: int,
               spec_data: dict[str, Any]) -> Experiment | None:
        experiment = self.repository.get(experiment_id)
        if experiment is None:
            return None
        spec = ExperimentSpec.from_dict(spec_data)
        results = engine.run(spec)
        return self.repository.update(
            experiment,
            name=spec.name,
            identifier=spec.identifier,
            experiment_date=spec.date,
            reference=spec.reference,
            notes=spec.notes,
            spec=spec.as_dict(),
            results=results.as_dict(),
            **_mirror_metrics(spec, results),
        )

    def duplicate(self, experiment_id: int,
                  new_name: str = "") -> Experiment | None:
        original = self.repository.get(experiment_id)
        if original is None:
            return None
        spec_data = dict(original.spec)
        spec_data["name"] = new_name or f"{original.name} (cópia)"
        spec_data["identifier"] = ""
        return self.create(spec_data)

    def recalculate(self, experiment_id: int) -> Experiment | None:
        experiment = self.repository.get(experiment_id)
        if experiment is None:
            return None
        return self.update(experiment_id, experiment.spec)

    def delete(self, experiment_id: int) -> bool:
        experiment = self.repository.get(experiment_id)
        if experiment is None:
            return False
        self.repository.delete(experiment)
        return True

    # -- consultas ---------------------------------------------------------
    def get(self, experiment_id: int) -> Experiment | None:
        return self.repository.get(experiment_id)

    def list(self, **kwargs: Any) -> list[Experiment]:
        return self.repository.list(**kwargs)

    def dashboard(self) -> dict[str, Any]:
        aggregates = self.repository.aggregates()
        recent = self.repository.list(limit=8, sort="created_at",
                                      direction="desc")
        best = self.repository.list(limit=1, sort="yield_primary",
                                    direction="desc")
        return {
            **aggregates,
            "recent": [e.as_dict(include_results=False) for e in recent],
            "best_experiment": (best[0].as_dict(include_results=False)
                                if best and best[0].yield_primary is not None
                                else None),
            "chart": [
                {
                    "id": e.id,
                    "name": e.name,
                    "identifier": e.identifier,
                    "yield_primary": e.yield_primary,
                    "faradaic_efficiency": e.faradaic_efficiency,
                    "charge_c": e.charge_c,
                    "current_a": e.current_a,
                    "time_s": e.time_s,
                }
                for e in self.repository.list(limit=100, sort="created_at",
                                              direction="asc")
            ],
        }

    def compare(self, ids: list[int]) -> dict[str, Any]:
        from ..calculations import simulation

        experiments = self.repository.get_many(ids)
        pairs = []
        for experiment in experiments:
            spec = ExperimentSpec.from_dict(experiment.spec)
            pairs.append((f"{experiment.name} (#{experiment.id})",
                          engine.run(spec)))
        table = simulation.compare(pairs)
        table["ids"] = [e.id for e in experiments]
        return table

    def series(self, ids: list[int] | None = None) -> list[dict[str, Any]]:
        """Pontos prontos para os gráficos, em unidades base."""
        experiments = (self.repository.get_many(ids) if ids
                       else self.repository.list(limit=500, sort="created_at",
                                                 direction="asc"))
        points = []
        for experiment in experiments:
            results = (experiment.results or {}).get("summary", {})
            points.append({
                "id": experiment.id,
                "name": experiment.name,
                "identifier": experiment.identifier,
                "date": experiment.experiment_date,
                "yield_primary": experiment.yield_primary,
                "yield_mass": experiment.yield_mass,
                "yield_amount": experiment.yield_amount,
                "faradaic_efficiency": experiment.faradaic_efficiency,
                "charge_c": experiment.charge_c,
                "current_a": experiment.current_a,
                "time_s": experiment.time_s,
                "theoretical_mass_g": experiment.theoretical_mass_g,
                "experimental_mass_g": experiment.experimental_mass_g,
                "moles_electrons": results.get("moles_electrons"),
                "charge_per_mole": results.get("charge_per_mole"),
                "energy": results.get("energy"),
            })
        return points
