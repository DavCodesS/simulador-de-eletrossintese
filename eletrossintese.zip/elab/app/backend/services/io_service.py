"""Importação e exportação.

O CSV é achatado: cada linha é um experimento. Reagentes adicionais usam
colunas prefixadas ``reagenteN_``. Colunas desconhecidas são ignoradas com
aviso, e colunas vazias viram ``None`` — nunca zero.
"""

from __future__ import annotations

import csv
import io
import json
from typing import Any

from ..calculations.errors import ValidationError
from ..calculations.spec import ExperimentSpec

#: Colunas do modelo de importação, na ordem em que aparecem.
CSV_COLUMNS: list[str] = [
    "nome", "identificador", "data", "referencia", "observacoes",
    "substrato_nome", "substrato_massa_molar", "substrato_massa",
    "substrato_massa_unidade", "substrato_coeficiente",
    "produto_nome", "produto_massa_molar", "produto_coeficiente",
    "produto_eletrons_por_mol",
    "produto_massa_experimental", "produto_massa_experimental_unidade",
    "corrente", "corrente_unidade", "tempo", "tempo_unidade",
    "tensao", "tensao_unidade", "carga_medida", "carga_medida_unidade",
    "constante_faraday", "eficiencia_admitida", "eficiencia_admitida_unidade",
    "definicao_rendimento", "base_teorica",
]

EXAMPLE_ROW: dict[str, str] = {
    "nome": "Exemplo — preencha com seus dados",
    "identificador": "EXP-001",
    "data": "2026-08-30",
    "referencia": "protocolo interno / DOI",
    "observacoes": "",
    "substrato_nome": "Substrato",
    "substrato_massa_molar": "100",
    "substrato_massa": "100",
    "substrato_massa_unidade": "mg",
    "substrato_coeficiente": "1",
    "produto_nome": "Produto",
    "produto_massa_molar": "114",
    "produto_coeficiente": "1",
    "produto_eletrons_por_mol": "",
    "produto_massa_experimental": "85.5",
    "produto_massa_experimental_unidade": "mg",
    "corrente": "50",
    "corrente_unidade": "mA",
    "tempo": "60",
    "tempo_unidade": "min",
    "tensao": "",
    "tensao_unidade": "V",
    "carga_medida": "",
    "carga_medida_unidade": "C",
    "constante_faraday": "",
    "eficiencia_admitida": "",
    "eficiencia_admitida_unidade": "%",
    "definicao_rendimento": "mass",
    "base_teorica": "stoichiometric",
}


def _number(raw: Any) -> float | None:
    """Converte texto em número, aceitando vírgula decimal.

    Campo vazio devolve ``None`` — jamais 0. É essa distinção que impede o
    sistema de inventar dados durante a importação.
    """
    if raw is None:
        return None
    text = str(raw).strip().replace(" ", "")
    if not text:
        return None
    text = text.replace(",", ".")
    try:
        return float(text)
    except ValueError as exc:
        raise ValidationError(f"Valor numérico inválido: '{raw}'.") from exc


def _text(raw: Any, default: str = "") -> str:
    return str(raw).strip() if raw is not None and str(raw).strip() else default


def template_csv() -> str:
    """Modelo de CSV com uma linha de exemplo."""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    writer.writerow({column: EXAMPLE_ROW.get(column, "")
                     for column in CSV_COLUMNS})
    return buffer.getvalue()


def _extra_reagents(row: dict[str, Any]) -> list[dict[str, Any]]:
    """Lê colunas ``reagenteN_nome``, ``reagenteN_massa_molar``, etc."""
    indices = sorted({
        key.split("_")[0][len("reagente"):]
        for key in row
        if key.startswith("reagente") and "_" in key
    })
    reagents = []
    for index in indices:
        prefix = f"reagente{index}_"
        name = _text(row.get(prefix + "nome"))
        if not name:
            continue
        reagents.append({
            "name": name,
            "molar_mass": _number(row.get(prefix + "massa_molar")),
            "mass": _number(row.get(prefix + "massa")),
            "mass_unit": _text(row.get(prefix + "massa_unidade"), "mg"),
            "amount": _number(row.get(prefix + "quantidade")),
            "amount_unit": _text(row.get(prefix + "quantidade_unidade"), "mmol"),
            "stoich_coefficient": _number(row.get(prefix + "coeficiente")),
        })
    return reagents


def row_to_spec(row: dict[str, Any]) -> dict[str, Any]:
    """Converte uma linha do CSV no documento de entrada do motor."""
    normalized = {(k or "").strip().lower(): v for k, v in row.items()}

    substrate_name = _text(normalized.get("substrato_nome"), "Substrato")
    reagents: list[dict[str, Any]] = [{
        "name": substrate_name,
        "molar_mass": _number(normalized.get("substrato_massa_molar")),
        "mass": _number(normalized.get("substrato_massa")),
        "mass_unit": _text(normalized.get("substrato_massa_unidade"), "mg"),
        "stoich_coefficient": _number(normalized.get("substrato_coeficiente")),
        "role": "substrate",
    }]
    reagents.extend(_extra_reagents(normalized))

    faraday = _number(normalized.get("constante_faraday"))
    electro: dict[str, Any] = {
        "current": _number(normalized.get("corrente")),
        "current_unit": _text(normalized.get("corrente_unidade"), "mA"),
        "time": _number(normalized.get("tempo")),
        "time_unit": _text(normalized.get("tempo_unidade"), "min"),
        "voltage": _number(normalized.get("tensao")),
        "voltage_unit": _text(normalized.get("tensao_unidade"), "V"),
        "measured_charge": _number(normalized.get("carga_medida")),
        "measured_charge_unit": _text(normalized.get("carga_medida_unidade"), "C"),
        "assumed_current_efficiency": _number(
            normalized.get("eficiencia_admitida")),
        "assumed_current_efficiency_unit": _text(
            normalized.get("eficiencia_admitida_unidade"), "%"),
    }
    if faraday is not None:
        electro["faraday_constant"] = faraday

    return {
        "name": _text(normalized.get("nome"), "Experimento importado"),
        "identifier": _text(normalized.get("identificador")),
        "date": _text(normalized.get("data")),
        "reference": _text(normalized.get("referencia")),
        "notes": _text(normalized.get("observacoes")),
        "reagents": reagents,
        "product": {
            "name": _text(normalized.get("produto_nome"), "Produto"),
            "molar_mass": _number(normalized.get("produto_massa_molar")),
            "stoich_coefficient": _number(
                normalized.get("produto_coeficiente")),
            "electrons_per_mol": _number(
                normalized.get("produto_eletrons_por_mol")),
            "experimental_mass": _number(
                normalized.get("produto_massa_experimental")),
            "experimental_mass_unit": _text(
                normalized.get("produto_massa_experimental_unidade"), "mg"),
        },
        "electro": electro,
        "substrate_name": substrate_name,
        "yield_definition": _text(
            normalized.get("definicao_rendimento"), "mass"),
        "theoretical_basis": _text(normalized.get("base_teorica"),
                                   "stoichiometric"),
    }


def parse_csv(content: str) -> tuple[list[dict[str, Any]], list[str]]:
    """Lê um CSV e devolve (specs válidos, erros por linha)."""
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        raise ValidationError("O arquivo CSV está vazio ou sem cabeçalho.")

    specs: list[dict[str, Any]] = []
    errors: list[str] = []
    for number, row in enumerate(reader, start=2):
        if not any((value or "").strip() for value in row.values()):
            continue
        try:
            spec_data = row_to_spec(row)
            ExperimentSpec.from_dict(spec_data).validate()
            specs.append(spec_data)
        except ValidationError as exc:
            errors.append(f"Linha {number}: {exc}")
        except Exception as exc:  # noqa: BLE001 — reportado, não engolido
            errors.append(f"Linha {number}: erro inesperado — {exc}")
    return specs, errors


# ---------------------------------------------------------------------------
# Exportação
# ---------------------------------------------------------------------------

EXPORT_COLUMNS: list[tuple[str, str]] = [
    ("id", "ID"),
    ("name", "Nome"),
    ("identifier", "Identificador"),
    ("date", "Data"),
    ("yield_primary", "Rendimento principal (%)"),
    ("yield_mass", "Rendimento base massa (%)"),
    ("yield_amount", "Rendimento base mol (%)"),
    ("faradaic_efficiency", "Eficiência faradaica (%)"),
    ("charge_c", "Carga (C)"),
    ("current_a", "Corrente (A)"),
    ("time_s", "Tempo (s)"),
    ("theoretical_mass_g", "Massa teórica (g)"),
    ("experimental_mass_g", "Massa experimental (g)"),
    ("reference", "Referência"),
    ("notes", "Observações"),
]


def _flat(experiment: Any) -> dict[str, Any]:
    data = experiment.as_dict(include_results=False)
    return {**data, **data["metrics"]}


def export_csv(experiments: list[Any]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow([label for _, label in EXPORT_COLUMNS])
    for experiment in experiments:
        flat = _flat(experiment)
        writer.writerow([flat.get(key) for key, _ in EXPORT_COLUMNS])
    return buffer.getvalue()


def export_json(experiments: list[Any]) -> str:
    return json.dumps(
        [e.as_dict(include_results=True) for e in experiments],
        ensure_ascii=False, indent=2, default=str)


def export_xlsx(experiments: list[Any]) -> bytes:
    """Exporta para Excel. Requer openpyxl; sem ele, a rota devolve 501."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Experimentos"
    sheet.append([label for _, label in EXPORT_COLUMNS])
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for experiment in experiments:
        flat = _flat(experiment)
        sheet.append([flat.get(key) for key, _ in EXPORT_COLUMNS])
    for index, (_, label) in enumerate(EXPORT_COLUMNS, start=1):
        sheet.column_dimensions[
            sheet.cell(row=1, column=index).column_letter].width = max(
                14, len(label) + 2)

    buffer = io.BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()
