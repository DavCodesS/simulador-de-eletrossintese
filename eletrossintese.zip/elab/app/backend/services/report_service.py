"""Geração de relatórios experimentais.

O relatório separa explicitamente três categorias, e essa separação aparece
no PDF impresso:

* parâmetros informados pelo usuário;
* resultados CALCULADOS pelas fórmulas;
* medidas EXPERIMENTAIS registradas.

Parâmetros não calculáveis aparecem no relatório com a justificativa, em vez
de serem omitidos — omitir daria a impressão de que não eram relevantes.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from ..calculations.formatting import significant, with_unit

DISCLAIMER = (
    "Este documento é um registro de cálculo. Os valores marcados como "
    "CALCULADOS derivam exclusivamente das fórmulas e dos parâmetros "
    "informados. Não representam validação experimental nem previsão de "
    "resultado, e não substituem a verificação do protocolo."
)


def build(experiment: Any) -> dict[str, Any]:
    """Monta a estrutura do relatório a partir de um experimento salvo."""
    results = experiment.results or {}
    outcomes = results.get("outcomes", {})
    spec = experiment.spec or {}

    calculated, experimental, unavailable = [], [], []
    for outcome in outcomes.values():
        entry = {
            "label": outcome["label"],
            "value": outcome["value"],
            "unit": outcome["unit"],
            "formatted": with_unit(outcome["value"], outcome["unit"]),
            "reason": outcome["reason"],
            "formula": (outcome.get("trace") or {}).get("formula_id"),
        }
        if outcome["status"] != "calculated":
            unavailable.append(entry)
        elif outcome["kind"] == "experimental":
            experimental.append(entry)
        else:
            calculated.append(entry)

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "identification": {
            "id": experiment.id,
            "name": experiment.name,
            "identifier": experiment.identifier,
            "date": experiment.experiment_date,
            "reference": experiment.reference,
            "notes": experiment.notes,
        },
        "reagents": spec.get("reagents", []),
        "product": spec.get("product", {}),
        "electro": spec.get("electro", {}),
        "configuration": {
            "yield_definition": spec.get("yield_definition"),
            "theoretical_basis": spec.get("theoretical_basis"),
            "limiting_selection": spec.get("limiting_selection"),
            "substrate_name": spec.get("substrate_name"),
        },
        "limiting": results.get("limiting"),
        "calculated": calculated,
        "experimental": experimental,
        "unavailable": unavailable,
        "warnings": results.get("warnings", []),
        "disclaimer": DISCLAIMER,
    }


def to_pdf(experiment: Any) -> bytes:
    """Renderiza o relatório em PDF (reportlab)."""
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_JUSTIFY
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
    )
    import io as _io

    report = build(experiment)
    styles = getSampleStyleSheet()
    small = ParagraphStyle("small", parent=styles["Normal"], fontSize=8,
                           leading=10, alignment=TA_JUSTIFY,
                           textColor=colors.HexColor("#444444"))
    heading = ParagraphStyle("h", parent=styles["Heading2"], fontSize=12,
                             spaceBefore=10, spaceAfter=4,
                             textColor=colors.HexColor("#123a5e"))

    buffer = _io.BytesIO()
    document = SimpleDocTemplate(
        buffer, pagesize=A4, title=f"Relatório — {experiment.name}",
        leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=16 * mm, bottomMargin=16 * mm)

    def table(rows: list[list[str]], widths: list[float]) -> Table:
        component = Table(rows, colWidths=widths, hAlign="LEFT")
        component.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2f7")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#123a5e")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c9d4e0")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#f8fafc")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        return component

    story: list[Any] = []
    identification = report["identification"]
    story.append(Paragraph(f"Relatório experimental — {identification['name']}",
                           styles["Title"]))
    story.append(Paragraph(
        f"Identificador: {identification['identifier'] or '—'} &nbsp;|&nbsp; "
        f"Data do experimento: {identification['date'] or '—'} &nbsp;|&nbsp; "
        f"Emitido em: {report['generated_at']}", small))
    story.append(Spacer(1, 6))
    story.append(Paragraph(report["disclaimer"], small))

    story.append(Paragraph("1. Reagentes declarados", heading))
    rows = [["Nome", "M (g/mol)", "Massa", "Quantidade", "Coeficiente"]]
    for reagent in report["reagents"]:
        mass = (f"{significant(reagent.get('mass'))} {reagent.get('mass_unit','')}"
                if reagent.get("mass") is not None else "—")
        amount = (f"{significant(reagent.get('amount'))} "
                  f"{reagent.get('amount_unit','')}"
                  if reagent.get("amount") is not None else "—")
        rows.append([
            reagent.get("name", "—"),
            significant(reagent.get("molar_mass")) if reagent.get("molar_mass") else "—",
            mass, amount,
            significant(reagent.get("stoich_coefficient"))
            if reagent.get("stoich_coefficient") else "não informado",
        ])
    story.append(table(rows, [120, 70, 80, 80, 90]))

    story.append(Paragraph("2. Produto e configuração de cálculo", heading))
    product = report["product"]
    configuration = report["configuration"]
    basis = ("estequiométrica" if configuration.get("theoretical_basis")
             == "stoichiometric" else "faradaica")
    definition = ("massa" if configuration.get("yield_definition") == "mass"
                  else "quantidade de matéria")
    rows = [
        ["Parâmetro", "Valor"],
        ["Produto", product.get("name", "—")],
        ["Massa molar do produto (g/mol)",
         significant(product.get("molar_mass")) if product.get("molar_mass") else "não informado"],
        ["Coeficiente estequiométrico",
         significant(product.get("stoich_coefficient")) if product.get("stoich_coefficient") else "não informado"],
        ["Elétrons por mol de produto (z)",
         significant(product.get("electrons_per_mol")) if product.get("electrons_per_mol") else "não informado"],
        ["Base teórica adotada", basis],
        ["Definição de rendimento", definition],
        ["Substrato de referência", configuration.get("substrate_name") or "—"],
    ]
    story.append(table(rows, [200, 240]))

    story.append(Paragraph("3. Parâmetros eletroquímicos informados", heading))
    electro = report["electro"]
    rows = [["Parâmetro", "Valor"]]
    for label, key, unit_key in [
        ("Corrente", "current", "current_unit"),
        ("Tempo", "time", "time_unit"),
        ("Tensão", "voltage", "voltage_unit"),
        ("Carga medida", "measured_charge", "measured_charge_unit"),
        ("Eficiência admitida", "assumed_current_efficiency",
         "assumed_current_efficiency_unit"),
    ]:
        value = electro.get(key)
        rows.append([label, f"{significant(value)} {electro.get(unit_key, '')}"
                     if value is not None else "não informado"])
    rows.append(["Constante de Faraday (C/mol)",
                 significant(electro.get("faraday_constant"))])
    story.append(table(rows, [200, 240]))

    story.append(Paragraph("4. Reagente limitante", heading))
    limiting = report["limiting"] or {}
    if limiting.get("status") == "calculated":
        story.append(Paragraph(
            f"Limitante: <b>{limiting['limiting_name']}</b> — avanço máximo "
            f"ξ = {significant(limiting['extent_mol'])} mol"
            + (" (definido pelo usuário)" if limiting.get("forced") else
               " (menor razão n/ν entre os reagentes declarados)"),
            styles["Normal"]))
    else:
        story.append(Paragraph(
            f"Não calculável. {limiting.get('reason', '')}", small))

    story.append(PageBreak())
    story.append(Paragraph("5. Medidas experimentais", heading))
    rows = [["Grandeza", "Valor"]] + [
        [entry["label"], entry["formatted"]]
        for entry in report["experimental"]] or [["—", "—"]]
    story.append(table(rows, [280, 160]))

    story.append(Paragraph("6. Resultados calculados", heading))
    rows = [["Grandeza", "Valor", "Fórmula"]] + [
        [entry["label"], entry["formatted"], entry["formula"] or "—"]
        for entry in report["calculated"]]
    story.append(table(rows, [190, 110, 140]))

    story.append(Paragraph("7. Parâmetros não calculáveis", heading))
    if report["unavailable"]:
        rows = [["Grandeza", "Motivo"]] + [
            [entry["label"], entry["reason"]]
            for entry in report["unavailable"]]
        story.append(table(rows, [170, 270]))
    else:
        story.append(Paragraph("Todos os parâmetros previstos foram "
                               "calculados.", small))

    if report["warnings"]:
        story.append(Paragraph("8. Avisos", heading))
        for warning in report["warnings"]:
            story.append(Paragraph(f"• {warning}", small))

    if identification["notes"]:
        story.append(Paragraph("9. Observações", heading))
        story.append(Paragraph(identification["notes"], styles["Normal"]))
    if identification["reference"]:
        story.append(Spacer(1, 6))
        story.append(Paragraph(
            f"<b>Fonte / protocolo:</b> {identification['reference']}", small))

    document.build(story)
    return buffer.getvalue()
