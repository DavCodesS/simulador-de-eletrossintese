"""Validação de fronteira.

As guardas de ``calculations/rules.py`` param no primeiro erro, o que é o
comportamento correto para o motor: ele não deve calcular com dado inválido.
Mas é o comportamento errado para quem está preenchendo um formulário e
descobre um problema por vez.

Este módulo percorre a descrição inteira do experimento **sem interromper**,
acumulando tudo o que está errado, e devolve uma lista ordenada. É usado pela
API para responder um erro de validação com o conjunto completo de problemas,
de modo que o usuário corrija tudo numa passada.

Ele também verifica algo que o motor só descobriria no meio de um cálculo:
nomes de unidade inválidos.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..calculations import rules
from ..calculations.errors import CalculationError, ValidationError
from ..calculations.spec import ExperimentSpec
from ..calculations.units import UNIT_REGISTRY, dimension_of

#: Campos de unidade e a dimensão que cada um precisa ter.
_UNIT_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("mass_unit", "mass", "massa do reagente"),
    ("amount_unit", "amount", "quantidade de matéria do reagente"),
    ("concentration_unit", "concentration", "concentração do reagente"),
    ("volume_unit", "volume", "volume do reagente"),
)

_PRODUCT_UNIT_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("experimental_mass_unit", "mass", "massa experimental do produto"),
    ("experimental_amount_unit", "amount", "quantidade experimental do produto"),
)

_ELECTRO_UNIT_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("current_unit", "current", "corrente"),
    ("time_unit", "time", "tempo"),
    ("voltage_unit", "voltage", "tensão"),
    ("measured_charge_unit", "charge", "carga medida"),
    ("assumed_current_efficiency_unit", "ratio", "eficiência admitida"),
)


@dataclass(frozen=True, slots=True)
class Problem:
    """Um problema encontrado, ligado ao campo que o causou."""

    field: str
    message: str
    severity: str = "error"          # "error" impede o cálculo; "notice" não

    def as_dict(self) -> dict[str, str]:
        return {"field": self.field, "message": self.message,
                "severity": self.severity}


@dataclass(slots=True)
class _Collector:
    """Executa uma guarda e guarda o erro em vez de deixá-lo subir."""

    problems: list[Problem] = field(default_factory=list)

    def check(self, guard, *args, **kwargs) -> None:
        try:
            guard(*args, **kwargs)
        except ValidationError as error:
            self.problems.append(Problem(error.field or "", str(error)))

    def add(self, field_name: str, message: str,
            severity: str = "error") -> None:
        self.problems.append(Problem(field_name, message, severity))


def _check_unit(collector: _Collector, holder: Any, attribute: str,
                dimension: str, label: str, prefix: str = "") -> None:
    """Confere um nome de unidade contra o registro."""
    unit = getattr(holder, attribute, None)
    if not unit:
        return
    try:
        dimension_of(unit, dimension)
    except CalculationError:
        accepted = ", ".join(UNIT_REGISTRY[dimension])
        collector.add(
            f"{prefix}{attribute}",
            f"A unidade '{unit}' não serve para {label}. "
            f"Unidades aceitas: {accepted}.")


def inspect(spec: ExperimentSpec | dict[str, Any]) -> list[Problem]:
    """Devolve todos os problemas da descrição, sem parar no primeiro.

    Aceita tanto o objeto de domínio quanto o dicionário cru vindo da API,
    para que o chamador não precise construir um ``ExperimentSpec`` válido
    antes de saber por que ele é inválido.
    """
    if isinstance(spec, dict):
        try:
            spec = ExperimentSpec.from_dict(spec)
        except Exception as error:            # payload malformado
            return [Problem("", f"Não foi possível ler os dados enviados: "
                                f"{error}")]
    collector = _Collector()

    if not spec.reagents:
        collector.add("reagents",
                      "Nenhum reagente foi declarado.", "notice")

    for index, reagent in enumerate(spec.reagents):
        prefix = f"reagents[{index}]."
        who = f"'{reagent.name or f'reagente {index + 1}'}'"
        collector.check(rules.required, reagent.name,
                        "O nome do reagente", f"{prefix}name")
        collector.check(rules.non_negative, reagent.mass,
                        f"{who}: a massa", f"{prefix}mass")
        collector.check(rules.non_negative, reagent.amount,
                        f"{who}: a quantidade de matéria", f"{prefix}amount")
        collector.check(rules.non_negative, reagent.concentration,
                        f"{who}: a concentração", f"{prefix}concentration")
        collector.check(rules.non_negative, reagent.volume,
                        f"{who}: o volume", f"{prefix}volume")
        collector.check(rules.positive, reagent.molar_mass,
                        f"{who}: a massa molar", f"{prefix}molar_mass")
        collector.check(rules.positive, reagent.stoich_coefficient,
                        f"{who}: o coeficiente estequiométrico",
                        f"{prefix}stoich_coefficient")
        for attribute, dimension, label in _UNIT_FIELDS:
            _check_unit(collector, reagent, attribute, dimension,
                        f"{label} {who}", prefix)

        if reagent.concentration is not None and reagent.volume is None:
            collector.add(f"{prefix}volume",
                          f"{who}: a concentração foi informada sem o volume, "
                          "então a quantidade de matéria não sai por essa via.",
                          "notice")

    product = spec.product
    collector.check(rules.positive, product.molar_mass,
                    "A massa molar do produto", "product.molar_mass")
    collector.check(rules.positive, product.electrons_per_mol,
                    "O número de elétrons por mol de produto",
                    "product.electrons_per_mol")
    collector.check(rules.positive, product.stoich_coefficient,
                    "O coeficiente estequiométrico do produto",
                    "product.stoich_coefficient")
    collector.check(rules.non_negative, product.experimental_mass,
                    "A massa experimental do produto",
                    "product.experimental_mass")
    collector.check(rules.non_negative, product.experimental_amount,
                    "A quantidade experimental do produto",
                    "product.experimental_amount")
    for attribute, dimension, label in _PRODUCT_UNIT_FIELDS:
        _check_unit(collector, product, attribute, dimension, label,
                    "product.")

    electro = spec.electro
    collector.check(rules.non_negative, electro.current, "A corrente",
                    "electro.current")
    collector.check(rules.non_negative, electro.measured_charge,
                    "A carga medida", "electro.measured_charge")
    collector.check(rules.non_negative, electro.voltage, "A tensão",
                    "electro.voltage")
    collector.check(rules.positive, electro.time, "O tempo", "electro.time")
    collector.check(rules.positive, electro.faraday_constant,
                    "A constante de Faraday", "electro.faraday_constant")
    for attribute, dimension, label in _ELECTRO_UNIT_FIELDS:
        _check_unit(collector, electro, attribute, dimension, label,
                    "electro.")

    if electro.assumed_current_efficiency is not None:
        try:
            efficiency = electro.assumed_efficiency_q
        except CalculationError:
            efficiency = None          # unidade inválida, já reportada acima
        if efficiency is not None:
            collector.check(rules.in_range, efficiency.base_value, 0.0, 1.0,
                            "A eficiência de corrente admitida",
                            "electro.assumed_current_efficiency")

    names = [reagent.name for reagent in spec.reagents]
    collector.check(rules.unique_names, names, "Lista de reagentes",
                    "reagents")
    if spec.limiting_selection not in ("auto", ""):
        collector.check(rules.member_of, spec.limiting_selection, names,
                        "O reagente escolhido como limitante",
                        "limiting_selection")
    collector.check(rules.member_of, spec.substrate_name, names,
                    "O substrato", "substrate_name")
    collector.check(rules.one_of, spec.yield_definition, ("mass", "amount"),
                    "A definição de rendimento", "yield_definition")
    collector.check(rules.one_of, spec.theoretical_basis,
                    ("stoichiometric", "faradaic"),
                    "A base da quantidade teórica", "theoretical_basis")

    return collector.problems


def errors_only(problems: list[Problem]) -> list[Problem]:
    """Filtra os problemas que realmente impedem o cálculo."""
    return [problem for problem in problems if problem.severity == "error"]
