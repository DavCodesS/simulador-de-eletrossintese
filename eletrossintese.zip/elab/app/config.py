"""Configuração da aplicação.

Tudo é sobrescrevível por variável de ambiente, o que permite trocar SQLite
por PostgreSQL sem alterar código:

    ELAB_DATABASE_URL=postgresql+psycopg://user:senha@host/banco python -m app
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("ELAB_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True, slots=True)
class Settings:
    app_name: str = "Eletroquímica — Motor de Cálculo Experimental"
    version: str = "1.0.0"
    database_url: str = os.environ.get(
        "ELAB_DATABASE_URL", f"sqlite:///{DATA_DIR / 'experiments.db'}")
    host: str = os.environ.get("ELAB_HOST", "127.0.0.1")
    port: int = int(os.environ.get("ELAB_PORT", "8000"))
    open_browser: bool = os.environ.get("ELAB_OPEN_BROWSER", "1") == "1"
    echo_sql: bool = os.environ.get("ELAB_ECHO_SQL", "0") == "1"

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


settings = Settings()
