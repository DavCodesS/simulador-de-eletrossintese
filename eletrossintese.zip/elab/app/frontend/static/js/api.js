/* Cliente da API.
   Nenhum cálculo científico acontece no navegador: este módulo só transporta
   dados. Todo número exibido vem do motor Python. */

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (response.status === 204) return null;

  const text = await response.text();
  let payload = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = null; }

  if (!response.ok) {
    const detail = payload?.detail ?? payload;
    const message =
      (typeof detail === "string" && detail) ||
      detail?.error ||
      payload?.error ||
      `Falha na requisição (${response.status}).`;
    const error = new Error(message);
    error.field = detail?.field ?? null;
    error.problems = detail?.problems ?? [];
    error.status = response.status;
    throw error;
  }
  return payload;
}

const post = (url, body) =>
  request(url, { method: "POST", body: JSON.stringify(body ?? {}) });
const put = (url, body) =>
  request(url, { method: "PUT", body: JSON.stringify(body ?? {}) });

export const api = {
  health: () => request("/api/health"),
  formulas: () => request("/api/formulas"),
  units: () => request("/api/units"),

  calculate: (spec) => post("/api/calculate", spec),
  validate: (spec) => post("/api/validate", spec),
  limiting: (payload) => post("/api/limiting", payload),

  listExperiments: (params = {}) => {
    const query = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== "" && v != null)
    );
    return request(`/api/experiments?${query}`);
  },
  getExperiment: (id) => request(`/api/experiments/${id}`),
  createExperiment: (spec) => post("/api/experiments", spec),
  updateExperiment: (id, spec) => put(`/api/experiments/${id}`, spec),
  duplicateExperiment: (id, name = "") =>
    post(`/api/experiments/${id}/duplicate`, { name }),
  recalculate: (id) => post(`/api/experiments/${id}/recalculate`),
  deleteExperiment: (id) => request(`/api/experiments/${id}`, { method: "DELETE" }),

  dashboard: () => request("/api/dashboard"),
  compare: (ids) => request(`/api/compare?ids=${ids.join(",")}`),
  series: (ids = []) => request(`/api/series?ids=${ids.join(",")}`),

  sweep: (payload) => post("/api/simulate/sweep", payload),
  scenarios: (payload) => post("/api/simulate/scenarios", payload),

  importCsv: (content, persist) => post("/api/import/csv", { content, persist }),
};
