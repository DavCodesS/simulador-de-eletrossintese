/* Ponto de entrada da interface: navegação, abas, modo de visualização e
   as ações do editor. */

import { api } from "./api.js";
import {
  addReagentRow, clearForm, initFormUnits, readSpec, state,
} from "./form.js";
import { renderResults } from "./results.js";
import {
  $, $$, el, initModal, initTooltips, toast,
} from "./ui.js";
import * as views from "./views.js";

const VIEW_TITLES = {
  dashboard: ["Painel", "Visão geral"],
  editor: ["Experimento", "Cadastro e cálculo"],
  library: ["Experimentos", "Registros salvos"],
  simulate: ["Simulador", "Resposta a mudanças de parâmetro"],
  scenarios: ["Cenários", "Comparação de condições"],
  charts: ["Gráficos", "Relações entre experimentos"],
  compare: ["Comparar", "Tabela comparativa"],
  formulas: ["Referência", "Fórmulas do motor de cálculo"],
  io: ["Dados", "Importar e exportar"],
};

let currentView = "dashboard";

/* ------------------------------------------------------------ navegação */

async function navigate(view) {
  currentView = view;
  $$(".nav-item").forEach((item) =>
    item.classList.toggle("is-active", item.dataset.view === view));
  $$(".view").forEach((section) =>
    section.classList.toggle("is-active", section.dataset.view === view));

  const [eyebrow, title] = VIEW_TITLES[view] ?? ["", ""];
  $("#viewEyebrow").textContent = eyebrow;
  $("#viewTitle").textContent = title;
  $("#sidebar").classList.remove("is-open");
  window.scrollTo({ top: 0, behavior: "instant" });

  try {
    if (view === "dashboard") await views.loadDashboard();
    if (view === "library") await views.loadLibrary();
    if (view === "simulate") views.loadSimulator();
    if (view === "charts") await views.loadCharts();
    if (view === "compare") await views.loadCompare();
    if (view === "formulas") await views.loadFormulas();
  } catch (error) {
    toast(error.message, "bad");
  }
}

/* --------------------------------------------------------------- editor */

/** Desenha a lista completa de problemas devolvida pelo validador. */
function showProblems(problems, headline) {
  const host = $("#resultsHost");
  host.innerHTML = "";
  const box = el("div", { class: "warnings" });
  box.append(el("div", { class: "warning" }, headline));
  for (const problem of problems) {
    box.append(el("div", { class: "warning" },
      problem.field ? `${problem.field} — ${problem.message}` : problem.message));
  }
  host.append(box);
}

async function calculate() {
  const spec = readSpec();
  try {
    const payload = await api.calculate(spec);
    state.lastSpec = spec;
    state.lastResults = payload;
    renderResults($("#resultsHost"), payload, state.mode);
    toast("Cálculo concluído.", "good");
  } catch (error) {
    const problems = error.problems ?? [];
    if (problems.length > 1) {
      showProblems(problems,
        `${problems.length} problemas impedem o cálculo:`);
      toast(`${problems.length} problemas nos dados.`, "bad");
    } else {
      toast(error.message, "bad");
    }
  }
}

async function save() {
  const spec = readSpec();
  try {
    const saved = state.currentId
      ? await api.updateExperiment(state.currentId, spec)
      : await api.createExperiment(spec);
    state.currentId = saved.id;
    state.lastResults = saved.results;
    $("#editorState").textContent = `#${saved.id}`;
    $("#editorState").classList.add("badge-on");
    $("#btnDuplicate").disabled = false;
    renderResults($("#resultsHost"), saved.results, state.mode);
    toast(`Experimento salvo como #${saved.id}.`, "good");
  } catch (error) {
    const problems = error.problems ?? [];
    if (problems.length > 1) {
      showProblems(problems, `${problems.length} problemas impedem salvar:`);
      toast(`${problems.length} problemas nos dados.`, "bad");
    } else {
      toast(error.message, "bad");
    }
  }
}

async function duplicateCurrent() {
  if (!state.currentId) return;
  try {
    const copy = await api.duplicateExperiment(state.currentId);
    toast(`Duplicado como "${copy.name}" (#${copy.id}).`, "good");
  } catch (error) {
    toast(error.message, "bad");
  }
}

/* ----------------------------------------------------------- bootstrap */

async function start() {
  initModal();
  initTooltips();

  $$(".nav-item").forEach((item) =>
    item.addEventListener("click", () => navigate(item.dataset.view)));
  document.addEventListener("navigate", (event) => navigate(event.detail));

  $("#navToggle").addEventListener("click", () => {
    const sidebar = $("#sidebar");
    sidebar.classList.toggle("is-open");
    $("#navToggle").setAttribute("aria-expanded",
      sidebar.classList.contains("is-open"));
  });

  $$(".tab").forEach((tab) => tab.addEventListener("click", () => {
    $$(".tab").forEach((other) => other.classList.toggle("is-on", other === tab));
    $$(".tab-panel").forEach((panel) =>
      panel.classList.toggle("is-on", panel.dataset.tab === tab.dataset.tab));
  }));

  $$(".mode-btn").forEach((button) => button.addEventListener("click", () => {
    state.mode = button.dataset.mode;
    $$(".mode-btn").forEach((other) => other.classList.toggle("is-on", other === button));
    if (state.lastResults) {
      renderResults($("#resultsHost"), state.lastResults, state.mode);
    }
  }));

  $("#addReagent").addEventListener("click", () => addReagentRow());
  $("#btnCalculate").addEventListener("click", calculate);
  $("#btnSave").addEventListener("click", save);
  $("#btnDuplicate").addEventListener("click", duplicateCurrent);
  $("#btnClear").addEventListener("click", () => {
    clearForm();
    $("#editorState").textContent = "novo";
    $("#editorState").classList.remove("badge-on");
    $("#btnDuplicate").disabled = true;
    $("#resultsHost").innerHTML = "";
    toast("Formulário limpo.");
  });

  for (const id of ["#libSearch", "#libSort", "#libDir"]) {
    $(id).addEventListener("input", () => views.loadLibrary());
  }

  $("#addScenario").addEventListener("click", () => views.addScenarioRow());
  $("#runScenarios").addEventListener("click", () =>
    views.runScenarios().catch((error) => toast(error.message, "bad")));
  $("#runCompare").addEventListener("click", () =>
    views.runCompare().catch((error) => toast(error.message, "bad")));
  $("#btnImport").addEventListener("click", () =>
    views.importCsv().catch((error) => toast(error.message, "bad")));

  try {
    const [units, formulas] = await Promise.all([api.units(), api.formulas()]);
    initFormUnits(units.dimensions, formulas.faraday_constant);
  } catch (error) {
    toast(`Não foi possível carregar as unidades: ${error.message}`, "bad");
  }

  views.initSimulator();
  addReagentRow({ name: "Substrato" });
  views.addScenarioRow({ name: "Cenário A" });
  views.addScenarioRow({ name: "Cenário B" });

  await navigate("dashboard");
}

start();
