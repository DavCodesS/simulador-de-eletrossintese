/* Gráficos. Um único tema para todos, para que as cores signifiquem sempre
   a mesma coisa entre telas. */

const PALETTE = ["#0f6d78", "#a8590b", "#3d5a6c", "#6b8f3a", "#8a4f7d", "#99331f"];

const registry = new Map();

function baseOptions(xTitle, yTitle) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: "nearest", intersect: false },
    plugins: {
      legend: {
        display: true,
        labels: { boxWidth: 10, boxHeight: 10, font: { size: 11 }, usePointStyle: true },
      },
      tooltip: {
        backgroundColor: "#0e1a24",
        titleFont: { size: 11 },
        bodyFont: { size: 12, family: "ui-monospace, monospace" },
        padding: 9,
      },
    },
    scales: {
      x: {
        title: { display: Boolean(xTitle), text: xTitle, font: { size: 10 } },
        grid: { color: "#eaeff1" },
        ticks: { font: { size: 10, family: "ui-monospace, monospace" } },
      },
      y: {
        title: { display: Boolean(yTitle), text: yTitle, font: { size: 10 } },
        grid: { color: "#eaeff1" },
        ticks: { font: { size: 10, family: "ui-monospace, monospace" } },
      },
    },
  };
}

/** Cria ou atualiza um gráfico, reaproveitando o canvas. */
export function draw(canvasId, { type = "line", labels, datasets, xTitle, yTitle }) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  registry.get(canvasId)?.destroy();

  const styled = datasets.map((dataset, index) => ({
    borderColor: PALETTE[index % PALETTE.length],
    backgroundColor: type === "bar"
      ? PALETTE[index % PALETTE.length]
      : `${PALETTE[index % PALETTE.length]}22`,
    borderWidth: 2,
    pointRadius: type === "scatter" ? 5 : 2,
    pointHoverRadius: 6,
    tension: 0.18,
    spanGaps: true,
    ...dataset,
  }));

  const chart = new Chart(canvas.getContext("2d"), {
    type,
    data: { labels, datasets: styled },
    options: baseOptions(xTitle, yTitle),
  });
  registry.set(canvasId, chart);
  return chart;
}

export function destroy(canvasId) {
  registry.get(canvasId)?.destroy();
  registry.delete(canvasId);
}
