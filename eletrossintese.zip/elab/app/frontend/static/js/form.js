/* Ligação entre o formulário e o documento de entrada (ExperimentSpec).
   Campos vazios viram null — o motor então reporta "não calculável" em vez
   de calcular com um zero inventado. */

import { $, el, fillUnits, numberOf, setValue, textOf } from "./ui.js";

export const state = {
  units: {},
  currentId: null,
  lastSpec: null,
  lastResults: null,
  mode: "simple",
};

const MASS_UNITS = ["mg", "g", "ug", "kg"];
const AMOUNT_UNITS = ["mmol", "mol", "umol", "nmol"];
const VOLUME_UNITS = ["mL", "L", "uL"];
const CONCENTRATION_UNITS = ["mol/L", "mmol/L", "M", "mM"];

let reagentSeed = 0;

/* ------------------------------------------------------------- reagentes */

export function addReagentRow(data = {}) {
  const index = ++reagentSeed;
  const card = el("div", { class: "reagent-card", "data-reagent": index });

  card.append(
    el("div", { class: "reagent-head" },
      el("span", { class: "reagent-index" }, `REAGENTE ${String(index).padStart(2, "0")}`),
      el("button", {
        class: "icon-btn", type: "button", title: "Remover reagente",
        onclick: () => { card.remove(); refreshReagentSelectors(); },
      }, "✕")
    ),
    el("div", { class: "field-grid" },
      field("Nome", el("input", { type: "text", "data-f": "name",
        value: data.name ?? "", oninput: refreshReagentSelectors })),
      field("Fórmula (opcional)", el("input", { type: "text", "data-f": "formula",
        value: data.formula ?? "", placeholder: "C7H9N" })),
      field("Massa molar", unitPair(
        el("input", { type: "number", step: "any", "data-f": "molar_mass",
          value: data.molar_mass ?? "", placeholder: "—" }),
        el("span", { class: "unit-static" }, "g/mol"))),
      field("Coeficiente estequiométrico", el("input", {
        type: "number", step: "any", "data-f": "stoich_coefficient",
        value: data.stoich_coefficient ?? "", placeholder: "—" })),
      field("Massa utilizada", unitPair(
        el("input", { type: "number", step: "any", "data-f": "mass",
          value: data.mass ?? "", placeholder: "—" }),
        select("mass_unit", MASS_UNITS, data.mass_unit ?? "mg"))),
      field("Quantidade de matéria", unitPair(
        el("input", { type: "number", step: "any", "data-f": "amount",
          value: data.amount ?? "", placeholder: "—" }),
        select("amount_unit", AMOUNT_UNITS, data.amount_unit ?? "mmol"))),
      field("Concentração", unitPair(
        el("input", { type: "number", step: "any", "data-f": "concentration",
          value: data.concentration ?? "", placeholder: "—" }),
        select("concentration_unit", CONCENTRATION_UNITS,
          data.concentration_unit ?? "mol/L"))),
      field("Volume", unitPair(
        el("input", { type: "number", step: "any", "data-f": "volume",
          value: data.volume ?? "", placeholder: "—" }),
        select("volume_unit", VOLUME_UNITS, data.volume_unit ?? "mL")))
    ),
    el("p", { class: "note", style: "margin:6px 0 0" },
      "Informe massa + massa molar, ou quantidade de matéria, ou concentração + volume.")
  );

  $("#reagentList").append(card);
  refreshReagentSelectors();
  return card;
}

function field(label, control) {
  return el("label", { class: "field" }, el("span", {}, label), control);
}

function unitPair(input, unit) {
  return el("div", { class: "input-unit" }, input, unit);
}

function select(name, options, selected) {
  const node = el("select", { "data-f": name });
  for (const option of options) {
    node.append(el("option", { value: option, selected: option === selected }, option));
  }
  return node;
}

function readReagentCard(card) {
  const read = (name) => card.querySelector(`[data-f="${name}"]`);
  const num = (name) => {
    const input = read(name);
    if (!input || input.value.trim() === "") return null;
    const parsed = Number(input.value.replace(",", "."));
    return Number.isFinite(parsed) ? parsed : null;
  };
  return {
    name: read("name").value.trim(),
    formula: read("formula").value.trim(),
    molar_mass: num("molar_mass"),
    stoich_coefficient: num("stoich_coefficient"),
    mass: num("mass"),
    mass_unit: read("mass_unit").value,
    amount: num("amount"),
    amount_unit: read("amount_unit").value,
    concentration: num("concentration"),
    concentration_unit: read("concentration_unit").value,
    volume: num("volume"),
    volume_unit: read("volume_unit").value,
  };
}

export function refreshReagentSelectors() {
  const names = Array.from(document.querySelectorAll("[data-reagent]"))
    .map((card) => card.querySelector('[data-f="name"]').value.trim())
    .filter(Boolean);

  const substrate = $("#f_substrate");
  const limiting = $("#f_limiting");
  const keepSubstrate = substrate.value;
  const keepLimiting = limiting.value;

  substrate.innerHTML = "";
  substrate.append(el("option", { value: "" }, "— usar o reagente limitante —"));
  limiting.innerHTML = "";
  limiting.append(el("option", { value: "auto" }, "Determinar automaticamente"));

  for (const name of names) {
    substrate.append(el("option", { value: name }, name));
    limiting.append(el("option", { value: name }, name));
  }
  substrate.value = names.includes(keepSubstrate) ? keepSubstrate : "";
  limiting.value = names.includes(keepLimiting) ? keepLimiting : "auto";
}

/* ------------------------------------------------------------ leitura */

export function readSpec() {
  const reagents = Array.from(document.querySelectorAll("[data-reagent]"))
    .map(readReagentCard)
    .filter((reagent) => reagent.name);

  return {
    name: textOf("#f_name", "Experimento sem nome"),
    identifier: textOf("#f_identifier"),
    date: textOf("#f_date"),
    reference: textOf("#f_reference"),
    notes: textOf("#f_notes"),
    reagents,
    product: {
      name: textOf("#p_name", "Produto"),
      formula: textOf("#p_formula"),
      molar_mass: numberOf("#p_molar"),
      stoich_coefficient: numberOf("#p_coeff"),
      electrons_per_mol: numberOf("#p_electrons"),
      experimental_mass: numberOf("#p_mass"),
      experimental_mass_unit: $("#p_mass_unit").value,
      experimental_amount: numberOf("#p_amount"),
      experimental_amount_unit: $("#p_amount_unit").value,
    },
    electro: {
      current: numberOf("#f_current"),
      current_unit: $("#f_current_unit").value,
      time: numberOf("#f_time"),
      time_unit: $("#f_time_unit").value,
      voltage: numberOf("#f_voltage"),
      voltage_unit: $("#f_voltage_unit").value,
      measured_charge: numberOf("#f_charge"),
      measured_charge_unit: $("#f_charge_unit").value,
      faraday_constant: numberOf("#f_faraday"),
      assumed_current_efficiency: numberOf("#f_efficiency"),
      assumed_current_efficiency_unit: "%",
    },
    substrate_name: $("#f_substrate").value,
    limiting_selection: $("#f_limiting").value || "auto",
    yield_definition: $("#f_yielddef").value,
    theoretical_basis: $("#f_basis").value,
  };
}

/* ------------------------------------------------------------- escrita */

export function writeSpec(spec) {
  setValue("#f_name", spec.name);
  setValue("#f_identifier", spec.identifier);
  setValue("#f_date", spec.date);
  setValue("#f_reference", spec.reference);
  setValue("#f_notes", spec.notes);

  $("#reagentList").innerHTML = "";
  reagentSeed = 0;
  for (const reagent of spec.reagents ?? []) addReagentRow(reagent);
  if (!(spec.reagents ?? []).length) addReagentRow({ name: "Substrato" });

  const product = spec.product ?? {};
  setValue("#p_name", product.name);
  setValue("#p_formula", product.formula);
  setValue("#p_molar", product.molar_mass);
  setValue("#p_coeff", product.stoich_coefficient);
  setValue("#p_electrons", product.electrons_per_mol);
  setValue("#p_mass", product.experimental_mass);
  setValue("#p_amount", product.experimental_amount);
  if (product.experimental_mass_unit) $("#p_mass_unit").value = product.experimental_mass_unit;
  if (product.experimental_amount_unit) $("#p_amount_unit").value = product.experimental_amount_unit;

  const electro = spec.electro ?? {};
  setValue("#f_current", electro.current);
  setValue("#f_time", electro.time);
  setValue("#f_voltage", electro.voltage);
  setValue("#f_charge", electro.measured_charge);
  setValue("#f_faraday", electro.faraday_constant);
  setValue("#f_efficiency", electro.assumed_current_efficiency);
  for (const [id, key] of [
    ["#f_current_unit", "current_unit"], ["#f_time_unit", "time_unit"],
    ["#f_voltage_unit", "voltage_unit"], ["#f_charge_unit", "measured_charge_unit"],
  ]) if (electro[key]) $(id).value = electro[key];

  refreshReagentSelectors();
  $("#f_substrate").value = spec.substrate_name ?? "";
  $("#f_limiting").value = spec.limiting_selection ?? "auto";
  $("#f_yielddef").value = spec.yield_definition ?? "mass";
  $("#f_basis").value = spec.theoretical_basis ?? "stoichiometric";
}

export function initFormUnits(units, faradayConstant) {
  state.units = units;
  fillUnits($("#f_current_unit"), units.current, "mA");
  fillUnits($("#f_time_unit"), units.time, "min");
  fillUnits($("#f_voltage_unit"), units.voltage, "V");
  fillUnits($("#f_charge_unit"), units.charge, "C");
  fillUnits($("#p_mass_unit"), MASS_UNITS, "mg");
  fillUnits($("#p_amount_unit"), AMOUNT_UNITS, "mmol");
  setValue("#f_faraday", faradayConstant);
}

export function clearForm() {
  for (const id of ["#f_name", "#f_identifier", "#f_date", "#f_reference",
    "#f_notes", "#p_name", "#p_formula", "#p_molar", "#p_coeff", "#p_electrons",
    "#p_mass", "#p_amount", "#f_current", "#f_time", "#f_voltage", "#f_charge",
    "#f_efficiency"]) setValue(id, "");
  $("#reagentList").innerHTML = "";
  reagentSeed = 0;
  addReagentRow({ name: "Substrato" });
  state.currentId = null;
}
