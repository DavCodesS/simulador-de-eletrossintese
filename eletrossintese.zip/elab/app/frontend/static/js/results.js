/* Renderização dos resultados e da escada de derivação.

   Cada resultado carrega o botão "Como foi calculado?", que abre o rastro
   produzido pelo próprio motor — a interface não reconstrói derivação
   alguma, apenas desenha o que o backend enviou. */

import { el, openModal, significant, withUnit } from "./ui.js";

const KIND_LABEL = {
  input: "Dado informado",
  conversion: "Conversão de unidade",
  constant: "Constante",
  assumption: "Escolha de configuração",
  formula: "Fórmula",
  substitution: "Substituição dos valores",
  intermediate: "Resultado intermediário",
  result: "Resultado",
};

const GROUPS = [
  {
    title: "Rendimento",
    keys: ["yield_mass", "yield_amount"],
  },
  {
    title: "Quantidades de matéria",
    keys: ["substrate_amount", "theoretical_amount_stoich",
      "theoretical_amount_faradaic", "theoretical_amount",
      "experimental_amount"],
  },
  {
    title: "Massas",
    keys: ["theoretical_mass"],
  },
  {
    title: "Eletroquímica",
    keys: ["charge", "moles_electrons", "theoretical_charge",
      "faradaic_efficiency", "charge_per_mole", "electrons_per_substrate",
      "energy"],
  },
];

const SIMPLE_KEYS = new Set([
  "theoretical_mass", "yield_mass", "yield_amount", "charge",
]);

/* ------------------------------------------------------------- resultado */

function resultCard(outcome) {
  const isVoid = outcome.status !== "calculated";
  const classes = ["result",
    isVoid ? "is-void" : (outcome.kind === "experimental" ? "is-exp" : "")];

  const card = el("div", { class: classes.filter(Boolean).join(" ") },
    el("div", { class: "result-label" }, outcome.label),
    el("div", { class: "result-value", html: isVoid
      ? '<span style="font-size:13px;color:var(--void)">não calculável</span>'
      : withUnit(outcome.value, outcome.unit) })
  );

  if (isVoid) {
    card.append(el("div", { class: "result-void-text" }, outcome.reason));
  } else if (outcome.trace) {
    card.append(el("div", { class: "result-foot" },
      el("button", {
        class: "why", type: "button",
        onclick: () => showTrace(outcome),
      }, "Como foi calculado?")));
  }
  return card;
}

/* ---------------------------------------------- escada de derivação */

export function traceLadder(trace) {
  const ladder = el("div", { class: "ladder" });

  for (const step of trace.steps) {
    const rung = el("div", { class: `rung rung-${step.kind}` },
      el("div", { class: "rung-kind" }, KIND_LABEL[step.kind] ?? step.kind),
      el("div", { class: "rung-label" }, step.label));

    if (step.expression) {
      rung.append(el("div", { class: "rung-expr" }, step.expression));
    }
    if (step.value != null) {
      rung.append(el("div", { class: "rung-value",
        html: withUnit(step.value, step.unit, 9) }));
    }
    if (step.note) {
      rung.append(el("div", { class: "rung-note" }, step.note));
    }
    ladder.append(rung);
  }
  return ladder;
}

export function showTrace(outcome) {
  const trace = outcome.trace;
  const body = el("div");

  if (trace.formula_latex || trace.formula_id) {
    const formulaStep = trace.steps.find((step) => step.kind === "formula");
    body.append(el("div", { class: "trace-formula" },
      formulaStep?.expression ?? trace.formula_id));
  }

  body.append(traceLadder(trace));

  const references = (trace.references ?? []).filter(Boolean);
  if (references.length) {
    body.append(el("div", { class: "trace-ref" },
      `Referência: ${references.join(" · ")}`));
  }
  body.append(el("div", { class: "trace-ref" },
    "Os valores foram mantidos em precisão total durante toda a cadeia; "
    + "o arredondamento acontece só na exibição."));

  openModal(`Como foi calculado — ${outcome.label}`, body);
}

/* ------------------------------------------------------------ limitante */

function limitingCard(limiting) {
  const panel = el("article", { class: "panel" });
  const head = el("header", { class: "panel-head" },
    el("h2", {}, "Reagente limitante"));
  panel.append(head);

  const body = el("div", { class: "panel-body" });

  if (limiting.status !== "calculated") {
    body.append(el("div", { class: "result is-void" },
      el("div", { class: "result-label" }, "Não determinado"),
      el("div", { class: "result-value", html: "—" }),
      el("div", { class: "result-void-text" }, limiting.reason)));
    panel.append(body);
    return panel;
  }

  body.append(el("div", { class: "result" },
    el("div", { class: "result-label" },
      `Limitante: ${limiting.limiting_name}`
      + (limiting.forced ? " (definido por você)" : "")),
    el("div", { class: "result-value", html: withUnit(limiting.extent_mol, "mol") }),
    el("div", { class: "result-void-text" },
      "Avanço máximo de reação ξ permitido pelos reagentes declarados."),
    el("div", { class: "result-foot" },
      el("button", { class: "why", type: "button",
        onclick: () => showTrace({ label: "Reagente limitante", trace: limiting.trace }),
      }, "Como foi calculado?"))));

  const table = el("table");
  table.append(el("thead", {}, el("tr", {},
    el("th", {}, "Reagente"), el("th", {}, "n (mol)"),
    el("th", {}, "ν"), el("th", {}, "ξ = n/ν"), el("th", {}, "Origem"))));
  const tbody = el("tbody");
  for (const reagent of limiting.reagents) {
    tbody.append(el("tr", {},
      el("td", {}, reagent.name),
      el("td", { class: `num ${reagent.amount_mol == null ? "na" : ""}` },
        reagent.amount_mol == null ? "—" : significant(reagent.amount_mol)),
      el("td", { class: `num ${reagent.stoich_coefficient == null ? "na" : ""}` },
        reagent.stoich_coefficient == null ? "—" : significant(reagent.stoich_coefficient)),
      el("td", { class: `num ${reagent.extent == null ? "na" : ""}` },
        reagent.extent == null ? "—" : significant(reagent.extent)),
      el("td", {}, reagent.excluded_reason
        ? el("span", { style: "color:var(--void)" }, "excluído")
        : reagent.source)));
  }
  table.append(tbody);
  body.append(el("div", { class: "table-wrap", style: "margin-top:12px" }, table));
  panel.append(body);
  return panel;
}

/* ---------------------------------------------------------------- render */

export function renderResults(host, payload, mode = "simple") {
  host.innerHTML = "";
  const outcomes = payload.outcomes ?? {};

  /* Destaque: rendimento principal. */
  const primary = outcomes.yield_primary;
  if (primary) {
    const headline = el("div", { class: "headline" },
      el("div", {},
        el("div", { class: "headline-label" }, primary.label),
        primary.status === "calculated"
          ? el("div", { class: "headline-value", html: withUnit(primary.value, primary.unit, 5) })
          : el("div", { class: "headline-value", style: "font-size:20px" }, "não calculável")));
    if (primary.status !== "calculated") {
      headline.append(el("div", { class: "headline-void" }, primary.reason));
    } else if (primary.trace) {
      headline.append(el("button", {
        class: "btn btn-mini", type: "button",
        onclick: () => showTrace(primary),
      }, "Como foi calculado?"));
    }
    host.append(headline);
  }

  /* Avisos derivados dos próprios números. */
  if ((payload.warnings ?? []).length) {
    const box = el("div", { class: "warnings" });
    for (const warning of payload.warnings) {
      box.append(el("div", { class: "warning" }, warning));
    }
    host.append(box);
  }

  /* Grupos de resultados. */
  const panel = el("article", { class: "panel" });
  panel.append(el("header", { class: "panel-head" },
    el("h2", {}, mode === "simple" ? "Resultados essenciais" : "Todos os resultados"),
    el("span", { class: "badge badge-on" }, mode === "simple" ? "modo simples" : "modo avançado")));
  const body = el("div", { class: "panel-body" });

  if (mode === "simple") {
    body.append(inputEchoGroup(payload.spec));
  }

  for (const group of GROUPS) {
    const keys = group.keys.filter((key) =>
      outcomes[key] && (mode === "advanced" || SIMPLE_KEYS.has(key)));
    if (!keys.length) continue;

    const section = el("div", { class: "result-group" },
      el("div", { class: "result-group-title" }, group.title));
    for (const key of keys) section.append(resultCard(outcomes[key]));
    body.append(section);
  }
  panel.append(body);
  host.append(panel);

  if (mode === "advanced" && payload.limiting) {
    host.append(limitingCard(payload.limiting));
  }
}

function inputEchoGroup(spec) {
  const section = el("div", { class: "result-group" },
    el("div", { class: "result-group-title" }, "Condições informadas"));

  const rows = [];
  const substrate = (spec.reagents ?? [])[0];
  if (substrate?.mass != null) {
    rows.push(["Massa inicial de " + substrate.name, substrate.mass, substrate.mass_unit]);
  }
  const product = spec.product ?? {};
  if (product.experimental_mass != null) {
    rows.push(["Massa obtida de " + product.name,
      product.experimental_mass, product.experimental_mass_unit]);
  }
  const electro = spec.electro ?? {};
  if (electro.current != null) rows.push(["Corrente aplicada", electro.current, electro.current_unit]);
  if (electro.time != null) rows.push(["Tempo de eletrólise", electro.time, electro.time_unit]);

  if (!rows.length) {
    section.append(el("div", { class: "result is-void" },
      el("div", { class: "result-label" }, "Nenhuma condição informada"),
      el("div", { class: "result-value", html: "—" })));
    return section;
  }

  for (const [label, value, unit] of rows) {
    section.append(el("div", { class: "result is-exp" },
      el("div", { class: "result-label" }, label),
      el("div", { class: "result-value", html: withUnit(value, unit) })));
  }
  return section;
}
