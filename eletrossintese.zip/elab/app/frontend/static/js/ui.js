/* Utilidades de interface: formatação de apresentação, DOM, avisos,
   modal e tooltips. A formatação aqui espelha `formatting.py` e serve
   apenas para exibição — nunca alimenta cálculo. */

export const $ = (selector, scope = document) => scope.querySelector(selector);
export const $$ = (selector, scope = document) =>
  Array.from(scope.querySelectorAll(selector));

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value == null || value === false) continue;
    if (key === "class") node.className = value;
    else if (key === "html") node.innerHTML = value;
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? "" : value);
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(child));
  }
  return node;
}

/** N algarismos significativos, com notação científica quando necessário. */
export function significant(value, digits = 6) {
  if (value == null || Number.isNaN(value)) return "—";
  if (!Number.isFinite(value)) return "indefinido";
  if (value === 0) return "0";

  const magnitude = Math.floor(Math.log10(Math.abs(value)));
  if (magnitude < -4 || magnitude >= digits + 3) {
    const [mantissa, exponent] = value.toExponential(digits - 1).split("e");
    return `${mantissa.replace(/0+$/, "").replace(/\.$/, "")}e${Number(exponent)}`;
  }
  const decimals = Math.max(digits - 1 - magnitude, 0);
  return value.toFixed(decimals).replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
}

export function withUnit(value, unit, digits = 6) {
  if (value == null) return "—";
  return unit
    ? `${significant(value, digits)} <span class="u">${escapeHtml(unit)}</span>`
    : significant(value, digits);
}

export function escapeHtml(text) {
  return String(text ?? "").replace(/[&<>"']/g, (character) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]
  );
}

/** Lê um input numérico devolvendo null quando vazio — nunca 0. */
export function numberOf(selector) {
  const input = typeof selector === "string" ? $(selector) : selector;
  if (!input) return null;
  const raw = input.value.trim().replace(",", ".");
  if (raw === "") return null;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

export function textOf(selector, fallback = "") {
  const input = typeof selector === "string" ? $(selector) : selector;
  return input && input.value.trim() ? input.value.trim() : fallback;
}

export function setValue(selector, value) {
  const input = typeof selector === "string" ? $(selector) : selector;
  if (input) input.value = value == null ? "" : value;
}

export function fillUnits(select, units, selected) {
  if (!select) return;
  select.innerHTML = "";
  for (const unit of units) {
    select.append(el("option", { value: unit, selected: unit === selected }, unit));
  }
}

/* ------------------------------------------------------------------ toast */

export function toast(message, kind = "") {
  const host = $("#toastHost");
  const node = el("div", { class: `toast ${kind ? "toast-" + kind : ""}` }, message);
  host.append(node);
  setTimeout(() => {
    node.style.opacity = "0";
    node.style.transition = "opacity .25s";
    setTimeout(() => node.remove(), 260);
  }, kind === "bad" ? 6000 : 3200);
}

/* ------------------------------------------------------------------ modal */

export function openModal(title, content) {
  $("#modalTitle").textContent = title;
  const body = $("#modalBody");
  body.innerHTML = "";
  body.append(content);
  $("#modal").hidden = false;
  document.body.style.overflow = "hidden";
}

export function closeModal() {
  $("#modal").hidden = true;
  document.body.style.overflow = "";
}

export function initModal() {
  $("#modal").addEventListener("click", (event) => {
    if (event.target.hasAttribute("data-close")) closeModal();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !$("#modal").hidden) closeModal();
  });
}

/* ---------------------------------------------------------------- tooltip */

export function initTooltips() {
  const tip = $("#tooltip");
  const show = (event) => {
    const target = event.target.closest("[data-tip]");
    if (!target) return;
    tip.textContent = target.dataset.tip;
    tip.hidden = false;
    const box = target.getBoundingClientRect();
    tip.style.left = `${Math.min(box.left, window.innerWidth - 270)}px`;
    tip.style.top = `${box.bottom + 7}px`;
  };
  const hide = () => { tip.hidden = true; };
  document.addEventListener("mouseover", show);
  document.addEventListener("mouseout", hide);
  document.addEventListener("focusin", show);
  document.addEventListener("focusout", hide);
}

/** Agrupa chamadas rápidas — usado nos sliders do simulador. */
export function debounce(fn, delay = 220) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}
