/* Telas secundárias. Nenhuma delas calcula: todas pedem números ao backend. */

import { api } from "./api.js";
import * as charts from "./charts.js";
import { readSpec, state, writeSpec } from "./form.js";
import { renderResults } from "./results.js";
import {
  $, debounce, el, escapeHtml, significant, toast, withUnit,
} from "./ui.js";

/* Grandezas disponíveis nos gráficos, com rótulo e unidade base. */
export const METRICS = [
  ["yield_primary", "Rendimento principal", "%"],
  ["yield_mass", "Rendimento (base massa)", "%"],
  ["yield_amount", "Rendimento (base mol)", "%"],
  ["faradaic_efficiency", "Eficiência faradaica", "%"],
  ["charge_c", "Carga", "C"],
  ["current_a", "Corrente", "A"],
  ["time_s", "Tempo", "s"],
  ["theoretical_mass_g", "Massa teórica", "g"],
  ["experimental_mass_g", "Massa obtida", "g"],
  ["moles_electrons", "Elétrons", "mol"],
  ["charge_per_mole", "Carga por mol de substrato", "C/mol"],
  ["energy", "Energia elétrica", "J"],
];

const SWEEP_METRICS = [
  ["yield_primary", "Rendimento principal", "%"],
  ["yield_mass", "Rendimento (base massa)", "%"],
  ["yield_amount", "Rendimento (base mol)", "%"],
  ["theoretical_amount_faradaic", "Quantidade teórica (faradaica)", "mol"],
  ["theoretical_amount_stoich", "Quantidade teórica (estequiométrica)", "mol"],
  ["theoretical_mass", "Massa teórica", "g"],
  ["charge", "Carga", "C"],
  ["moles_electrons", "Elétrons", "mol"],
  ["faradaic_efficiency", "Eficiência faradaica", "%"],
  ["theoretical_charge", "Carga teórica", "C"],
  ["energy", "Energia elétrica", "J"],
];

const metricLabel = (key, table = METRICS) =>
  (table.find(([k]) => k === key) ?? [key, key, ""])[1];
const metricUnit = (key, table = METRICS) =>
  (table.find(([k]) => k === key) ?? [key, key, ""])[2];

/* ======================================================== PAINEL */

export async function loadDashboard() {
  const data = await api.dashboard();

  const stats = [
    ["Experimentos realizados", data.total, ""],
    ["Rendimento médio", data.average_yield, "%"],
    ["Melhor rendimento", data.best_yield, "%"],
    ["Maior eficiência faradaica", data.best_efficiency, "%"],
  ];
  const host = $("#dashStats");
  host.innerHTML = "";
  for (const [label, value, unit] of stats) {
    host.append(el("div", { class: "stat" },
      el("div", { class: "stat-label" }, label),
      el("div", { class: "stat-value", html: value == null
        ? '<span style="color:var(--void);font-size:17px">sem dados</span>'
        : withUnit(value, unit, 4) }),
      el("div", { class: "stat-note" }, value == null
        ? "Nenhum experimento com esse valor calculado."
        : "Sobre os experimentos salvos.")));
  }

  const points = data.chart ?? [];
  charts.draw("dashYieldChart", {
    type: "bar",
    labels: points.map((p) => p.identifier || p.name),
    datasets: [{ label: "Rendimento (%)",
      data: points.map((p) => p.yield_primary) }],
    yTitle: "%",
  });
  charts.draw("dashConditionsChart", {
    type: "scatter",
    datasets: [{
      label: "Carga × rendimento",
      data: points
        .filter((p) => p.charge_c != null && p.yield_primary != null)
        .map((p) => ({ x: p.charge_c, y: p.yield_primary })),
    }],
    xTitle: "Carga (C)", yTitle: "Rendimento (%)",
  });

  const recent = $("#dashRecent");
  recent.innerHTML = "";
  if (!data.recent.length) {
    recent.append(el("div", { class: "empty" },
      el("div", { class: "empty-mark" }, "sem registros"),
      el("p", {}, "Nenhum experimento salvo ainda. Abra Experimento, preencha os dados e salve.")));
    return;
  }
  recent.append(experimentTable(data.recent, { compact: true }));
}

/* ======================================================== BIBLIOTECA */

export async function loadLibrary() {
  const data = await api.listExperiments({
    search: $("#libSearch").value,
    sort: $("#libSort").value,
    direction: $("#libDir").value,
  });
  const host = $("#libraryTable");
  host.innerHTML = "";
  if (!data.items.length) {
    host.append(el("div", { class: "empty" },
      el("div", { class: "empty-mark" }, "nada encontrado"),
      el("p", {}, "Nenhum experimento corresponde à busca.")));
    return;
  }
  host.append(experimentTable(data.items, { compact: false }));
}

function experimentTable(items, { compact }) {
  const table = el("table");
  const header = el("tr", {},
    el("th", {}, "Nome"), el("th", {}, "Identificador"), el("th", {}, "Data"),
    el("th", {}, "Rendimento"), el("th", {}, "Eficiência"), el("th", {}, "Carga"));
  if (!compact) header.append(el("th", {}, ""));
  table.append(el("thead", {}, header));

  const body = el("tbody");
  for (const item of items) {
    const metrics = item.metrics ?? {};
    const row = el("tr", {},
      el("td", {}, item.name),
      el("td", {}, item.identifier || "—"),
      el("td", {}, item.date || "—"),
      numCell(metrics.yield_primary, "%"),
      numCell(metrics.faradaic_efficiency, "%"),
      numCell(metrics.charge_c, "C"));

    if (!compact) {
      row.append(el("td", {}, el("div", { class: "row-actions" },
        el("button", { class: "btn btn-mini", onclick: () => openExperiment(item.id) }, "Abrir"),
        el("a", { class: "btn btn-mini", href: `/api/experiments/${item.id}/report.pdf` }, "PDF"),
        el("button", { class: "btn btn-mini", onclick: () => duplicate(item.id) }, "Duplicar"),
        el("button", { class: "btn btn-mini btn-danger", onclick: () => remove(item.id, item.name) }, "Excluir"))));
    }
    body.append(row);
  }
  table.append(body);
  return el("div", { class: "table-wrap" }, table);
}

function numCell(value, unit) {
  return value == null
    ? el("td", { class: "num na" }, "—")
    : el("td", { class: "num", html: withUnit(value, unit, 4) });
}

async function openExperiment(id) {
  const experiment = await api.getExperiment(id);
  writeSpec(experiment.spec);
  state.currentId = id;
  state.lastResults = experiment.results;
  $("#editorState").textContent = `#${id}`;
  $("#editorState").classList.add("badge-on");
  $("#btnDuplicate").disabled = false;
  if (experiment.results) {
    renderResults($("#resultsHost"), experiment.results, state.mode);
  }
  document.dispatchEvent(new CustomEvent("navigate", { detail: "editor" }));
}

async function duplicate(id) {
  const copy = await api.duplicateExperiment(id);
  toast(`Duplicado como "${copy.name}".`, "good");
  loadLibrary();
}

async function remove(id, name) {
  if (!confirm(`Excluir "${name}"? A ação não pode ser desfeita.`)) return;
  await api.deleteExperiment(id);
  toast("Experimento excluído.");
  loadLibrary();
  loadDashboard();
}

/* ======================================================== SIMULADOR */

const SLIDERS = [
  { path: "electro.current", label: "Corrente", unit: "mA", min: 0, max: 500, step: 1 },
  { path: "electro.time", label: "Tempo", unit: "min", min: 1, max: 480, step: 1 },
  { path: "electro.assumed_current_efficiency", label: "Eficiência admitida", unit: "%", min: 0, max: 100, step: 1 },
  { path: "product.electrons_per_mol", label: "Elétrons por mol (z)", unit: "", min: 1, max: 8, step: 1 },
  { path: "product.stoich_coefficient", label: "Coeficiente do produto", unit: "", min: 0.5, max: 4, step: 0.5 },
];

let simSpec = null;

function readPath(object, path) {
  return path.split(".").reduce((node, key) => node?.[key], object);
}
function writePath(object, path, value) {
  const keys = path.split(".");
  const last = keys.pop();
  const target = keys.reduce((node, key) => node[key], object);
  target[last] = value;
}

export function initSimulator() {
  const paramSelect = $("#simParam");
  paramSelect.innerHTML = "";
  for (const slider of SLIDERS) {
    paramSelect.append(el("option", { value: slider.path }, slider.label));
  }
  const metricSelect = $("#simMetric");
  metricSelect.innerHTML = "";
  for (const [key, label] of SWEEP_METRICS) {
    metricSelect.append(el("option", { value: key }, label));
  }
  metricSelect.value = "yield_primary";
  paramSelect.addEventListener("change", runSimulation);
  metricSelect.addEventListener("change", runSimulation);
}

export function loadSimulator() {
  simSpec = readSpec();
  const host = $("#simControls");
  host.innerHTML = "";

  const initialMass = simSpec.reagents[0];
  const rows = [...SLIDERS];
  if (initialMass) {
    rows.splice(2, 0, {
      path: `reagents.0.mass`, label: `Massa de ${initialMass.name}`,
      unit: initialMass.mass_unit, min: 0, max: Math.max(1000, (initialMass.mass ?? 100) * 4), step: 1,
    });
  }

  for (const slider of rows) {
    const current = readPath(simSpec, slider.path);
    const value = current ?? slider.min;
    const row = el("div", { class: "slider-row" },
      el("div", { class: "slider-head" },
        el("span", {}, slider.label),
        el("span", { class: "slider-value", html: withUnit(value, slider.unit, 5) })),
      el("input", {
        type: "range", min: slider.min, max: slider.max, step: slider.step,
        value, "data-path": slider.path,
      }),
      el("div", { class: "slider-bounds" },
        el("span", {}, `${slider.min}`), el("span", {}, `${slider.max}`)));

    const range = row.querySelector("input");
    const readout = row.querySelector(".slider-value");
    range.addEventListener("input", () => {
      const next = Number(range.value);
      readout.innerHTML = withUnit(next, slider.unit, 5);
      writePath(simSpec, slider.path, next);
      debouncedSimulation();
    });
    host.append(row);
  }

  host.append(el("p", { class: "note", style: "margin-top:14px" },
    "Os controles partem do experimento aberto no editor. Ajuste e observe a resposta."));
  runSimulation();
}

const debouncedSimulation = debounce(() => runSimulation(), 260);

async function runSimulation() {
  if (!simSpec) return;
  const parameter = $("#simParam").value;
  const metric = $("#simMetric").value;
  const slider = SLIDERS.find((s) => s.path === parameter);

  try {
    const [sweep, point] = await Promise.all([
      api.sweep({
        spec: simSpec, parameter,
        start: slider.min, stop: slider.max, points: 40,
      }),
      api.calculate(simSpec),
    ]);

    charts.draw("simChart", {
      type: "line",
      labels: sweep.values.map((v) => significant(v, 4)),
      datasets: [{
        label: `${metricLabel(metric, SWEEP_METRICS)} (${metricUnit(metric, SWEEP_METRICS)})`,
        data: sweep.series[metric],
        fill: true,
      }],
      xTitle: `${sweep.label}${sweep.unit ? " (" + sweep.unit + ")" : ""}`,
      yTitle: metricUnit(metric, SWEEP_METRICS),
    });

    const readout = $("#simReadout");
    readout.innerHTML = "";
    for (const key of ["charge", "moles_electrons", "theoretical_amount",
      "theoretical_mass", "yield_primary", "faradaic_efficiency"]) {
      const outcome = point.outcomes[key];
      if (!outcome) continue;
      readout.append(el("div", { class: "readout" },
        el("div", { class: "readout-label" }, outcome.label),
        el("div", { class: "readout-value", html: outcome.status === "calculated"
          ? withUnit(outcome.value, outcome.unit, 5)
          : '<span style="font-size:12px;color:var(--void)">não calculável</span>' })));
    }
  } catch (error) {
    toast(error.message, "bad");
  }
}

/* ======================================================== CENÁRIOS */

let scenarioSeed = 0;

export function addScenarioRow(data = {}) {
  const index = ++scenarioSeed;
  const card = el("div", { class: "scenario-card" },
    el("label", { class: "field" }, el("span", {}, "Nome"),
      el("input", { type: "text", "data-s": "name",
        value: data.name ?? `Cenário ${index}`, placeholder: "Cenário" })),
    el("label", { class: "field" }, el("span", {}, "Corrente (mA)"),
      el("input", { type: "number", step: "any", "data-s": "current",
        value: data.current ?? "", placeholder: "manter" })),
    el("label", { class: "field" }, el("span", {}, "Tempo (min)"),
      el("input", { type: "number", step: "any", "data-s": "time",
        value: data.time ?? "", placeholder: "manter" })),
    el("button", { class: "icon-btn", type: "button",
      onclick: () => card.remove() }, "✕"));
  $("#scenarioList").append(card);
}

export async function runScenarios() {
  const spec = readSpec();
  const definitions = Array.from(document.querySelectorAll(".scenario-card")).map((card) => {
    const read = (name) => card.querySelector(`[data-s="${name}"]`).value.trim();
    const overrides = {};
    if (read("current")) overrides["electro.current"] = Number(read("current"));
    if (read("time")) overrides["electro.time"] = Number(read("time"));
    return { name: read("name") || "Cenário", overrides };
  });

  if (!definitions.length) {
    toast("Adicione ao menos um cenário.", "bad");
    return;
  }

  const data = await api.scenarios({ spec, scenarios: definitions });
  const host = $("#scenarioResults");
  host.innerHTML = "";

  const table = el("table");
  const keys = ["charge", "theoretical_amount", "theoretical_mass",
    "yield_primary", "faradaic_efficiency", "moles_electrons"];
  const units = { charge: "C", theoretical_amount: "mol", theoretical_mass: "g",
    yield_primary: "%", faradaic_efficiency: "%", moles_electrons: "mol" };
  const labels = { charge: "Carga", theoretical_amount: "Quantidade teórica",
    theoretical_mass: "Massa teórica", yield_primary: "Rendimento",
    faradaic_efficiency: "Eficiência faradaica", moles_electrons: "Elétrons" };

  table.append(el("thead", {}, el("tr", {},
    el("th", {}, "Cenário"), el("th", {}, "Alterações"),
    ...keys.map((key) => el("th", {}, labels[key])))));

  const body = el("tbody");
  for (const scenario of data.scenarios) {
    if (scenario.error) {
      body.append(el("tr", {},
        el("td", {}, scenario.name),
        el("td", { colspan: keys.length + 1, style: "color:var(--warn)" }, scenario.error)));
      continue;
    }
    const changes = Object.entries(scenario.overrides)
      .map(([path, value]) => `${path.split(".").pop()} = ${value}`).join(" · ") || "base";
    body.append(el("tr", {},
      el("td", {}, scenario.name),
      el("td", { style: "font-family:var(--mono);font-size:11px" }, changes),
      ...keys.map((key) => numCell(scenario.summary[key], units[key]))));
  }
  table.append(body);
  host.append(el("div", { class: "table-wrap" }, table));
  host.append(el("p", { class: "note", style: "margin:12px 16px" }, data.disclaimer));
  $("#scenarioResultsPanel").hidden = false;
}

/* ======================================================== GRÁFICOS */

let seriesCache = [];

export async function loadCharts() {
  const xSelect = $("#chartX");
  const ySelect = $("#chartY");
  if (!xSelect.options.length) {
    for (const [key, label, unit] of METRICS) {
      xSelect.append(el("option", { value: key }, `${label}${unit ? " (" + unit + ")" : ""}`));
      ySelect.append(el("option", { value: key }, `${label}${unit ? " (" + unit + ")" : ""}`));
    }
    xSelect.value = "charge_c";
    ySelect.value = "yield_primary";
    for (const node of [xSelect, ySelect, $("#chartType")]) {
      node.addEventListener("change", drawMainChart);
    }
  }

  const data = await api.series([]);
  seriesCache = data.points;

  const picker = $("#chartPicker");
  picker.innerHTML = "";
  for (const point of seriesCache) {
    picker.append(el("label", { class: "pick" },
      el("input", { type: "checkbox", checked: true, value: point.id,
        onchange: drawMainChart }),
      el("div", {},
        el("div", { class: "pick-name" }, point.name),
        el("div", { class: "pick-meta" },
          `${point.identifier || "sem id"} · ${point.yield_primary == null
            ? "sem rendimento" : significant(point.yield_primary, 4) + " %"}`))));
  }
  drawMainChart();
}

function drawMainChart() {
  const xKey = $("#chartX").value;
  const yKey = $("#chartY").value;
  const type = $("#chartType").value;

  const selected = new Set(Array.from(
    document.querySelectorAll("#chartPicker input:checked")).map((i) => Number(i.value)));
  const points = seriesCache.filter((p) => selected.has(p.id));

  if (type === "bar") {
    charts.draw("mainChart", {
      type: "bar",
      labels: points.map((p) => p.identifier || p.name),
      datasets: [{ label: metricLabel(yKey), data: points.map((p) => p[yKey]) }],
      yTitle: metricUnit(yKey),
    });
    return;
  }

  const pairs = points
    .filter((p) => p[xKey] != null && p[yKey] != null)
    .map((p) => ({ x: p[xKey], y: p[yKey], name: p.name }))
    .sort((a, b) => a.x - b.x);

  charts.draw("mainChart", {
    type,
    datasets: [{ label: `${metricLabel(yKey)} × ${metricLabel(xKey)}`, data: pairs,
      showLine: type === "line" }],
    xTitle: `${metricLabel(xKey)} (${metricUnit(xKey)})`,
    yTitle: `${metricLabel(yKey)} (${metricUnit(yKey)})`,
  });
}

/* ======================================================== COMPARAR */

export async function loadCompare() {
  const data = await api.listExperiments({ limit: 200 });
  const picker = $("#comparePicker");
  picker.innerHTML = "";
  if (!data.items.length) {
    picker.append(el("p", { class: "note" }, "Salve ao menos dois experimentos para comparar."));
    return;
  }
  for (const item of data.items) {
    picker.append(el("label", { class: "pick" },
      el("input", { type: "checkbox", value: item.id }),
      el("div", {},
        el("div", { class: "pick-name" }, item.name),
        el("div", { class: "pick-meta" }, `#${item.id} · ${item.date || "sem data"}`))));
  }
}

export async function runCompare() {
  const ids = Array.from(document.querySelectorAll("#comparePicker input:checked"))
    .map((input) => Number(input.value));
  if (ids.length < 2) {
    toast("Selecione pelo menos dois experimentos.", "bad");
    return;
  }
  const data = await api.compare(ids);
  const host = $("#compareTable");
  host.innerHTML = "";

  const table = el("table");
  const header = el("tr", {}, el("th", {}, "Parâmetro"));
  for (const name of data.experiments) header.append(el("th", {}, name));
  header.append(el("th", {}, "Diferença"), el("th", {}, "Diferença %"));
  table.append(el("thead", {}, header));

  const body = el("tbody");
  for (const row of data.rows) {
    const tr = el("tr", {}, el("td", {}, row.label));
    for (const entry of row.values) {
      tr.append(entry.value == null
        ? el("td", { class: "num na" }, "não calculável")
        : el("td", { class: "num", html: withUnit(entry.value, entry.unit, 5) }));
    }
    const last = row.values[row.values.length - 1];
    tr.append(
      last.delta == null
        ? el("td", { class: "num na" }, "—")
        : el("td", { class: `num ${last.delta >= 0 ? "delta-up" : "delta-down"}` },
            `${last.delta >= 0 ? "+" : ""}${significant(last.delta, 4)}`),
      last.delta_percent == null
        ? el("td", { class: "num na" }, "—")
        : el("td", { class: `num ${last.delta_percent >= 0 ? "delta-up" : "delta-down"}` },
            `${last.delta_percent >= 0 ? "+" : ""}${significant(last.delta_percent, 4)} %`));
    body.append(tr);
  }
  table.append(body);
  host.append(el("div", { class: "table-wrap" }, table));
  $("#compareResultPanel").hidden = false;
}

/* ======================================================== FÓRMULAS */

export async function loadFormulas() {
  const data = await api.formulas();
  const host = $("#formulaList");
  host.innerHTML = "";
  host.append(el("p", { class: "note" },
    `Constante de Faraday: ${data.faraday_constant} C/mol — ${data.faraday_reference}`));

  for (const formula of data.formulas) {
    const card = el("article", { class: "formula-card" },
      el("div", { class: "formula-eq" }, formula.text),
      el("div", { class: "formula-name" }, formula.name),
      formula.description && el("div", { class: "formula-desc" }, formula.description));

    const symbols = el("div", { class: "formula-symbols", html:
      formula.symbols.map((symbol) =>
        `<code>${escapeHtml(symbol.symbol)}</code> ${escapeHtml(symbol.description)} `
        + `[${escapeHtml(symbol.base_unit)}]`).join(" &nbsp;·&nbsp; ") });
    card.append(symbols);
    card.append(el("div", { class: "formula-symbols" },
      `Resultado em ${formula.result_unit}.`
      + (formula.reference ? ` Referência: ${formula.reference}` : "")));
    host.append(card);
  }
}

/* ======================================================== IMPORTAR */

export async function importCsv() {
  const file = $("#csvFile").files[0];
  if (!file) {
    toast("Escolha um arquivo CSV.", "bad");
    return;
  }
  const content = await file.text();
  const report = await api.importCsv(content, $("#csvPersist").checked);

  const host = $("#importReport");
  host.innerHTML = "";
  host.append(el("p", { class: "note", style: "margin-top:14px" },
    `${report.parsed} linha(s) lida(s), ${report.created} experimento(s) salvo(s).`));
  for (const error of report.errors) {
    host.append(el("div", { class: "warning" }, error));
  }
  toast(report.errors.length
    ? `${report.created} importado(s), ${report.errors.length} com problema.`
    : `${report.created} experimento(s) importado(s).`,
    report.errors.length ? "bad" : "good");
  loadDashboard();
}
