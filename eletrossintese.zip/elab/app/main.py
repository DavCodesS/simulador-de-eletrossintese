"""Aplicação FastAPI."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .backend.api.routes import router
from .backend.calculations.errors import CalculationError
from .backend.database.session import init_db
from .config import settings

FRONTEND_DIR = Path(__file__).resolve().parent / "frontend"
templates = Jinja2Templates(directory=str(FRONTEND_DIR / "templates"))


def create_app() -> FastAPI:
    application = FastAPI(title=settings.app_name, version=settings.version)

    init_db()

    application.mount(
        "/static", StaticFiles(directory=str(FRONTEND_DIR / "static")),
        name="static")
    application.include_router(router)

    @application.exception_handler(CalculationError)
    async def _calculation_error(_request: Request,
                                 exc: CalculationError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.http_status,
            content={"error": str(exc), "field": getattr(exc, "field", None),
                     "kind": type(exc).__name__})

    @application.get("/", response_class=HTMLResponse)
    async def index(request: Request) -> HTMLResponse:
        return templates.TemplateResponse(
            request, "index.html",
            {"app_name": settings.app_name, "version": settings.version})

    return application


app = create_app()
