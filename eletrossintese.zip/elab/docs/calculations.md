# Documentação dos cálculos

Este documento descreve **todas** as relações matemáticas implementadas no
motor, as unidades aceitas e as regras que governam quando um resultado é
calculado e quando ele é declarado não calculável.

As tabelas de fórmulas e de unidades abaixo foram geradas a partir do próprio
registro em `app/backend/calculations/formulas.py` e `units.py`. A versão viva
está sempre disponível em `GET /api/formulas` e `GET /api/units`, e na tela
**Referência → Fórmulas** da aplicação.

---

## 1. O que o motor sabe e o que ele não sabe

O motor implementa **apenas relações matemáticas universais**: definição de
carga, definição de quantidade de matéria, leis de Faraday da eletrólise,
proporção estequiométrica e as duas definições de rendimento.

Ele **não** contém nenhuma informação sobre a reação de N-metilação nem sobre
qualquer outra reação. Em particular, os seguintes valores **nunca** são
inferidos, estimados ou preenchidos por padrão:

| Parâmetro | Origem obrigatória |
|---|---|
| Coeficientes estequiométricos (`ν`) | equação balanceada do usuário |
| Elétrons por mol de produto (`z`) | protocolo experimental ou literatura |
| Eficiência de corrente admitida (`η`) | usuário, quando aplicável |
| Massas molares | usuário |
| Quais substâncias participam da reação | lista de reagentes declarada |
| Qual reagente é o substrato | escolha do usuário |

Se algum deles faltar, o resultado que dependeria dele sai com
`status = "not_calculable"`, acompanhado da lista exata do que falta. O motor
não possui um terceiro estado: não existe "valor aproximado" nem "estimativa".

---

## 2. Constante de Faraday

O valor padrão é derivado das constantes exatas do SI:

```
F = e · N_A = 1,602176634e-19 C × 6,02214076e23 mol⁻¹ = 96485,33212... C/mol
```

O usuário pode substituir esse valor por outro (por exemplo, `96485` para
conferência manual). O valor efetivamente usado aparece no rastro de todo
cálculo que depende dele.

---

## 3. As duas rotas de quantidade teórica

O sistema calcula **duas** quantidades teóricas de produto, sempre que os
dados permitirem, e **nunca as combina**:

**Rota estequiométrica** — limitada pela matéria disponível:

```
ξ    = min(n_i / ν_i)      sobre os reagentes declarados
n_p  = n_L · (ν_p / ν_L)
```

**Rota faradaica** — limitada pela carga fornecida:

```
n_p  = (Q · η) / (z · F)
```

Quando `η` não é informada, a rota faradaica usa `η = 100 %` e o rastro
registra isso como **limite superior teórico**, não como previsão.

O usuário escolhe qual das duas serve de referência para o rendimento
(`theoretical_basis`). O rótulo do resultado indica sempre qual foi usada.
Quando as duas são calculáveis e divergem, o sistema emite um aviso dizendo
qual fator está limitando — carga ou matéria.

---

## 4. As duas definições de rendimento

```
Y_m = 100 · m_exp / m_teórica       (base massa)
Y_n = 100 · n_exp / n_teórica       (base quantidade de matéria)
```

Ambas são calculadas quando possível, exibidas separadamente e **nunca
misturadas**. O `yield_primary` é uma cópia rotulada daquela que o usuário
escolheu em `yield_definition`.

As duas coincidem numericamente quando a quantidade experimental foi derivada
da mesma massa pela mesma massa molar. Se o usuário informar massa e
quantidade de forma independente e elas divergirem, o sistema avisa em vez de
escolher uma.

---

## 5. Eficiência admitida × eficiência calculada

São grandezas distintas e o software as mantém separadas:

| | Símbolo | Origem | Onde é usada |
|---|---|---|---|
| **Admitida** | `η` (entrada) | informada pelo usuário | rota faradaica e simulação |
| **Calculada** | `η` (saída) | `100 · (n_exp · z · F) / Q` | métrica do experimento realizado |

Uma nunca alimenta a outra.

---

## 6. Precisão numérica

Todos os cálculos usam ponto flutuante de 64 bits e **nenhum valor
intermediário é arredondado**. As conversões de unidade são multiplicações por
fatores exatos. O arredondamento acontece somente na conversão para texto, em
`formatting.py`, com 6 algarismos significativos por padrão e notação
científica quando a magnitude exige (`< 1e-4` ou muito grande).

Consequência prática: `m = 1 µg / 123,456 g/mol × 137,137 g/mol` devolve o
mesmo valor que a mesma conta feita à mão com precisão total, com erro
relativo abaixo de `1e-15`.

---

## 7. Rastro de cálculo

Todo resultado calculado carrega um `trace` com passos tipados, na ordem:

```
input          dado informado, na unidade em que foi digitado
conversion     conversão explícita para a unidade base
constant       constante física utilizada
assumption     escolha de configuração feita pelo usuário
formula        a fórmula simbólica
substitution   a fórmula com os números substituídos
result         o valor final
```

O rastro é produzido pela mesma função que produz o número, na mesma passagem.
A interface apenas desenha o que recebeu — ela não reconstrói derivação alguma.
Por isso é impossível o rastro exibido divergir do valor exibido.

---

## 8. Validações

As guardas ficam em `calculations/rules.py` e são chamadas por `spec.py`, de
modo que a mensagem de uma mesma regra seja idêntica em todo o sistema.

| Regra | Onde |
|---|---|
| Massa, massa molar e quantidade não podem ser negativas | `spec.py` |
| Massa molar deve ser maior que zero | `spec.py` |
| Tempo deve ser maior que zero | `spec.py` |
| Corrente e carga não podem ser negativas | `spec.py` |
| Coeficiente estequiométrico deve ser maior que zero | `spec.py` |
| Constante de Faraday deve ser maior que zero | `spec.py` |
| Eficiência admitida entre 0 % e 100 % | `spec.py` |
| Nomes de reagentes únicos | `spec.py` |
| Substrato e limitante devem existir na lista | `spec.py` |
| Denominadores não nulos | `formulas.py`, campo `nonzero` |
| Unidades da dimensão correta | `units.py` + `Formula.evaluate` |

Violações levantam `ValidationError` ou `DivisionByZeroError`, ambas com
mensagem em português apontando o campo. A API as devolve como HTTP 422.

Em paralelo, `validators/experiment_validator.py` percorre a descrição inteira
sem interromper e devolve **todos** os problemas de uma vez, incluindo nomes de
unidade inválidos. É o que alimenta `POST /api/validate` e o campo
`detail.problems` das respostas 422.

---

## 9. Avisos automáticos

Os avisos comparam apenas números já calculados; nenhum deles prevê
comportamento químico:

- rota faradaica abaixo da estequiométrica → a carga é o fator limitante;
- rota faradaica acima da estequiométrica → excesso de carga;
- rendimento acima de 100 % → revisar massa molar, coeficientes ou pureza;
- eficiência faradaica acima de 100 % → fisicamente impossível, revisar `z` e `Q`;
- as duas definições de rendimento divergem → foram informadas de forma independente.

---

## 10. Unidades aceitas

Conversões são exatas e sempre explicitadas no rastro
(`50 mA = 0.05 A`, `60 min = 3600 s`, `100 mg = 0.1 g`).

| Dimensão | Unidade base | Unidades aceitas |
|---|---|---|
| current | `A` | `A`, `mA`, `uA`, `µA`, `kA` |
| time | `s` | `s`, `ms`, `min`, `h`, `d` |
| mass | `g` | `g`, `mg`, `ug`, `µg`, `kg`, `ng` |
| amount | `mol` | `mol`, `mmol`, `umol`, `µmol`, `nmol` |
| charge | `C` | `C`, `mC`, `kC`, `mAh`, `Ah` |
| molar_mass | `g/mol` | `g/mol`, `kg/mol`, `mg/mol` |
| voltage | `V` | `V`, `mV`, `kV` |
| volume | `L` | `L`, `mL`, `uL`, `µL`, `m3` |
| concentration | `mol/L` | `mol/L`, `M`, `mmol/L`, `mM`, `uM` |
| energy | `J` | `J`, `kJ`, `Wh`, `kWh` |
| faraday | `C/mol` | `C/mol` |
| ratio | `fraction` | `fraction`, ``, `%` |

---

## 11. Catálogo de fórmulas

### `charge_from_current_time`

**Carga elétrica a partir de corrente e tempo**

```
Q = I*t
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `I` | corrente aplicada | current | `A` |
| `t` | duração da eletrólise | time | `s` |

Resultado em `C`.

Definição de carga para corrente constante (modo galvanostático).

> Referência: Definição do coulomb: 1 C = 1 A · 1 s.

---

### `moles_of_electrons`

**Quantidade de matéria de elétrons**

```
n_e = Q/F
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `Q` | carga elétrica que atravessou a célula | charge | `C` |
| `F` | constante de Faraday | faraday | `C/mol` |

Resultado em `mol`.

Primeira lei de Faraday da eletrólise.

> Referência: CODATA 2018 — F = e · N_A = 96485,33212... C/mol (valor exato por definição do SI)

> Guarda contra divisão por zero: `F` não pode(m) ser zero.

---

### `charge_from_moles_of_electrons`

**Carga a partir da quantidade de elétrons**

```
Q = n_e*F
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_e` | quantidade de matéria de elétrons | amount | `mol` |
| `F` | constante de Faraday | faraday | `C/mol` |

Resultado em `C`.

Forma inversa da primeira lei de Faraday.

> Referência: CODATA 2018 — F = e · N_A = 96485,33212... C/mol (valor exato por definição do SI)

---

### `amount_from_mass`

**Quantidade de matéria a partir da massa**

```
n = m/M
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `m` | massa da substância | mass | `g` |
| `M` | massa molar da substância | molar_mass | `g/mol` |

Resultado em `mol`.

Definição de quantidade de matéria.

> Guarda contra divisão por zero: `M` não pode(m) ser zero.

---

### `mass_from_amount`

**Massa a partir da quantidade de matéria**

```
m = n*M
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n` | quantidade de matéria | amount | `mol` |
| `M` | massa molar | molar_mass | `g/mol` |

Resultado em `g`.

Forma inversa da definição de quantidade de matéria.

---

### `amount_from_concentration`

**Quantidade de matéria a partir de concentração e volume**

```
n = c*V
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `c` | concentração em quantidade de matéria | concentration | `mol/L` |
| `V` | volume da solução | volume | `L` |

Resultado em `mol`.

Definição de concentração em quantidade de matéria.

---

### `amount_from_stoichiometry`

**Quantidade de produto pela estequiometria**

```
n_p = n_L*(nu_p/nu_L)
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_L` | quantidade de matéria do reagente limitante | amount | `mol` |
| `nu_p` | coeficiente estequiométrico do produto | ratio | `fraction` |
| `nu_L` | coeficiente estequiométrico do reagente limitante | ratio | `fraction` |

Resultado em `mol`.

Proporção estequiométrica. Os coeficientes são fornecidos pelo usuário a partir da equação balanceada do seu protocolo; o sistema não infere nenhuma estequiometria.

> Guarda contra divisão por zero: `nu_L` não pode(m) ser zero.

---

### `amount_from_charge`

**Quantidade de produto pela carga (rota faradaica)**

```
n_p = (Q*eta)/(z*F)
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `Q` | carga total aplicada | charge | `C` |
| `eta` | eficiência de corrente admitida | ratio | `fraction` |
| `z` | elétrons por mol de produto (fornecido pelo usuário) | ratio | `fraction` |
| `F` | constante de Faraday | faraday | `C/mol` |

Resultado em `mol`.

Primeira lei de Faraday aplicada ao produto. O valor de z depende do mecanismo da reação e deve vir do protocolo experimental ou da literatura; o sistema nunca o arbitra.

> Referência: CODATA 2018 — F = e · N_A = 96485,33212... C/mol (valor exato por definição do SI)

> Guarda contra divisão por zero: `z`, `F` não pode(m) ser zero.

---

### `theoretical_charge`

**Carga teórica necessária**

```
Q_th = n_p*z*F
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_p` | quantidade de matéria de produto visada | amount | `mol` |
| `z` | elétrons por mol de produto | ratio | `fraction` |
| `F` | constante de Faraday | faraday | `C/mol` |

Resultado em `C`.

Carga exigida para converter n_p mols com eficiência de 100 %.

> Referência: CODATA 2018 — F = e · N_A = 96485,33212... C/mol (valor exato por definição do SI)

---

### `faradaic_efficiency`

**Eficiência faradaica / de corrente**

```
eta = 100*(n_exp*z*F)/Q
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_exp` | quantidade de matéria de produto obtida | amount | `mol` |
| `z` | elétrons por mol de produto | ratio | `fraction` |
| `F` | constante de Faraday | faraday | `C/mol` |
| `Q` | carga total que atravessou a célula | charge | `C` |

Resultado em `%`.

Fração da carga total efetivamente convertida no produto de interesse, expressa em porcentagem.

> Referência: CODATA 2018 — F = e · N_A = 96485,33212... C/mol (valor exato por definição do SI)

> Guarda contra divisão por zero: `Q` não pode(m) ser zero.

---

### `yield_by_mass`

**Rendimento em massa**

```
Y_m = 100*m_exp/m_th
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `m_exp` | massa de produto isolada (experimental) | mass | `g` |
| `m_th` | massa teórica de produto | mass | `g` |

Resultado em `%`.

Definição por massa. Não deve ser misturada com a definição por quantidade de matéria na mesma comparação.

> Guarda contra divisão por zero: `m_th` não pode(m) ser zero.

---

### `yield_by_amount`

**Rendimento em quantidade de matéria**

```
Y_n = 100*n_exp/n_th
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_exp` | quantidade de matéria de produto obtida | amount | `mol` |
| `n_th` | quantidade de matéria teórica de produto | amount | `mol` |

Resultado em `%`.

Definição por quantidade de matéria. Coincide numericamente com a definição por massa apenas quando ambas usam a mesma massa molar.

> Guarda contra divisão por zero: `n_th` não pode(m) ser zero.

---

### `charge_per_mole`

**Carga por mol de substrato**

```
q_m = Q/n_s
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `Q` | carga total aplicada | charge | `C` |
| `n_s` | quantidade de matéria de substrato | amount | `mol` |

Resultado em `C/mol`.

Carga específica efetivamente aplicada por mol de substrato.

> Guarda contra divisão por zero: `n_s` não pode(m) ser zero.

---

### `electrons_per_mole_substrate`

**Elétrons por mol de substrato (observado)**

```
z_obs = n_e/n_s
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_e` | quantidade de matéria de elétrons | amount | `mol` |
| `n_s` | quantidade de matéria de substrato | amount | `mol` |

Resultado em `fraction`.

Razão observada entre elétrons fornecidos e substrato carregado. É uma grandeza medida, não uma dedução de mecanismo.

> Guarda contra divisão por zero: `n_s` não pode(m) ser zero.

---

### `electrical_energy`

**Energia elétrica consumida**

```
E = U*Q
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `U` | tensão média da célula | voltage | `V` |
| `Q` | carga total | charge | `C` |

Resultado em `J`.

Válida para tensão aproximadamente constante durante o ensaio.

---

### `substrate_conversion`

**Conversão do substrato**

```
X = 100*(n_0-n_f)/n_0
```

| Símbolo | Significado | Dimensão | Unidade base |
|---|---|---|---|
| `n_0` | quantidade inicial de substrato | amount | `mol` |
| `n_f` | quantidade final de substrato recuperada | amount | `mol` |

Resultado em `%`.

Fração do substrato consumida, em porcentagem.

> Guarda contra divisão por zero: `n_0` não pode(m) ser zero.

---

---

## 12. Como adicionar uma fórmula

1. Declare um objeto `Formula` em `app/backend/calculations/formulas.py`,
   passando-o por `register(...)`. Informe a dimensão de cada símbolo e liste
   em `nonzero` os símbolos que aparecem em denominador.
2. Escreva um teste em `tests/test_formulas.py` com um valor calculado à mão.
3. Se a fórmula deve entrar no fluxo do experimento, chame-a a partir de
   `electrochemistry.py` ou `stoichiometry.py` devolvendo um `Outcome`, e
   registre-a em `engine.run`.
4. Para que apareça na simulação, acrescente a chave em
   `simulation.TRACKED_METRICS`; para varrer um novo parâmetro, acrescente-o
   em `simulation.SWEEPABLE`.

Nada precisa ser alterado na API nem no frontend: o catálogo de fórmulas, a
lista de unidades e os resultados são todos descobertos em tempo de execução.

## 13. Como adicionar um tipo de reação

Não existe reação embutida no código, então "adicionar uma reação" significa
cadastrar seus parâmetros:

- os reagentes com seus coeficientes;
- o produto com seu coeficiente e seu `z`;
- opcionalmente, a referência do protocolo.

Para reaproveitar um conjunto de parâmetros, salve um experimento e use
**Duplicar**: a cópia mantém toda a configuração química e zera o
identificador, pronta para receber novos valores experimentais. Um catálogo de
modelos de reação pode ser construído sobre essa mesma estrutura sem alterar o
motor de cálculo.
