"""Fixtures compartilhadas.

O caso de referência abaixo foi calculado À MÃO e serve de âncora para os
testes numéricos. Os números foram escolhidos para darem resultados exatos:

    Substrato : M = 100 g/mol ; m = 100 mg = 0,1 g  ->  n = 1,000e-3 mol
    Produto   : M = 114 g/mol ; nu = 1              ->  n_th = 1,000e-3 mol
                                                        m_th = 0,114 g = 114 mg
    Isolado   : m_exp = 85,5 mg                     ->  Y = 75,000 %
                                                        n_exp = 7,500e-4 mol
    Elétrica  : I = 50 mA = 0,050 A ; t = 60 min = 3600 s
                Q = 0,050 x 3600 = 180 C
    Faraday   : F fixado em 96485 C/mol para conferência manual
                n(e-)  = 180 / 96485        = 1,8655749...e-3 mol
                Q_th   = 1e-3 x 2 x 96485   = 192,970 C
                eta    = 100 x (7,5e-4 x 2 x 96485) / 180 = 80,4041666... %
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.backend.calculations.spec import (  # noqa: E402
    ElectroSpec, ExperimentSpec, ProductSpec, ReagentSpec,
)

#: Constante de Faraday arredondada, usada apenas para conferência manual.
F_MANUAL = 96485.0


@pytest.fixture
def reference_spec() -> ExperimentSpec:
    """Caso de referência descrito no cabeçalho deste arquivo."""
    return ExperimentSpec(
        name="Caso de referência",
        identifier="REF-001",
        reagents=[
            ReagentSpec(name="Substrato", molar_mass=100.0, mass=100.0,
                        mass_unit="mg", stoich_coefficient=1.0,
                        role="substrate"),
        ],
        product=ProductSpec(
            name="Produto N-metilado", molar_mass=114.0,
            stoich_coefficient=1.0, electrons_per_mol=2.0,
            experimental_mass=85.5, experimental_mass_unit="mg",
        ),
        electro=ElectroSpec(
            current=50.0, current_unit="mA",
            time=60.0, time_unit="min",
            faraday_constant=F_MANUAL,
        ),
        substrate_name="Substrato",
        yield_definition="mass",
        theoretical_basis="stoichiometric",
    )


@pytest.fixture
def two_reagent_spec() -> ExperimentSpec:
    """Dois reagentes para exercitar a análise de limitante.

    A: n = 0,2 g / 100 g/mol = 2,0e-3 mol ; nu = 1 -> xi = 2,0e-3
    B: n = 0,3 g / 200 g/mol = 1,5e-3 mol ; nu = 2 -> xi = 0,75e-3  <- limitante
    """
    return ExperimentSpec(
        name="Dois reagentes",
        reagents=[
            ReagentSpec(name="A", molar_mass=100.0, mass=0.2, mass_unit="g",
                        stoich_coefficient=1.0),
            ReagentSpec(name="B", molar_mass=200.0, mass=0.3, mass_unit="g",
                        stoich_coefficient=2.0),
        ],
        product=ProductSpec(name="P", molar_mass=150.0,
                            stoich_coefficient=1.0),
        electro=ElectroSpec(faraday_constant=F_MANUAL),
        substrate_name="A",
    )
