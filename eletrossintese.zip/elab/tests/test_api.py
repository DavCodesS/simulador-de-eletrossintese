"""Testes de integração da API e da persistência.

Cada teste roda contra um banco SQLite temporário, criado antes de a
aplicação ser importada.
"""

from __future__ import annotations

import os

import pytest


@pytest.fixture(scope="session")
def application(tmp_path_factory):
    """Aplicação única por sessão, apontada para um banco temporário.

    As variáveis de ambiente são definidas ANTES do primeiro import de
    ``app.main``, que é quando ``Settings`` é congelado. Recarregar módulos
    aqui criaria classes de exceção duplicadas e quebraria ``pytest.raises``
    em outros arquivos de teste.
    """
    root = tmp_path_factory.mktemp("elab-db")
    os.environ["ELAB_DATABASE_URL"] = f"sqlite:///{root / 'test.db'}"
    os.environ["ELAB_DATA_DIR"] = str(root)
    os.environ["ELAB_OPEN_BROWSER"] = "0"

    from app.main import create_app
    return create_app()


@pytest.fixture
def client(application):
    """Cliente HTTP com as tabelas zeradas a cada teste."""
    from fastapi.testclient import TestClient

    from app.backend.database.session import engine
    from app.backend.models.experiment import Base

    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)

    with TestClient(application) as test_client:
        yield test_client


@pytest.fixture
def spec_payload():
    """Mesmo caso de referência calculado à mão no conftest."""
    return {
        "name": "Referência",
        "identifier": "REF-001",
        "reagents": [{"name": "Substrato", "molar_mass": 100.0, "mass": 100.0,
                      "mass_unit": "mg", "stoich_coefficient": 1.0}],
        "product": {"name": "Produto", "molar_mass": 114.0,
                    "stoich_coefficient": 1.0, "electrons_per_mol": 2.0,
                    "experimental_mass": 85.5, "experimental_mass_unit": "mg"},
        "electro": {"current": 50.0, "current_unit": "mA",
                    "time": 60.0, "time_unit": "min",
                    "faraday_constant": 96485.0},
        "substrate_name": "Substrato",
    }


class TestMetadata:
    def test_health(self, client) -> None:
        assert client.get("/api/health").json()["status"] == "ok"

    def test_index_page_is_served(self, client) -> None:
        response = client.get("/")
        assert response.status_code == 200
        assert "Eletrossíntese" in response.text

    def test_formula_catalog(self, client) -> None:
        data = client.get("/api/formulas").json()
        ids = {formula["id"] for formula in data["formulas"]}
        assert {"charge_from_current_time", "moles_of_electrons",
                "yield_by_mass", "yield_by_amount"} <= ids

    def test_unit_catalog(self, client) -> None:
        data = client.get("/api/units").json()
        assert "mA" in data["dimensions"]["current"]
        assert "electro.current" in data["sweepable"]


class TestCalculate:
    def test_reference_case(self, client, spec_payload) -> None:
        data = client.post("/api/calculate", json=spec_payload).json()
        assert data["summary"]["charge"] == pytest.approx(180.0)
        assert data["summary"]["yield_mass"] == pytest.approx(75.0)

    def test_trace_is_returned_with_every_calculated_outcome(
            self, client, spec_payload) -> None:
        data = client.post("/api/calculate", json=spec_payload).json()
        for outcome in data["outcomes"].values():
            if outcome["status"] == "calculated":
                assert outcome["trace"]["steps"], outcome["key"]

    def test_validation_error_returns_422_with_message(
            self, client, spec_payload) -> None:
        spec_payload["electro"]["time"] = 0
        response = client.post("/api/calculate", json=spec_payload)
        assert response.status_code == 422
        assert "tempo" in response.json()["detail"]["error"].lower()

    def test_empty_payload_does_not_crash(self, client) -> None:
        response = client.post("/api/calculate", json={})
        assert response.status_code == 200
        assert all(o["status"] == "not_calculable"
                   for o in response.json()["outcomes"].values())


class TestCrud:
    def test_create_read_update_delete(self, client, spec_payload) -> None:
        created = client.post("/api/experiments", json=spec_payload)
        assert created.status_code == 201
        experiment_id = created.json()["id"]
        assert created.json()["metrics"]["yield_primary"] == pytest.approx(75.0)

        fetched = client.get(f"/api/experiments/{experiment_id}").json()
        assert fetched["name"] == "Referência"

        spec_payload["name"] = "Renomeado"
        spec_payload["product"]["experimental_mass"] = 57.0   # 50 %
        updated = client.put(f"/api/experiments/{experiment_id}",
                             json=spec_payload).json()
        assert updated["name"] == "Renomeado"
        assert updated["metrics"]["yield_primary"] == pytest.approx(50.0)

        assert client.delete(f"/api/experiments/{experiment_id}").status_code == 204
        assert client.get(f"/api/experiments/{experiment_id}").status_code == 404

    def test_duplicate_creates_independent_record(self, client,
                                                  spec_payload) -> None:
        original = client.post("/api/experiments", json=spec_payload).json()
        copy = client.post(f"/api/experiments/{original['id']}/duplicate",
                           json={"name": ""}).json()
        assert copy["id"] != original["id"]
        assert copy["name"].endswith("(cópia)")
        assert copy["identifier"] == ""
        assert copy["metrics"]["yield_primary"] == pytest.approx(75.0)

    def test_recalculate_refreshes_stored_results(self, client,
                                                  spec_payload) -> None:
        created = client.post("/api/experiments", json=spec_payload).json()
        response = client.post(f"/api/experiments/{created['id']}/recalculate")
        assert response.status_code == 200
        assert response.json()["metrics"]["yield_primary"] == pytest.approx(75.0)

    def test_missing_record_returns_404(self, client) -> None:
        assert client.get("/api/experiments/999").status_code == 404
        assert client.delete("/api/experiments/999").status_code == 404


class TestQueries:
    def _seed(self, client, spec_payload, count=3):
        ids = []
        for index in range(count):
            payload = {**spec_payload, "name": f"Exp {index}",
                       "identifier": f"E{index}"}
            payload["product"] = {**spec_payload["product"],
                                  "experimental_mass": 57.0 + index * 10}
            ids.append(client.post("/api/experiments", json=payload).json()["id"])
        return ids

    def test_search_filters_by_name(self, client, spec_payload) -> None:
        self._seed(client, spec_payload)
        data = client.get("/api/experiments?search=Exp 1").json()
        assert [item["name"] for item in data["items"]] == ["Exp 1"]

    def test_sort_by_yield(self, client, spec_payload) -> None:
        self._seed(client, spec_payload)
        data = client.get(
            "/api/experiments?sort=yield_primary&direction=desc").json()
        yields = [item["metrics"]["yield_primary"] for item in data["items"]]
        assert yields == sorted(yields, reverse=True)

    def test_dashboard_aggregates(self, client, spec_payload) -> None:
        self._seed(client, spec_payload)
        data = client.get("/api/dashboard").json()
        assert data["total"] == 3
        assert data["average_yield"] is not None
        assert len(data["chart"]) == 3

    def test_dashboard_is_empty_but_valid_without_data(self, client) -> None:
        data = client.get("/api/dashboard").json()
        assert data["total"] == 0
        assert data["average_yield"] is None
        assert data["best_experiment"] is None

    def test_compare_two_experiments(self, client, spec_payload) -> None:
        ids = self._seed(client, spec_payload, 2)
        data = client.get(f"/api/compare?ids={ids[0]},{ids[1]}").json()
        row = next(r for r in data["rows"] if r["key"] == "yield_mass")
        assert row["values"][1]["delta"] is not None

    def test_compare_requires_two(self, client, spec_payload) -> None:
        ids = self._seed(client, spec_payload, 1)
        assert client.get(f"/api/compare?ids={ids[0]}").status_code == 422


class TestSimulationEndpoints:
    def test_sweep(self, client, spec_payload) -> None:
        data = client.post("/api/simulate/sweep", json={
            "spec": spec_payload, "parameter": "electro.current",
            "start": 10, "stop": 100, "points": 5}).json()
        assert data["series"]["charge"] == pytest.approx(
            [36.0, 117.0, 198.0, 279.0, 360.0])
        assert data["unit"] == "mA"

    def test_sweep_rejects_unknown_parameter(self, client, spec_payload) -> None:
        response = client.post("/api/simulate/sweep", json={
            "spec": spec_payload, "parameter": "produto.nome",
            "start": 1, "stop": 2, "points": 3})
        assert response.status_code == 422

    def test_scenarios(self, client, spec_payload) -> None:
        data = client.post("/api/simulate/scenarios", json={
            "spec": spec_payload,
            "scenarios": [
                {"name": "A", "overrides": {}},
                {"name": "B", "overrides": {"electro.current": 100}},
            ]}).json()
        assert data["scenarios"][0]["summary"]["charge"] == pytest.approx(180.0)
        assert data["scenarios"][1]["summary"]["charge"] == pytest.approx(360.0)
        assert "previsão" in data["disclaimer"].lower()

    def test_limiting_endpoint(self, client) -> None:
        data = client.post("/api/limiting", json={
            "reagents": [
                {"name": "A", "molar_mass": 100, "mass": 0.2, "mass_unit": "g",
                 "stoich_coefficient": 1},
                {"name": "B", "molar_mass": 200, "mass": 0.3, "mass_unit": "g",
                 "stoich_coefficient": 2},
            ],
            "product_coefficient": 1}).json()
        assert data["limiting"]["limiting_name"] == "B"
        assert data["theoretical_amount"]["value"] == pytest.approx(0.75e-3)


class TestReportsAndIO:
    def test_report_structure(self, client, spec_payload) -> None:
        created = client.post("/api/experiments", json=spec_payload).json()
        report = client.get(f"/api/experiments/{created['id']}/report").json()
        assert report["identification"]["name"] == "Referência"
        assert report["calculated"] and report["experimental"]
        assert "validação experimental" in report["disclaimer"]

    def test_pdf_report(self, client, spec_payload) -> None:
        created = client.post("/api/experiments", json=spec_payload).json()
        response = client.get(f"/api/experiments/{created['id']}/report.pdf")
        assert response.status_code == 200
        assert response.content.startswith(b"%PDF")

    @pytest.mark.parametrize("fmt, marker", [
        ("csv", b"Rendimento"), ("json", b"\"spec\""), ("xlsx", b"PK")])
    def test_exports(self, client, spec_payload, fmt, marker) -> None:
        client.post("/api/experiments", json=spec_payload)
        response = client.get(f"/api/export/{fmt}")
        assert response.status_code == 200
        assert marker in response.content

    def test_csv_template_round_trip(self, client) -> None:
        template = client.get("/api/export/template.csv").text
        response = client.post("/api/import/csv",
                               json={"content": template, "persist": True})
        data = response.json()
        assert data["created"] == 1
        assert data["errors"] == []

    def test_import_reports_bad_rows_without_aborting(self, client) -> None:
        content = (
            "nome,substrato_massa_molar,substrato_massa,tempo,tempo_unidade\n"
            "Boa,100,50,60,min\n"
            "Ruim,100,50,0,min\n"          # tempo zero -> inválida
            "Outra boa,120,80,30,min\n"
        )
        data = client.post("/api/import/csv",
                           json={"content": content, "persist": True}).json()
        assert data["created"] == 2
        assert len(data["errors"]) == 1
        assert "Linha 3" in data["errors"][0]

    def test_import_accepts_comma_decimal_separator(self, client) -> None:
        content = ("nome,substrato_massa_molar,substrato_massa\n"
                   "Vírgula,\"100,5\",\"12,25\"\n")
        data = client.post("/api/import/csv",
                           json={"content": content, "persist": True}).json()
        assert data["created"] == 1
        stored = client.get("/api/experiments").json()["items"][0]
        assert stored["spec"]["reagents"][0]["molar_mass"] == pytest.approx(100.5)

    def test_empty_csv_cells_become_none_not_zero(self, client) -> None:
        content = ("nome,substrato_massa_molar,substrato_massa,corrente\n"
                   "Vazio,100,50,\n")
        client.post("/api/import/csv", json={"content": content, "persist": True})
        stored = client.get("/api/experiments").json()["items"][0]
        assert stored["spec"]["electro"]["current"] is None


class TestPersistenceIntegrity:
    def test_stored_results_match_a_fresh_calculation(self, client,
                                                      spec_payload) -> None:
        created = client.post("/api/experiments", json=spec_payload).json()
        fresh = client.post("/api/calculate", json=spec_payload).json()
        assert created["results"]["summary"] == fresh["summary"]

    def test_mirrored_columns_match_the_results_payload(self, client,
                                                        spec_payload) -> None:
        created = client.post("/api/experiments", json=spec_payload).json()
        assert created["metrics"]["charge_c"] == pytest.approx(
            created["results"]["summary"]["charge"])
        assert created["metrics"]["current_a"] == pytest.approx(0.05)
        assert created["metrics"]["time_s"] == pytest.approx(3600.0)


class TestValidateEndpoint:
    def test_never_returns_422(self, client) -> None:
        response = client.post("/api/validate", json={
            "reagents": [{"name": "A", "molar_mass": -1}],
            "electro": {"time": 0}})
        assert response.status_code == 200
        assert response.json()["valid"] is False
        assert response.json()["error_count"] >= 2

    def test_accepts_a_valid_spec(self, client, spec_payload) -> None:
        data = client.post("/api/validate", json=spec_payload).json()
        assert data["valid"] is True
        assert data["problems"] == []

    def test_calculate_error_carries_the_full_list(self, client) -> None:
        response = client.post("/api/calculate", json={
            "reagents": [{"name": "A", "molar_mass": -1, "mass": -1}],
            "electro": {"current": -1, "time": 0}})
        assert response.status_code == 422
        assert len(response.json()["detail"]["problems"]) >= 4
