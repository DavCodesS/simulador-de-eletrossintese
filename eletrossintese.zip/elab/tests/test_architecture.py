"""Testes de arquitetura e do validador de fronteira.

Os testes de arquitetura não verificam comportamento: verificam que as
fronteiras declaradas no README continuam de pé. Eles falham no dia em que
alguém importar SQLAlchemy dentro do motor de cálculo, e essa falha é o
objetivo — é mais barato descobrir isso aqui do que seis meses depois.
"""

from __future__ import annotations

import ast
import pathlib

import pytest

from app.backend.validators import experiment_validator as validator

ROOT = pathlib.Path(__file__).resolve().parent.parent
CALCULATIONS = ROOT / "app" / "backend" / "calculations"

#: Nada disto pode aparecer dentro do motor de cálculo.
FORBIDDEN_IN_ENGINE = {
    "fastapi", "starlette", "uvicorn", "sqlalchemy", "jinja2",
    "pydantic", "app.backend.api", "app.backend.database",
    "app.backend.models", "app.backend.services", "app.config",
}


def _imported_modules(path: pathlib.Path) -> set[str]:
    """Nomes de módulo importados por um arquivo, absolutos e relativos."""
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:                      # import relativo
                found.add("." * node.level + (node.module or ""))
            elif node.module:
                found.add(node.module)
    return found


class TestEngineIsolation:
    """O motor de cálculo tem de continuar utilizável sem a aplicação web."""

    @pytest.mark.parametrize(
        "module_path",
        sorted(CALCULATIONS.glob("*.py")),
        ids=lambda path: path.name,
    )
    def test_engine_module_has_no_io_dependency(self, module_path) -> None:
        imported = _imported_modules(module_path)
        for name in imported:
            root = name.split(".")[0]
            assert root not in FORBIDDEN_IN_ENGINE, (
                f"{module_path.name} importa '{name}'. O motor de cálculo "
                "não pode depender de I/O nem do framework web."
            )
            assert not any(name.startswith(forbidden)
                           for forbidden in FORBIDDEN_IN_ENGINE), (
                f"{module_path.name} importa '{name}'."
            )

    def test_engine_runs_without_importing_the_web_app(self) -> None:
        """Um script isolado consegue calcular sem subir a aplicação."""
        import subprocess
        import sys

        script = (
            "import sys\n"
            "from app.backend.calculations.engine import run\n"
            "from app.backend.calculations.spec import ExperimentSpec\n"
            "spec = ExperimentSpec.from_dict({\n"
            "    'reagents': [{'name': 'S', 'molar_mass': 100, 'mass': 100,\n"
            "                  'mass_unit': 'mg', 'stoich_coefficient': 1}],\n"
            "    'product': {'molar_mass': 114, 'stoich_coefficient': 1,\n"
            "                'electrons_per_mol': 2,\n"
            "                'experimental_mass': 85.5,\n"
            "                'experimental_mass_unit': 'mg'},\n"
            "    'electro': {'current': 50, 'current_unit': 'mA',\n"
            "                'time': 60, 'time_unit': 'min'},\n"
            "})\n"
            "results = run(spec)\n"
            "assert abs(results.summary()['yield_mass'] - 75.0) < 1e-9\n"
            "assert 'fastapi' not in sys.modules\n"
            "assert 'sqlalchemy' not in sys.modules\n"
            "print('ok')\n"
        )
        completed = subprocess.run(
            [sys.executable, "-c", script], cwd=ROOT,
            capture_output=True, text=True, check=False)
        assert completed.returncode == 0, completed.stderr
        assert "ok" in completed.stdout


class TestNoScienceInTheBrowser:
    """O JavaScript formata e desenha; ele não calcula."""

    def test_frontend_has_no_faraday_constant(self) -> None:
        js_dir = ROOT / "app" / "frontend" / "static" / "js"
        for path in js_dir.glob("*.js"):
            source = path.read_text(encoding="utf-8")
            assert "96485" not in source, (
                f"{path.name} contém a constante de Faraday. Constantes "
                "físicas pertencem ao motor Python."
            )

    def test_frontend_does_not_reimplement_conversions(self) -> None:
        js_dir = ROOT / "app" / "frontend" / "static" / "js"
        suspicious = ("/ 1000", "* 1000", "* 3600", "/ 3600")
        for path in js_dir.glob("*.js"):
            for line in path.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith("//"):
                    continue
                for pattern in suspicious:
                    assert pattern not in line, (
                        f"{path.name}: '{line.strip()}' parece uma conversão "
                        "de unidade. Conversões pertencem a units.py."
                    )


class TestBoundaryValidator:
    """O validador acumula problemas em vez de parar no primeiro."""

    def test_reports_every_problem_at_once(self) -> None:
        problems = validator.inspect({
            "reagents": [
                {"name": "A", "molar_mass": -5, "mass": -2},
                {"name": "a", "molar_mass": 10},
            ],
            "product": {"electrons_per_mol": 0},
            "electro": {"current": -1, "time": 0},
            "substrate_name": "Inexistente",
        })
        fields = {problem.field for problem in problems}
        assert {"reagents[0].mass", "reagents[0].molar_mass",
                "product.electrons_per_mol", "electro.current",
                "electro.time", "reagents", "substrate_name"} <= fields

    def test_valid_spec_has_no_problems(self, reference_spec) -> None:
        assert validator.inspect(reference_spec) == []

    def test_detects_unknown_unit_names(self) -> None:
        problems = validator.inspect({
            "reagents": [{"name": "A", "molar_mass": 100, "mass": 1,
                          "mass_unit": "quilo"}],
            "electro": {"current": 1, "current_unit": "amperes",
                        "time": 1, "time_unit": "min"},
        })
        fields = {problem.field for problem in problems}
        assert "reagents[0].mass_unit" in fields
        assert "electro.current_unit" in fields

    def test_unit_message_lists_accepted_units(self) -> None:
        problems = validator.inspect({
            "reagents": [{"name": "A", "molar_mass": 100, "mass": 1,
                          "mass_unit": "quilo"}]})
        message = next(p.message for p in problems
                       if p.field == "reagents[0].mass_unit")
        assert "mg" in message and "g" in message

    def test_notice_does_not_block_calculation(self) -> None:
        problems = validator.inspect({
            "reagents": [{"name": "A", "molar_mass": 100,
                          "concentration": 0.5}],
        })
        notices = [p for p in problems if p.severity == "notice"]
        assert any("volume" in p.field for p in notices)
        assert validator.errors_only(problems) == []

    def test_malformed_payload_is_reported_not_raised(self) -> None:
        problems = validator.inspect({"reagents": "isto não é uma lista"})
        assert problems and problems[0].severity == "error"

    def test_agrees_with_the_engine_on_validity(self, reference_spec) -> None:
        """Se o validador aprova, o motor não deve recusar por validação."""
        assert validator.errors_only(validator.inspect(reference_spec)) == []
        reference_spec.validate()          # não deve levantar

    def test_accepts_the_dict_form_too(self, reference_spec) -> None:
        assert validator.inspect(reference_spec.as_dict()) == []
