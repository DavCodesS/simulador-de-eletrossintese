"""Testes de ponta a ponta do motor de cálculo."""

from __future__ import annotations

import pytest

from app.backend.calculations import engine
from app.backend.calculations.errors import ValidationError
from app.backend.calculations.spec import ExperimentSpec, ReagentSpec

from .conftest import F_MANUAL


class TestReferenceCase:
    """Confere o motor inteiro contra o caso calculado à mão no conftest."""

    def test_substrate_amount(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("substrate_amount") == pytest.approx(1e-3)

    def test_charge(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("charge") == pytest.approx(180.0)

    def test_moles_of_electrons(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("moles_electrons") == pytest.approx(
            180.0 / F_MANUAL, rel=1e-12)

    def test_theoretical_amount_stoichiometric(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("theoretical_amount_stoich") == pytest.approx(1e-3)
        assert results.value("theoretical_amount") == pytest.approx(1e-3)

    def test_theoretical_mass(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("theoretical_mass") == pytest.approx(0.114)

    def test_experimental_amount_from_mass(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("experimental_amount") == pytest.approx(7.5e-4)

    def test_yield_by_mass_is_75_percent(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("yield_mass") == pytest.approx(75.0)

    def test_both_yield_definitions_agree_here(self, reference_spec) -> None:
        """Coincidem porque a quantidade experimental veio da mesma massa."""
        results = engine.run(reference_spec)
        assert results.value("yield_amount") == pytest.approx(75.0)

    def test_primary_yield_follows_user_choice(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.outcomes["yield_primary"].label.endswith("(massa)")
        reference_spec.yield_definition = "amount"
        results = engine.run(reference_spec)
        assert "quantidade de matéria" in results.outcomes["yield_primary"].label

    def test_theoretical_charge(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("theoretical_charge") == pytest.approx(192.970)

    def test_faradaic_efficiency(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("faradaic_efficiency") == pytest.approx(
            80.40416666666, rel=1e-10)

    def test_charge_per_mole_substrate(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("charge_per_mole") == pytest.approx(180.0 / 1e-3)

    def test_observed_electrons_per_substrate(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        expected = (180.0 / F_MANUAL) / 1e-3
        assert results.value("electrons_per_substrate") == pytest.approx(expected)

    def test_faradaic_route_uses_100_percent_when_unset(self,
                                                        reference_spec) -> None:
        results = engine.run(reference_spec)
        assert results.value("theoretical_amount_faradaic") == pytest.approx(
            180.0 / (2 * F_MANUAL))
        trace = results.outcomes["theoretical_amount_faradaic"].trace
        notes = " ".join(s.note for s in trace.steps)
        assert "limite superior teórico" in notes

    def test_charge_shortfall_is_reported_as_warning(self,
                                                     reference_spec) -> None:
        """A carga só cobre 9,33e-4 mol dos 1,00e-3 mol estequiométricos."""
        results = engine.run(reference_spec)
        assert any("fator limitante" in w for w in results.warnings)


class TestRoutesAreNeverMerged:
    def test_both_routes_are_reported_separately(self, reference_spec) -> None:
        results = engine.run(reference_spec)
        stoich = results.value("theoretical_amount_stoich")
        faradaic = results.value("theoretical_amount_faradaic")
        assert stoich != pytest.approx(faradaic)
        assert results.outcomes["theoretical_amount_stoich"].is_ok
        assert results.outcomes["theoretical_amount_faradaic"].is_ok

    def test_switching_basis_changes_the_theoretical_used(self,
                                                          reference_spec) -> None:
        reference_spec.theoretical_basis = "faradaic"
        results = engine.run(reference_spec)
        assert results.value("theoretical_amount") == pytest.approx(
            180.0 / (2 * F_MANUAL))
        # m_th = n_th x 114 g/mol
        assert results.value("theoretical_mass") == pytest.approx(
            180.0 / (2 * F_MANUAL) * 114.0)


class TestMissingDataIsNeverInvented:
    def test_no_electrons_per_mol_blocks_faradaic_metrics(self,
                                                          reference_spec) -> None:
        reference_spec.product.electrons_per_mol = None
        results = engine.run(reference_spec)
        for key in ("theoretical_amount_faradaic", "theoretical_charge",
                    "faradaic_efficiency"):
            outcome = results.outcomes[key]
            assert outcome.status == "not_calculable"
            assert outcome.value is None
            assert "elétrons por mol de produto (z)" in outcome.missing

    def test_no_stoich_coefficient_blocks_stoichiometric_route(
            self, reference_spec) -> None:
        reference_spec.product.stoich_coefficient = None
        results = engine.run(reference_spec)
        assert results.outcomes["theoretical_amount_stoich"].status == \
            "not_calculable"
        assert results.value("theoretical_mass") is None
        assert results.value("yield_mass") is None

    def test_no_current_no_time_blocks_charge_chain(self,
                                                    reference_spec) -> None:
        reference_spec.electro.current = None
        reference_spec.electro.time = None
        results = engine.run(reference_spec)
        assert results.outcomes["charge"].status == "not_calculable"
        assert set(results.outcomes["charge"].missing) == {"corrente", "tempo"}
        assert results.outcomes["moles_electrons"].status == "not_calculable"

    def test_measured_charge_overrides_current_times_time(self,
                                                          reference_spec) -> None:
        reference_spec.electro.measured_charge = 200.0
        results = engine.run(reference_spec)
        assert results.value("charge") == pytest.approx(200.0)
        assert results.outcomes["charge"].kind == "experimental"

    def test_no_product_molar_mass_blocks_mass_yield_only(self,
                                                          reference_spec) -> None:
        reference_spec.product.molar_mass = None
        reference_spec.product.experimental_amount = 0.75
        reference_spec.product.experimental_amount_unit = "mmol"
        results = engine.run(reference_spec)
        assert results.value("yield_mass") is None
        assert results.value("yield_amount") == pytest.approx(75.0)

    def test_empty_spec_computes_nothing_and_crashes_nowhere(self) -> None:
        results = engine.run(ExperimentSpec())
        assert all(o.status == "not_calculable" for o in results.outcomes.values())
        assert results.limiting.status == "not_calculable"

    def test_every_not_calculable_outcome_explains_itself(self) -> None:
        results = engine.run(ExperimentSpec())
        for outcome in results.outcomes.values():
            assert outcome.reason or outcome.missing


class TestWarnings:
    def test_yield_above_100_percent_is_flagged(self, reference_spec) -> None:
        reference_spec.product.experimental_mass = 200.0
        results = engine.run(reference_spec)
        assert any("acima de 100" in w for w in results.warnings)

    def test_divergent_yield_definitions_are_flagged(self,
                                                     reference_spec) -> None:
        reference_spec.product.experimental_amount = 0.5   # mmol, discorda
        results = engine.run(reference_spec)
        assert any("divergem" in w for w in results.warnings)

    def test_excess_charge_is_flagged(self, reference_spec) -> None:
        reference_spec.electro.time = 600.0                # 10 h -> muita carga
        reference_spec.electro.time_unit = "min"
        results = engine.run(reference_spec)
        assert any("excesso de carga" in w for w in results.warnings)


class TestValidation:
    @pytest.mark.parametrize("field, value", [
        ("mass", -1.0),
        ("molar_mass", -50.0),
        ("amount", -0.5),
    ])
    def test_negative_reagent_values_rejected(self, field, value) -> None:
        spec = ExperimentSpec(reagents=[ReagentSpec(name="A", **{field: value})])
        with pytest.raises(ValidationError):
            engine.run(spec)

    def test_zero_molar_mass_rejected(self) -> None:
        spec = ExperimentSpec(reagents=[ReagentSpec(name="A", molar_mass=0.0)])
        with pytest.raises(ValidationError):
            engine.run(spec)

    def test_zero_time_rejected(self, reference_spec) -> None:
        reference_spec.electro.time = 0.0
        with pytest.raises(ValidationError):
            engine.run(reference_spec)

    def test_negative_current_rejected(self, reference_spec) -> None:
        reference_spec.electro.current = -5.0
        with pytest.raises(ValidationError):
            engine.run(reference_spec)

    def test_efficiency_above_100_rejected(self, reference_spec) -> None:
        reference_spec.electro.assumed_current_efficiency = 150.0
        with pytest.raises(ValidationError):
            engine.run(reference_spec)

    def test_efficiency_at_bounds_accepted(self, reference_spec) -> None:
        for value in (0.0, 100.0):
            reference_spec.electro.assumed_current_efficiency = value
            engine.run(reference_spec)

    def test_zero_stoich_coefficient_rejected(self, reference_spec) -> None:
        reference_spec.reagents[0].stoich_coefficient = 0.0
        with pytest.raises(ValidationError):
            engine.run(reference_spec)

    def test_zero_faraday_rejected(self, reference_spec) -> None:
        reference_spec.electro.faraday_constant = 0.0
        with pytest.raises(ValidationError):
            engine.run(reference_spec)

    def test_unknown_substrate_rejected(self, reference_spec) -> None:
        reference_spec.substrate_name = "Inexistente"
        with pytest.raises(ValidationError):
            engine.run(reference_spec)

    def test_safe_run_returns_message_instead_of_raising(self,
                                                         reference_spec) -> None:
        reference_spec.electro.time = 0.0
        results, error = engine.safe_run(reference_spec)
        assert results is None
        assert "tempo" in error.lower()


class TestPrecision:
    def test_no_intermediate_rounding_in_the_chain(self) -> None:
        """Massas muito pequenas devem sobreviver à cadeia completa."""
        spec = ExperimentSpec(
            reagents=[ReagentSpec(name="S", molar_mass=123.456,
                                  mass=1.0, mass_unit="ug",
                                  stoich_coefficient=1.0)],
            product=__import__(
                "app.backend.calculations.spec", fromlist=["ProductSpec"]
            ).ProductSpec(name="P", molar_mass=137.137,
                          stoich_coefficient=1.0,
                          experimental_mass=0.5, experimental_mass_unit="ug"),
            substrate_name="S",
        )
        results = engine.run(spec)
        expected_n = 1e-6 / 123.456
        assert results.value("substrate_amount") == pytest.approx(
            expected_n, rel=1e-15)
        expected_mass = expected_n * 137.137
        assert results.value("theoretical_mass") == pytest.approx(
            expected_mass, rel=1e-15)
        assert results.value("yield_mass") == pytest.approx(
            100.0 * 0.5e-6 / expected_mass, rel=1e-12)


def test_results_serialization_round_trip(reference_spec) -> None:
    import json

    results = engine.run(reference_spec)
    payload = json.loads(json.dumps(results.as_dict()))
    assert payload["outcomes"]["charge"]["value"] == pytest.approx(180.0)
    assert payload["outcomes"]["charge"]["trace"]["steps"]
    assert payload["summary"]["yield_mass"] == pytest.approx(75.0)


def test_spec_round_trip(reference_spec) -> None:
    restored = ExperimentSpec.from_dict(reference_spec.as_dict())
    assert engine.run(restored).value("yield_mass") == pytest.approx(75.0)
