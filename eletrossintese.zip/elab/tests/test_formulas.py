"""Testes do registro de fórmulas."""

from __future__ import annotations

import pytest

from app.backend.calculations import formulas as F
from app.backend.calculations.errors import DivisionByZeroError, FormulaError
from app.backend.calculations.trace import StepKind
from app.backend.calculations.units import Quantity

from .conftest import F_MANUAL


def test_charge_from_current_and_time_matches_hand_calculation() -> None:
    """Q = 0,050 A x 3600 s = 180 C (exemplo do enunciado)."""
    value, trace = F.CHARGE_FROM_CURRENT_TIME.evaluate({
        "I": Quantity.create(50.0, "mA"),
        "t": Quantity.create(60.0, "min"),
    })
    assert value == pytest.approx(180.0)
    assert trace.formula_id == "charge_from_current_time"


def test_current_symbol_is_not_the_imaginary_unit() -> None:
    """Regressão: o SymPy interpreta 'I' como unidade imaginária por padrão."""
    expression = F.CHARGE_FROM_CURRENT_TIME.expression
    assert {s.name for s in expression.free_symbols} == {"I", "t"}


def test_energy_symbol_is_not_eulers_number() -> None:
    """Regressão: 'E' seria o número de Euler no SymPy."""
    assert {s.name for s in F.SPECIFIC_ENERGY.expression.free_symbols} == {"U", "Q"}


def test_trace_contains_conversions_formula_substitution_and_result() -> None:
    _, trace = F.CHARGE_FROM_CURRENT_TIME.evaluate({
        "I": Quantity.create(50.0, "mA"),
        "t": Quantity.create(60.0, "min"),
    })
    kinds = [s.kind for s in trace.steps]
    assert StepKind.INPUT in kinds
    assert StepKind.CONVERSION in kinds
    assert StepKind.FORMULA in kinds
    assert StepKind.SUBSTITUTION in kinds
    assert kinds[-1] is StepKind.RESULT

    conversions = [s.expression for s in trace.steps
                   if s.kind is StepKind.CONVERSION]
    assert any("0.05" in c and "mA" in c for c in conversions)
    assert any("3600" in c and "min" in c for c in conversions)


def test_no_conversion_step_when_already_in_base_unit() -> None:
    _, trace = F.CHARGE_FROM_CURRENT_TIME.evaluate({
        "I": Quantity.create(0.05, "A"),
        "t": Quantity.create(3600.0, "s"),
    })
    assert not [s for s in trace.steps if s.kind is StepKind.CONVERSION]


def test_moles_of_electrons_hand_calculation() -> None:
    """n(e-) = 180 / 96485 = 1,8655749...e-3 mol."""
    value, _ = F.MOLES_OF_ELECTRONS.evaluate({
        "Q": Quantity.create(180.0, "C"),
        "F": F.faraday(F_MANUAL),
    })
    assert value == pytest.approx(180.0 / 96485.0, rel=1e-12)
    assert value == pytest.approx(1.8655749e-3, rel=1e-6)


def test_amount_from_mass_hand_calculation() -> None:
    """n = 0,100 g / 100 g/mol = 1,000e-3 mol."""
    value, _ = F.AMOUNT_FROM_MASS.evaluate({
        "m": Quantity.create(100.0, "mg"),
        "M": Quantity.create(100.0, "g/mol"),
    })
    assert value == pytest.approx(1e-3, rel=1e-15)


def test_mass_from_amount_hand_calculation() -> None:
    """m = 1,000e-3 mol x 114 g/mol = 0,114 g."""
    value, _ = F.MASS_FROM_AMOUNT.evaluate({
        "n": Quantity.create(1.0, "mmol"),
        "M": Quantity.create(114.0, "g/mol"),
    })
    assert value == pytest.approx(0.114, rel=1e-15)


def test_amount_from_concentration() -> None:
    """n = 0,25 mol/L x 20 mL = 5,0e-3 mol."""
    value, _ = F.AMOUNT_FROM_CONCENTRATION.evaluate({
        "c": Quantity.create(0.25, "mol/L"),
        "V": Quantity.create(20.0, "mL"),
    })
    assert value == pytest.approx(5e-3)


def test_yield_by_mass_hand_calculation() -> None:
    """Y = 100 x 85,5 / 114 = 75,000 %."""
    value, _ = F.YIELD_BY_MASS.evaluate({
        "m_exp": Quantity.create(85.5, "mg"),
        "m_th": Quantity.create(114.0, "mg"),
    })
    assert value == pytest.approx(75.0)
    assert F.YIELD_BY_MASS.result_unit == "%"


def test_yield_by_amount_hand_calculation() -> None:
    value, _ = F.YIELD_BY_AMOUNT.evaluate({
        "n_exp": Quantity.create(0.75, "mmol"),
        "n_th": Quantity.create(1.0, "mmol"),
    })
    assert value == pytest.approx(75.0)


def test_theoretical_charge_hand_calculation() -> None:
    """Q_th = 1,0e-3 mol x 2 x 96485 C/mol = 192,970 C."""
    value, _ = F.THEORETICAL_CHARGE.evaluate({
        "n_p": Quantity.create(1.0, "mmol"),
        "z": F.ratio(2.0),
        "F": F.faraday(F_MANUAL),
    })
    assert value == pytest.approx(192.970, rel=1e-12)


def test_faradaic_efficiency_hand_calculation() -> None:
    """eta = 100 x (7,5e-4 x 2 x 96485) / 180 = 80,4041666... %."""
    value, _ = F.FARADAIC_EFFICIENCY.evaluate({
        "n_exp": Quantity.create(7.5e-4, "mol"),
        "z": F.ratio(2.0),
        "F": F.faraday(F_MANUAL),
        "Q": Quantity.create(180.0, "C"),
    })
    assert value == pytest.approx(80.40416666666, rel=1e-10)


def test_amount_from_charge_with_efficiency_in_percent() -> None:
    """n = (180 x 0,80) / (2 x 96485) = 7,46227...e-4 mol."""
    value, _ = F.AMOUNT_FROM_CHARGE.evaluate({
        "Q": Quantity.create(180.0, "C"),
        "eta": F.ratio(80.0, "%"),
        "z": F.ratio(2.0),
        "F": F.faraday(F_MANUAL),
    })
    assert value == pytest.approx(144.0 / 192970.0, rel=1e-12)


def test_stoichiometric_ratio_uses_user_coefficients() -> None:
    """n_p = 2,0e-3 x (3 / 2) = 3,0e-3 mol."""
    value, _ = F.AMOUNT_FROM_STOICHIOMETRY.evaluate({
        "n_L": Quantity.create(2.0, "mmol"),
        "nu_p": F.ratio(3.0),
        "nu_L": F.ratio(2.0),
    })
    assert value == pytest.approx(3e-3)


def test_substrate_conversion() -> None:
    """X = 100 x (1,0 - 0,4) / 1,0 = 60 %."""
    value, _ = F.CONVERSION_FRACTION.evaluate({
        "n_0": Quantity.create(1.0, "mmol"),
        "n_f": Quantity.create(0.4, "mmol"),
    })
    assert value == pytest.approx(60.0)


class TestGuards:
    def test_zero_molar_mass_raises_division_by_zero(self) -> None:
        with pytest.raises(DivisionByZeroError):
            F.AMOUNT_FROM_MASS.evaluate({
                "m": Quantity.create(1.0, "g"),
                "M": Quantity.create(0.0, "g/mol"),
            })

    def test_zero_theoretical_mass_raises_division_by_zero(self) -> None:
        with pytest.raises(DivisionByZeroError):
            F.YIELD_BY_MASS.evaluate({
                "m_exp": Quantity.create(1.0, "g"),
                "m_th": Quantity.create(0.0, "g"),
            })

    def test_zero_charge_in_efficiency_raises(self) -> None:
        with pytest.raises(DivisionByZeroError):
            F.FARADAIC_EFFICIENCY.evaluate({
                "n_exp": Quantity.create(1e-3, "mol"),
                "z": F.ratio(2.0),
                "F": F.faraday(),
                "Q": Quantity.create(0.0, "C"),
            })

    def test_missing_symbol_raises(self) -> None:
        with pytest.raises(FormulaError):
            F.CHARGE_FROM_CURRENT_TIME.evaluate({"I": Quantity.create(1.0, "A")})

    def test_extra_symbol_raises(self) -> None:
        with pytest.raises(FormulaError):
            F.CHARGE_FROM_CURRENT_TIME.evaluate({
                "I": Quantity.create(1.0, "A"),
                "t": Quantity.create(1.0, "s"),
                "x": Quantity.create(1.0, "s"),
            })

    def test_wrong_dimension_raises(self) -> None:
        with pytest.raises(FormulaError):
            F.CHARGE_FROM_CURRENT_TIME.evaluate({
                "I": Quantity.create(1.0, "mg"),
                "t": Quantity.create(1.0, "s"),
            })

    def test_unknown_formula_id_raises(self) -> None:
        with pytest.raises(FormulaError):
            F.get("formula_inexistente")


def test_catalog_is_serializable_and_complete() -> None:
    catalog = F.catalog()
    assert len(catalog) == len(F.FORMULAS)
    for entry in catalog:
        assert entry["id"] and entry["text"] and entry["symbols"]
        assert entry["result_unit"]


def test_faraday_constant_value() -> None:
    """F = e x N_A, com e e N_A exatos no SI."""
    assert F.FARADAY_CONSTANT == pytest.approx(
        1.602176634e-19 * 6.02214076e23, rel=1e-12)
