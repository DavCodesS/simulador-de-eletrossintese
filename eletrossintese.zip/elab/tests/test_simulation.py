"""Testes de simulação, cenários e comparação."""

from __future__ import annotations

import pytest

from app.backend.calculations import engine, simulation as sim
from app.backend.calculations.errors import ValidationError

from .conftest import F_MANUAL


class TestOverrides:
    def test_override_electro_field(self, reference_spec) -> None:
        clone = sim.apply_overrides(reference_spec, {"electro.current": 100.0})
        assert clone.electro.current == 100.0
        assert reference_spec.electro.current == 50.0    # original intacto

    def test_override_reagent_by_name(self, reference_spec) -> None:
        clone = sim.apply_overrides(
            reference_spec, {"reagents[Substrato].mass": 200.0})
        assert clone.reagents[0].mass == 200.0

    def test_invalid_path_raises(self, reference_spec) -> None:
        with pytest.raises(ValidationError):
            sim.apply_overrides(reference_spec, {"electro.inexistente": 1.0})

    def test_unknown_reagent_raises(self, reference_spec) -> None:
        with pytest.raises(ValidationError):
            sim.apply_overrides(reference_spec, {"reagents[Zed].mass": 1.0})


class TestSweep:
    def test_charge_is_linear_in_current(self, reference_spec) -> None:
        result = sim.sweep(reference_spec, "electro.current", 10.0, 100.0, 10)
        charges = result.series["charge"]
        # Q = I(mA) x 1e-3 x 3600 s
        for current, charge in zip(result.values, charges):
            assert charge == pytest.approx(current * 1e-3 * 3600.0)

    def test_sweep_reports_the_unit_of_the_swept_parameter(
            self, reference_spec) -> None:
        result = sim.sweep(reference_spec, "electro.current", 10.0, 100.0, 5)
        assert result.unit == "mA"
        assert result.label == "Corrente"

    def test_faradaic_theoretical_grows_with_time(self, reference_spec) -> None:
        result = sim.sweep(reference_spec, "electro.time", 10.0, 120.0, 12)
        series = result.series["theoretical_amount_faradaic"]
        assert all(a < b for a, b in zip(series, series[1:]))

    def test_stoichiometric_theoretical_is_flat_under_current_sweep(
            self, reference_spec) -> None:
        """A rota estequiométrica não depende da corrente — e não deve mudar."""
        result = sim.sweep(reference_spec, "electro.current", 10.0, 100.0, 6)
        series = result.series["theoretical_amount_stoich"]
        assert all(v == pytest.approx(1e-3) for v in series)

    def test_efficiency_sweep_scales_faradaic_route_linearly(
            self, reference_spec) -> None:
        result = sim.sweep(
            reference_spec, "electro.assumed_current_efficiency",
            0.0, 100.0, 5)
        series = result.series["theoretical_amount_faradaic"]
        full = 180.0 / (2 * F_MANUAL)
        assert series[0] == pytest.approx(0.0)
        assert series[-1] == pytest.approx(full)
        assert series[2] == pytest.approx(full * 0.5)

    def test_invalid_points_rejected(self, reference_spec) -> None:
        with pytest.raises(ValidationError):
            sim.sweep(reference_spec, "electro.current", 1.0, 10.0, 1)
        with pytest.raises(ValidationError):
            sim.sweep(reference_spec, "electro.current", 1.0, 10.0, 1000)

    def test_non_sweepable_parameter_rejected(self, reference_spec) -> None:
        with pytest.raises(ValidationError):
            sim.sweep(reference_spec, "product.name", 1.0, 10.0, 5)

    def test_invalid_points_do_not_abort_the_sweep(self, reference_spec) -> None:
        """t = 0 é inválido; o ponto vira None e a varredura continua."""
        result = sim.sweep(reference_spec, "electro.time", 0.0, 60.0, 4)
        assert result.series["charge"][0] is None
        assert result.errors[0] is not None
        assert result.series["charge"][-1] == pytest.approx(180.0)

    def test_result_carries_the_projection_disclaimer(self,
                                                      reference_spec) -> None:
        payload = sim.sweep(reference_spec, "electro.current",
                            10.0, 50.0, 3).as_dict()
        assert "não constituem previsão" in payload["disclaimer"].lower()


class TestScenarios:
    def test_scenarios_are_evaluated_independently(self, reference_spec) -> None:
        evaluated = sim.scenarios(reference_spec, [
            {"name": "A", "overrides": {"electro.current": 50.0}},
            {"name": "B", "overrides": {"electro.current": 100.0}},
            {"name": "C", "overrides": {"electro.time": 120.0}},
        ])
        assert [s.name for s in evaluated] == ["A", "B", "C"]
        charges = [s.results.value("charge") for s in evaluated]
        assert charges == pytest.approx([180.0, 360.0, 360.0])

    def test_failing_scenario_does_not_break_the_batch(self,
                                                       reference_spec) -> None:
        evaluated = sim.scenarios(reference_spec, [
            {"name": "ok", "overrides": {}},
            {"name": "ruim", "overrides": {"electro.time": 0.0}},
        ])
        assert evaluated[0].error == ""
        assert evaluated[1].error and evaluated[1].results is None

    def test_scenario_is_serializable(self, reference_spec) -> None:
        payload = sim.scenarios(
            reference_spec, [{"name": "A", "overrides": {}}])[0].as_dict()
        assert payload["summary"]["charge"] == pytest.approx(180.0)


class TestCompare:
    def test_absolute_and_percent_differences(self, reference_spec) -> None:
        a = engine.run(reference_spec)
        b = engine.run(sim.apply_overrides(
            reference_spec, {"electro.current": 100.0}))
        table = sim.compare([("A", a), ("B", b)])
        row = next(r for r in table["rows"] if r["key"] == "charge")
        assert row["values"][0]["value"] == pytest.approx(180.0)
        assert row["values"][1]["delta"] == pytest.approx(180.0)
        assert row["values"][1]["delta_percent"] == pytest.approx(100.0)

    def test_not_calculable_rows_have_no_difference(self,
                                                    reference_spec) -> None:
        a = engine.run(reference_spec)
        b = engine.run(sim.apply_overrides(
            reference_spec, {"product.electrons_per_mol": None}))
        table = sim.compare([("A", a), ("B", b)])
        row = next(r for r in table["rows"]
                   if r["key"] == "faradaic_efficiency")
        assert row["values"][1]["status"] == "not_calculable"
        assert row["values"][1]["delta"] is None

    def test_single_experiment_rejected(self, reference_spec) -> None:
        with pytest.raises(ValidationError):
            sim.compare([("A", engine.run(reference_spec))])
