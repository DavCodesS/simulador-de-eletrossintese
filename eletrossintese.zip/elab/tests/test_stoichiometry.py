"""Testes da análise estequiométrica e de reagente limitante."""

from __future__ import annotations

import pytest

from app.backend.calculations import stoichiometry as st
from app.backend.calculations.errors import ValidationError
from app.backend.calculations.spec import ExperimentSpec, ReagentSpec


def make(name: str, **kwargs) -> ReagentSpec:
    return ReagentSpec(name=name, **kwargs)


class TestAmountOf:
    def test_from_mass_and_molar_mass(self) -> None:
        entry = st.amount_of(make("A", molar_mass=100.0, mass=250.0,
                                  mass_unit="mg", stoich_coefficient=1.0))
        assert entry.amount_mol == pytest.approx(2.5e-3)
        assert entry.source == "massa e massa molar"

    def test_direct_amount_takes_precedence(self) -> None:
        entry = st.amount_of(make("A", molar_mass=100.0, mass=250.0,
                                  amount=1.0, amount_unit="mmol",
                                  stoich_coefficient=1.0))
        assert entry.amount_mol == pytest.approx(1e-3)
        assert entry.source == "quantidade de matéria informada"

    def test_from_concentration_and_volume(self) -> None:
        entry = st.amount_of(make("A", concentration=0.5,
                                  concentration_unit="mol/L",
                                  volume=10.0, volume_unit="mL",
                                  stoich_coefficient=1.0))
        assert entry.amount_mol == pytest.approx(5e-3)
        assert entry.source == "concentração e volume"

    def test_mass_without_molar_mass_is_not_calculable(self) -> None:
        entry = st.amount_of(make("A", mass=250.0, stoich_coefficient=1.0))
        assert entry.amount_mol is None
        assert entry.usable is False
        assert "massa molar" in entry.excluded_reason

    def test_no_data_yields_no_silent_default(self) -> None:
        entry = st.amount_of(make("A", stoich_coefficient=1.0))
        assert entry.amount_mol is None      # nunca 0, nunca 1


class TestLimiting:
    def test_identifies_limiting_by_smallest_extent(self,
                                                    two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents)
        assert analysis.status == "calculated"
        assert analysis.limiting_name == "B"
        assert analysis.extent_mol == pytest.approx(0.75e-3)

    def test_extents_are_computed_for_every_usable_reagent(
            self, two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents)
        extents = {a.name: a.extent for a in analysis.amounts}
        assert extents["A"] == pytest.approx(2.0e-3)
        assert extents["B"] == pytest.approx(0.75e-3)

    def test_missing_coefficient_excludes_reagent(self) -> None:
        reagents = [
            make("A", molar_mass=100.0, mass=0.2, mass_unit="g",
                 stoich_coefficient=1.0),
            make("B", molar_mass=200.0, mass=0.3, mass_unit="g"),  # sem nu
        ]
        analysis = st.analyse_limiting(reagents)
        assert analysis.limiting_name == "A"
        excluded = next(a for a in analysis.amounts if a.name == "B")
        assert excluded.usable is False

    def test_no_reagents_is_not_calculable(self) -> None:
        analysis = st.analyse_limiting([])
        assert analysis.status == "not_calculable"
        assert analysis.limiting_name is None

    def test_all_reagents_unusable_is_not_calculable(self) -> None:
        analysis = st.analyse_limiting([make("A"), make("B")])
        assert analysis.status == "not_calculable"

    def test_single_reagent_is_flagged_as_trivial(self) -> None:
        analysis = st.analyse_limiting([
            make("A", molar_mass=100.0, mass=0.2, mass_unit="g",
                 stoich_coefficient=1.0)])
        assert analysis.limiting_name == "A"
        notes = " ".join(s.note for s in analysis.trace.steps)
        assert "por construção" in notes

    def test_user_can_force_the_limiting_reagent(self, two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents, "A")
        assert analysis.limiting_name == "A"
        assert analysis.forced is True
        assert analysis.extent_mol == pytest.approx(2.0e-3)

    def test_forcing_an_unusable_reagent_raises(self) -> None:
        reagents = [
            make("A", molar_mass=100.0, mass=0.2, mass_unit="g",
                 stoich_coefficient=1.0),
            make("B"),
        ]
        with pytest.raises(ValidationError):
            st.analyse_limiting(reagents, "B")

    def test_trace_shows_every_step(self, two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents)
        text = " ".join(
            f"{s.label} {s.expression} {s.note}" for s in analysis.trace.steps)
        assert "xi_i = n_i / nu_i" in text
        assert "argmin" in text


class TestTheoreticalFromStoichiometry:
    def test_uses_user_coefficients(self, two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents)
        outcome = st.theoretical_amount_from_stoichiometry(analysis, 1.0, "P")
        # n_L = 1,5e-3 ; nu_p = 1 ; nu_L = 2 -> n_p = 1,5e-3 x 1/2 = 0,75e-3
        # equivale a xi x nu_p = 0,75e-3 x 1
        assert outcome.value == pytest.approx(0.75e-3)

    def test_product_coefficient_two_doubles_the_amount(
            self, two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents)
        outcome = st.theoretical_amount_from_stoichiometry(analysis, 2.0, "P")
        # xi x nu_p = 0,75e-3 x 2 = 1,5e-3
        assert outcome.value == pytest.approx(1.5e-3)

    def test_missing_product_coefficient_is_not_calculable(
            self, two_reagent_spec) -> None:
        analysis = st.analyse_limiting(two_reagent_spec.reagents)
        outcome = st.theoretical_amount_from_stoichiometry(analysis, None, "P")
        assert outcome.status == "not_calculable"
        assert outcome.value is None
        assert "coeficiente estequiométrico do produto" in outcome.missing

    def test_not_calculable_when_limiting_unknown(self) -> None:
        analysis = st.analyse_limiting([])
        outcome = st.theoretical_amount_from_stoichiometry(analysis, 1.0, "P")
        assert outcome.status == "not_calculable"


def test_duplicate_reagent_names_are_rejected() -> None:
    spec = ExperimentSpec(reagents=[make("A", molar_mass=1.0),
                                    make("a", molar_mass=1.0)])
    with pytest.raises(ValidationError):
        spec.validate()
