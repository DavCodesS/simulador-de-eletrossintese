"""Testes da camada de unidades."""

from __future__ import annotations

import math

import pytest

from app.backend.calculations.errors import (
    IncompatibleUnitError, UnknownUnitError,
)
from app.backend.calculations.units import (
    Quantity, base_unit, convert, from_base, to_base,
)


@pytest.mark.parametrize("value, unit, expected", [
    (50.0, "mA", 0.050),          # mA -> A
    (1.0, "A", 1.0),
    (2500.0, "uA", 2.5e-3),
])
def test_current_to_base(value: float, unit: str, expected: float) -> None:
    assert to_base(value, unit, "current") == pytest.approx(expected)


@pytest.mark.parametrize("value, unit, expected", [
    (60.0, "min", 3600.0),        # min -> s
    (1.5, "h", 5400.0),           # h   -> s
    (90.0, "s", 90.0),
])
def test_time_to_base(value: float, unit: str, expected: float) -> None:
    assert to_base(value, unit, "time") == pytest.approx(expected)


@pytest.mark.parametrize("value, unit, expected", [
    (100.0, "mg", 0.1),           # mg -> g
    (2.0, "kg", 2000.0),
    (500.0, "ug", 5e-4),
])
def test_mass_to_base(value: float, unit: str, expected: float) -> None:
    assert to_base(value, unit, "mass") == pytest.approx(expected)


@pytest.mark.parametrize("value, unit, expected", [
    (1.0, "mmol", 1e-3),
    (250.0, "umol", 2.5e-4),
    (3.0, "mol", 3.0),
])
def test_amount_to_base(value: float, unit: str, expected: float) -> None:
    assert to_base(value, unit, "amount") == pytest.approx(expected)


def test_micro_sign_and_ascii_are_equivalent() -> None:
    assert to_base(1.0, "µmol", "amount") == to_base(1.0, "umol", "amount")
    assert to_base(1.0, "µA", "current") == to_base(1.0, "uA", "current")


def test_chained_conversion_round_trip_is_exact_enough() -> None:
    """Converter ida e volta não pode acumular erro relevante."""
    original = 137.42
    there = convert(original, "mg", "kg", "mass")
    back = convert(there, "kg", "mg", "mass")
    assert back == pytest.approx(original, rel=1e-15)


def test_mah_is_charge_not_current() -> None:
    assert to_base(1.0, "mAh", "charge") == pytest.approx(3.6)
    assert to_base(1.0, "Ah", "charge") == pytest.approx(3600.0)


def test_percent_converts_to_fraction() -> None:
    assert to_base(80.0, "%", "ratio") == pytest.approx(0.8)
    assert from_base(0.8, "%", "ratio") == pytest.approx(80.0)


def test_incompatible_dimensions_raise() -> None:
    with pytest.raises(IncompatibleUnitError):
        convert(1.0, "mg", "min")


def test_unknown_unit_raises() -> None:
    with pytest.raises(UnknownUnitError):
        to_base(1.0, "parsec")


def test_declared_dimension_mismatch_raises() -> None:
    with pytest.raises(IncompatibleUnitError):
        to_base(1.0, "mg", "time")


def test_base_units() -> None:
    assert base_unit("charge") == "C"
    assert base_unit("amount") == "mol"
    assert base_unit("mass") == "g"


class TestQuantity:
    def test_base_value_and_flag(self) -> None:
        q = Quantity.create(50.0, "mA")
        assert q.dimension == "current"
        assert q.base_value == pytest.approx(0.05)
        assert q.is_converted() is True

    def test_no_conversion_flag_for_base_unit(self) -> None:
        assert Quantity.create(2.0, "A").is_converted() is False

    def test_to_returns_new_instance(self) -> None:
        q = Quantity.create(3600.0, "s")
        other = q.to("min")
        assert other.value == pytest.approx(60.0)
        assert q.value == 3600.0     # imutável

    def test_registry_has_no_ambiguous_units(self) -> None:
        """Invariante: nenhuma string de unidade pertence a duas dimensões.

        Se alguém adicionar uma unidade ambígua ao registro, este teste
        quebra e obriga a decidir explicitamente como desambiguá-la.
        """
        from collections import Counter

        from app.backend.calculations.units import UNIT_REGISTRY

        counts = Counter(
            unit for units in UNIT_REGISTRY.values() for unit in units)
        assert [u for u, n in counts.items() if n > 1] == []

    def test_ambiguity_guard_raises_when_triggered(self, monkeypatch) -> None:
        from app.backend.calculations import units as units_module

        monkeypatch.setitem(units_module._UNIT_INDEX, "X", ["mass", "time"])
        with pytest.raises(IncompatibleUnitError):
            units_module.dimension_of("X")
        assert units_module.dimension_of("X", "mass") == "mass"

    def test_negative_values_are_allowed_at_this_layer(self) -> None:
        """A camada de unidades converte; quem julga o sinal é o validador."""
        assert Quantity.create(-5.0, "mg").base_value == pytest.approx(-0.005)

    def test_very_small_values_keep_precision(self) -> None:
        q = Quantity.create(1.0, "nmol")
        assert q.base_value == pytest.approx(1e-9, rel=1e-15)
        assert math.isfinite(q.base_value)
